<?php
//000000000000
 exit();?>
s:235:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/../data/runtime/cache/2a/3eff9a760062733a1a46cf31ea8827.php,/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/../data/runtime/cache/4c/74a1ff58286a4370e9da96b28dfaa4.php";