<?php
//000000000000
 exit();?>
a:7:{s:2:"id";i:20;s:10:"access_key";s:15:"oYcdxrfzQ69roip";s:9:"game_name";s:26:"梦幻宝可梦(安卓版)";s:10:"game_appid";s:17:"8D69CAC77A743965C";s:11:"sdk_version";i:1;s:16:"relation_game_id";i:20;s:13:"is_force_real";i:0;}