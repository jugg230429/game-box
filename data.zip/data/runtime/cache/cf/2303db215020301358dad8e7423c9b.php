<?php
//000000000000
 exit();?>
a:12:{s:12:"suspend_icon";s:0:"";s:19:"suspend_show_status";s:1:"0";s:15:"loginout_status";s:1:"1";s:8:"set_type";s:7:"sdk_set";s:15:"yk_login_status";s:1:"1";s:23:"account_register_switch";s:1:"1";s:31:"need_choose_smallaccount_switch";s:1:"0";s:21:"vip_level_show_switch";s:1:"0";s:21:"share_entrance_switch";s:1:"0";s:14:"sdk_login_logo";s:50:"site/20240611/7ade340b6838e1c5caaee457f5776e7e.png";s:24:"phonenum_register_switch";s:1:"0";s:25:"network_speed_show_switch";s:1:"1";}