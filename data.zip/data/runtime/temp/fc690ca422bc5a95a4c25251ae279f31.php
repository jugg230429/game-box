<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:112:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/datareport/user/basedata.html";i:1722590115;s:101:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/public/header.html";i:1632734362;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
            position: absolute;
            left: 5px;
            top: 37%;
        }
        .mailer-test .form-required {
            top: 15%;
        }
        .mailer-test .form-horizontal .control-label {
            width: 30%;
        }

        .btn.disabled, .btn[disabled], fieldset[disabled] .btn {
            background-color: #999;
            border-color: #999;
        }

        .btn.disabled:hover, .btn[disabled]:hover, fieldset[disabled] .btn:hover {
            background-color: #999;
            border-color: #999;
        }


        /*新加*/
        .dropdown-menu > .active > a, .dropdown-menu > .active > a:hover, .dropdown-menu > .active > a:focus {
            background-color: #1E91FF;
        }

        .dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus {
            background-color: #1E91FF;
        }

        tbody > .data_summary {
            background-color: #e6e6e6;
        }

    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
        var saveAsImage = 'http://<?php echo $_SERVER["HTTP_HOST"]; ?>/themes/admin_simpleboot3/public/assets/images/data_btn_download_n.png';
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <link rel="stylesheet" href="/themes/admin_simpleboot3/public/assets/css/bootstrap-select.css">
    <script src="/static/js/layer/layer.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap-select.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/defaults-zh_CN.js"></script>
    <link rel="stylesheet" type="text/css" media="all" href="/static/js/datejs/daterangepicker.css"/>
    <script type="text/javascript" src="/static/js/datejs/moment.min.js"></script>
    <script type="text/javascript" src="/static/js/datejs/daterangepicker.js"></script>
    <script>
        btn_tijiao_load_img_id = 0;
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container: 'body',
                html: true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
            $('.pagination .jspagerow').change(function () {
                value = $('.pagination .jspagerow option:selected').attr('vv');
                $('#page').remove();
                $('#search_form').append('<input type="hidden" id="page" name="row" value="' + value + '">');
                $('#search_btn').click();
            });

            $("body").bind("keydown", function (event) {
                if (event.keyCode == 116) {
                    event.preventDefault(); //阻止默认刷新
                    //location.reload();
                    //采用location.reload()在火狐下可能会有问题，火狐会保留上一次链接
                    location = location;
                }
            })
        });

        var unSelected = "#acb6c0";
        var selected = "#2C3E50";
        $(function () {
            $("select").css("color", unSelected);
            $("option").css("color", selected);
            $("select").change(function () {
                var selItem = $(this).val();
                if (selItem == $(this).find('option:first').val()) {
                    $(this).css("color", unSelected);
                } else {
                    $(this).css("color", selected);
                }
            });
        })

    </script>
    <script>
        // 更改button状态
        function change_submit_btn(consa, registe_btn) {
            j = 0;
            consa.find('input,select').each(function (i, n) {
                that = $(this);
                that.hasClass('jsmust')&&!that.val()?registe_btn.prop('disabled',true):j++;
            });
            if(j==consa.find('input,select').length){
                registe_btn.prop('disabled',false);
            }
        }
    </script>
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
        #think_page_trace_open {
        z-index: 9999;
    }
    </style>
    <?php endif; ?>

<script type="text/javascript" src="/static/js/datejs/momentfunction.js"></script>
<link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/question.css" rel="stylesheet">
<link rel="stylesheet" href="/themes/admin_simpleboot3/public/assets/js/laydate.css" id="layuicss-laydate">
<link rel="stylesheet" href="/static/js/layui/css/layui.css">
</head>
<style>
    /* #search_form #rangepickdate {
	    width: 220px!important;
    }    */
</style>
<body>

<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li class="active"><a href="<?php echo url('user/basedata'); ?>">日报数据</a></li>
        <span class="title_remark">说明：用户每日数据汇总，默认显示截至今日数据 <span style="color: rgb(231,76,60);">（注：补链用户数据不计算在内）</span></span>
    </ul>
    <form id="search_form" class="well form-inline  fr" method="get" action="<?php echo url('user/basedata'); ?>" onsubmit="return check();">
        <input type="text" name="datetime" class="laydate-input-ico01" id="test" placeholder="开始时间-结束时间" value="<?php echo input('datetime'); ?>" autocomplete="off">
        <!-- <input type="text" class="form-control form-control-date " name="rangepickdate" id="rangepickdate" style="width: 240px;" value="" readonly placeholder="请选择日期"> -->
        <?php if(AUTH_PROMOTE == 1): $map = ['parent_id'=>0]; ?>
            <select name="promote_id" id="promote_id" class="selectpicker " game_id="<?php echo input('request.promote_id'); ?>" data-live-search="true" data-size="8" style="width: 100px;">
                <option value="">全部渠道</option>
                <option promote-id="is_gf" value='is_gf' <?php if(input('request.promote_id') == 'is_gf'): ?>selected<?php endif; ?>>官方渠道</option>
                <?php $_result=get_promote_list($map);if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <option promote-id="<?php echo $vo['id']; ?>" value="<?php echo $vo['id']; ?>" <?php if(input('request.promote_id') == $vo['id']): ?>selected<?php endif; ?>><?php echo $vo['account']; ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
        <?php endif; if(AUTH_GAME == 1): ?>
            <select name="game_id" id="game_id" class="selectpicker gameChangeWidth" game_id="<?php echo input('request.game_id'); ?>" data-live-search="true" data-size="8" style="width: 100px;">
                <option value="">全部游戏</option>
                <?php $_result=get_game_list('id,game_name');if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <option game-id="<?php echo $vo['id']; ?>" value="<?php echo $vo['id']; ?>" <?php if(input('request.game_id') == $vo['id']): ?>selected<?php endif; ?>><?php echo $vo['game_name']; ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
        <?php endif; ?>
        <input type="hidden" name="row" value="<?php echo input('request.row',10); ?>">
        <input type="hidden" name="sort" id="sort" value="<?php echo input('request.sort',1); ?>">
        <input type="hidden" name="sort_type" id="sort_type" value="<?php echo input('request.sort_type'); ?>">
        <input type="submit" class="btn btn-primary" id="search_btn" value="搜索" />
        <a class="btn btn-clear" href="<?php echo url('user/basedata'); ?>">清空</a>
        <a class="btn btn-export js-ajax-dialog-btn-xz" data-msg="确定导出吗？" href="<?php echo url('Export/expUser',array_merge(['id'=>1,'xlsname'=>'基础数据'.$start.'至'.$end],input(),$total_data)); ?>">导出</a>
    </form>
    <table class="table table-hover table-bordered">
        <thead>
        <tr>
            <th>日期</th>
            <th>渠道</th>
            <th>
                <a href="javascript:changesort('count_new_register_user');" class="basedata-a">新增用户
                    <?php if(input('request.sort_type') == 'count_new_register_user' and input('request.sort') == 3): ?>
                        ▼
                        <?php elseif(input('request.sort_type') == 'count_new_register_user' and input('request.sort') == 2): ?>
                        ▲
                        <?php else: ?>
                        <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                    <?php endif; ?>
                </a>
                <div class="question_">
                    <i class="question_mark">?</i>
                    <div class="question_content">
                        <ul class="question_content_box">
                            <li class="question_list">
                                <span class="title">新增用户</span>
                                <span class="">平台新注册用户数</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </th>
            <th>
                <a href="javascript:changesort('count_active_user');" class="basedata-a">活跃用户
                    <?php if(input('request.sort_type') == 'count_active_user' and input('request.sort') == 3): ?>
                        ▼
                        <?php elseif(input('request.sort_type') == 'count_active_user' and input('request.sort') == 2): ?>
                        ▲
                        <?php else: ?>
                        <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                    <?php endif; ?>
                </a>
                <div class="question_">
                    <i class="question_mark">?</i>
                    <div class="question_content">
                        <ul class="question_content_box">
                            <li class="question_list">
                                <span class="title">活跃用户</span>
                                <span class="">登录游戏用户数（含新老用户，累计时去重）</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </th>
            <th>
                <a href="javascript:changesort('count_pay_user');" class="basedata-a">付费用户
                    <?php if(input('request.sort_type') == 'count_pay_user' and input('request.sort') == 3): ?>
                        ▼
                        <?php elseif(input('request.sort_type') == 'count_pay_user' and input('request.sort') == 2): ?>
                        ▲
                        <?php else: ?>
                        <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                    <?php endif; ?>
                </a>
                <div class="question_">
                    <i class="question_mark">?</i>
                    <div class="question_content">
                        <ul class="question_content_box">
                            <li class="question_list">
                                <span class="title">付费用户</span>
                                <span class="">游戏内充值用户数（统计充值成功，累计时去重）</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </th>
            <th>
                <a href="javascript:changesort('count_new_pay_user');" class="basedata-a">新增付费用户
                    <?php if(input('request.sort_type') == 'count_new_pay_user' and input('request.sort') == 3): ?>
                        ▼
                        <?php elseif(input('request.sort_type') == 'count_new_pay_user' and input('request.sort') == 2): ?>
                        ▲
                        <?php else: ?>
                        <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                    <?php endif; ?>
                </a>
                <div class="question_">
                    <i class="question_mark">?</i>
                    <div class="question_content">
                        <ul class="question_content_box">
                            <li class="question_list">
                                <span class="title">新增付费用户</span>
                                <span class="">注册当日进行游戏内充值的用户数（统计充值成功，累计时去重）</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </th>
            <th>
                <a href="javascript:changesort('new_total_pay');" class="basedata-a">新增付费额
                    <?php if(input('request.sort_type') == 'new_total_pay' and input('request.sort') == 3): ?>
                        ▼
                        <?php elseif(input('request.sort_type') == 'new_total_pay' and input('request.sort') == 2): ?>
                        ▲
                        <?php else: ?>
                        <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                    <?php endif; ?>
                </a>
                <div class="question_">
                    <i class="question_mark">?</i>
                    <div class="question_content">
                        <ul class="question_content_box">
                            <li class="question_list">
                                <span class="title">新增付费额</span>
                                <span class="">新注册用户充值金额</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </th>
            <th>
                <a href="javascript:changesort('count_total_order');" class="basedata-a">订单数
                    <?php if(input('request.sort_type') == 'count_total_order' and input('request.sort') == 3): ?>
                        ▼
                        <?php elseif(input('request.sort_type') == 'count_total_order' and input('request.sort') == 2): ?>
                        ▲
                        <?php else: ?>
                        <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                    <?php endif; ?>
                </a>
                <div class="question_">
                    <i class="question_mark">?</i>
                    <div class="question_content">
                        <ul class="question_content_box">
                            <li class="question_list">
                                <span class="title">订单数</span>
                                <span class="">游戏内订单数量（统计充值成功） </span>
                            </li>
                        </ul>
                    </div>
                </div>
            </th>
            <th>
                <a href="javascript:changesort('total_pay');" class="basedata-a">总付费额
                    <?php if(input('request.sort_type') == 'total_pay' and input('request.sort') == 3): ?>
                        ▼
                        <?php elseif(input('request.sort_type') == 'total_pay' and input('request.sort') == 2): ?>
                        ▲
                        <?php else: ?>
                        <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                    <?php endif; ?>
                </a>
                <div class="question_">
                    <i class="question_mark">?</i>
                    <div class="question_content">
                        <ul class="question_content_box">
                            <li class="question_list">
                                <span class="title">总付费额</span>
                                <span class="">累计充值总额</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </th>
            <th>
                <a href="javascript:changesort('rate');" class="basedata-a">总付费率
                    <?php if(input('request.sort_type') == 'rate' and input('request.sort') == 3): ?>
                        ▼
                        <?php elseif(input('request.sort_type') == 'rate' and input('request.sort') == 2): ?>
                        ▲
                        <?php else: ?>
                        <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                    <?php endif; ?>
                </a>
                <div class="question_">
                    <i class="question_mark">?</i>
                    <div class="question_content">
                        <ul class="question_content_box">
                            <li class="question_list">
                                <span class="title">总付费率</span>
                                <span class="">付费用户/新增用户</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </th>
            <th>
                <a href="javascript:changesort('arpu');" class="basedata-a">ARPU
                    <?php if(input('request.sort_type') == 'arpu' and input('request.sort') == 3): ?>
                        ▼
                        <?php elseif(input('request.sort_type') == 'arpu' and input('request.sort') == 2): ?>
                        ▲
                        <?php else: ?>
                        <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                    <?php endif; ?>
                </a>
                <div class="question_">
                    <i class="question_mark">?</i>
                    <div class="question_content">
                        <ul class="question_content_box">
                            <li class="question_list">
                                <span class="title">ARPU</span>
                                <span class="">总付费额/活跃用户</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </th>
            <th>
                <a href="javascript:changesort('arppu');" class="basedata-a">ARPPU
                    <?php if(input('request.sort_type') == 'arppu' and input('request.sort') == 3): ?>
                        ▼
                        <?php elseif(input('request.sort_type') == 'arppu' and input('request.sort') == 2): ?>
                        ▲
                        <?php else: ?>
                        <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                    <?php endif; ?>
                </a>
                <div class="question_">
                    <i class="question_mark">?</i>
                    <div class="question_content">
                        <ul class="question_content_box">
                            <li class="question_list">
                                <span class="title">ARPPU</span>
                                <span class="">总付费额/付费用户</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </th>
            <th>
                <a href="javascript:changesort('count_fire_device');" class="basedata-a">激活设备
                    <?php if(input('request.sort_type') == 'count_fire_device' and input('request.sort') == 3): ?>
                        ▼
                        <?php elseif(input('request.sort_type') == 'count_fire_device' and input('request.sort') == 2): ?>
                        ▲
                        <?php else: ?>
                        <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                    <?php endif; ?>
                </a>
                <div class="question_ last">
                    <i class="question_mark">?</i>
                    <div class="question_content">
                        <ul class="question_content_box">
                            <li class="question_list">
                                <span class="title">激活设备</span>
                                <span class="">首次安装并且打开应用的设备数，只在首次<br/>安装打开应用时计作新增设备</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </th>
        </tr>
        </thead>
        <tbody>
        <?php if(empty($data_lists) || (($data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator ) && $data_lists->isEmpty())): ?>
            <tr><td colspan="13" style="text-align: center;">暂无数据</td></tr>
            <?php else: ?>
            <tr class="">
                <td><span style="margin-right: 10px;">汇总 </span></td>
                <td class="data_summary_bold"><?php echo input('request.promote_id')==0?'--':get_promote_name(input('request.promote_id')); ?></td>
                <td class="data_summary_bold"><?php echo $total_data['new_register_user']; ?></td>
                <td class="data_summary_bold"><?php echo $total_data['active_user']; ?></td>
                <td class="data_summary_bold"><?php echo $total_data['pay_user']; ?></td>
                <td class="data_summary_bold"><?php echo $total_data['new_pay_user']; ?></td>
                <td class="data_summary_bold"><?php echo $total_data['new_total_pay']; ?></td>
                <td class="data_summary_bold"><?php echo $total_data['total_order']; ?></td>
                <td class="data_summary_bold"><?php echo $total_data['total_pay']; ?></td>
                <td class="data_summary_bold"><?php echo $total_data['new_register_user']==0?'0.00':null_to_0($total_data['pay_user']/$total_data['new_register_user']*100); ?>%</td>
                <td class="data_summary_bold"><?php echo $total_data['active_user']==0?'0.00':null_to_0($total_data['total_pay']/$total_data['active_user']); ?></td>
                <td class="data_summary_bold"><?php echo $total_data['pay_user']==0?'0.00':null_to_0($total_data['total_pay']/$total_data['pay_user']); ?></td>
                <td class="data_summary_bold"><?php echo $total_data['fire_device']; ?></td>
            </tr>
            <?php if(is_array($data_lists) || $data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator): if( count($data_lists)==0 ) : echo "" ;else: foreach($data_lists as $key=>$vo): ?>
                <tr>
                    <td><?php echo $vo['time']; ?></td>
                    <td><?php echo input('request.promote_id')==0?'全部':get_promote_name(input('request.promote_id')); ?></td>
                    <td class="js_list-data list-data">
                        <?php echo $vo['count_new_register_user']; ?>
                    </td>
                    <td class="js_list-data list-data">
                        <?php echo $vo['count_active_user']; ?>
                    </td>
                    <td class="js_list-data list-data">
                        <?php echo $vo['count_pay_user']; ?>
                    </td>
                    <td class="js_list-data list-data">
                        <?php echo $vo['count_new_pay_user']; ?>
                    </td>
                    <td class="js_list-data needAjax list-data" url="<?php echo url('Ajax/get_pay_detail',['date'=>$vo['time'],'promote_id'=>input('request.promote_id'),'game_id'=>input('request.game_id'),'user_ids'=>$vo['new_pay_user']]); ?>">
                        <?php echo $vo['new_total_pay']; ?>
                    </td>
                    <td class="js_list-data list-data">
                        <?php echo $vo['count_total_order']; ?>
                    </td>
                    <td><?php echo $vo['total_pay']; ?></td>
                    <td><?php echo $vo['rate']; ?></td>
                    <td><?php echo $vo['arpu']; ?></td>
                    <td><?php echo $vo['arppu']; ?></td>
                    <td class="js_list-data list-data">
                        <?php echo $vo['count_fire_device']; ?>
                    </td>
                </tr>
            <?php endforeach; endif; else: echo "" ;endif; endif; ?>
        </tbody>
    </table>
    <div class="pagination">
        <?php echo $page; ?>
        <!--<li class="page-item"></li>-->
    </div>
</div>
<script src="/static/js/admin.js"></script>
<script src="/static/js/layer/layer.js"></script>
<script src="/themes/admin_simpleboot3/public/assets/js/laydate.js"></script>
<script type="text/javascript">
    //时间插件 默认时间
    var start = '<?php echo $start; ?>',end  = '<?php echo $end; ?>';
    function check(){
        layer.load(1);
        var jsdate = $("#rangepickdate").val();
        datearr=jsdate.split('至');
        var start_time = datearr[0];
        var end_time = datearr[1];
        if(start_time != '' && end_time != '' && start_time > end_time){
            layer.msg('开始时间不能大于结束时间');
            return false;
        }
        return true;
    }
    //排序
    function changesort(type){
        var sort_type = $("#sort_type").val();
        if(sort_type != type){
            var sort = 1;
        }else{
            var sort = $("#sort").val();
        }
        $("#sort_type").val(type);
        if(sort == 1){
            $("#sort").val(3);
        }else if(sort == 3){
            $("#sort").val(2);
        }else{
            $("#sort").val(1);
        }
        $("#search_btn").click();
    }

    //经过表头字段热区时出现？
    $(".question_").click(function () {
        $(this).find(".question_content").toggleClass("open")

    });
    $("tr th").mouseover(function () {
        $(this).find(".question_").addClass("on");
    });
    $("tr th").mouseout(function () {
        $(this).find(".question_").removeClass("on");
        $(this).find(".question_content").removeClass("open")
    });
    
        //定义接收本月的第一天和最后一天
        var startDate1=new Date(new Date().setDate(1));
        var endDate1=new Date(new Date(new Date().setMonth(new Date().getMonth()+1)).setDate(0));
        //定义接收上个月的第一天和最后一天
        var startDate2=new Date(new Date(new Date().setMonth(new Date().getMonth()-1)).setDate(1));
        var endDate2=new Date(new Date().setDate(0));
        laydate.render({
            elem: '#test',
            type: 'date',
            range: '~',
            format: 'yyyy-M-d',
            //max:'2018-1-15',//可选最大日期（当然如果加个这上，那扩展的那几个快捷选择时间按扭的值就得判断处理一下了）
            //min:'2018-1-15',//可选最小日期（当然如果加个这上，那扩展的那几个快捷选择时间按扭的值就得判断处理一下了）
            extrabtns: [
                {id: 'today', text: '今天', range: [new Date(), new Date()]},
                {id: 'lastday-7', text: '过去7天', range: [new Date(new Date().setDate(new Date().getDate()-7)), new Date(new Date().setDate(new Date().getDate()-1))]},
                {id: 'lastday-30', text: '过去30天', range: [new Date(new Date().setDate(new Date().getDate()-30)), new Date(new Date().setDate(new Date().getDate()-1))]},
                {id: 'yesterday', text: '昨天', range: [new Date(new Date().setDate(new Date().getDate()-1)), new Date(new Date().setDate(new Date().getDate()-1))]},
                {id: 'thismonth', text: '本月', range: [startDate1,endDate1]},
                {id: 'lastmonth', text: '上个月', range: [startDate2,endDate2]}
            ],
            done: function(val, stdate, ovdate){
                //当确认选择时间后调用这里
            }
        });
</script>
</body>
</html>
