<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:99:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/simpleboot3/media/index/index.html";i:1632734368;s:98:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/simpleboot3/mediapublic/base.html";i:1632734368;}*/ ?>
﻿<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="baidu-site-verification" content="l18xwLxEKU">
  <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
  <meta name="renderer" content="webkit">

  <script src="/static/js/jquery-1.11.1.min.js"></script>
  <script src="/themes/simpleboot3/mediapublic/assets/js/frontend.js"></script>

  <link href="<?php if($union_set[pc_icon]): ?><?php echo cmf_get_image_url($union_set['pc_icon']); else: ?><?php echo cmf_get_image_url(cmf_get_option('media_set')['pc_set_ico']); endif; ?>" type="image/x-icon" rel="shortcut icon">
  <?php if($action_name == index and $controller_name == Index): ?>
    <title><?php echo seo_replace($seo['media_index']['seo_title'],array(),'media','title'); ?></title>
    <meta name="keywords" content="<?php echo seo_replace($seo['media_index']['seo_keyword'],array(),'media','keywords'); ?>">
    <meta name="description" content="<?php echo seo_replace($seo['media_index']['seo_description'],array(),'media','description'); ?>">
    <?php elseif(($action_name == game_center or $action_name == game_hcenter or $action_name == game_ycenter) and $controller_name == Game): ?>
    <title><?php echo seo_replace($seo['media_game_list']['seo_title'],array('game_name'=>$data['game_name']),'media','title'); ?></title>
    <meta name="keywords" content="<?php echo seo_replace($seo['media_game_list']['seo_keyword'],array(),'media','keywords'); ?>">
    <meta name="description" content="<?php echo seo_replace($seo['media_game_list']['seo_description'],array(),'media','description'); ?>">
    <?php elseif(($action_name == detail or $action_name == hdetail or $action_name == ydetail) and $controller_name == Game): ?>
    <title><?php echo seo_replace($seo['media_game_detail']['seo_title'],array('game_name'=>$data['game_name']),'media','title'); ?></title>
    <meta name="keywords"
          content="<?php echo seo_replace($seo['media_game_detail']['seo_keyword'],array('game_name'=>$data['game_name'],),'media','keywords'); ?>">
    <meta name="description"
          content="<?php echo seo_replace($seo['media_game_detail']['seo_description'],array('game_name'=>$data['game_name'],),'media','description'); ?>">
    <?php elseif(($action_name == open_game or $action_name == open_ygame) and $controller_name == Game): ?>
    <title><?php echo seo_replace($seo['media_open_game']['seo_title'],array('game_name'=>$game_name),'media','title'); ?></title>
    <meta name="keywords"
          content="<?php echo seo_replace($seo['media_open_game']['seo_keyword'],array('game_name'=>$game_name),'media','keywords'); ?>">
    <meta name="description"
          content="<?php echo seo_replace($seo['media_open_game']['seo_description'],array('game_name'=>$game_name),'media','description'); ?>">
    <?php elseif($action_name == gift and $controller_name == Gift): ?>
    <title><?php echo seo_replace($seo['media_gift_index']['seo_title'],array('giftbag_name'=>$data['giftbag_name']),'media','title'); ?>
    </title>
    <meta name="keywords"
          content="<?php echo seo_replace($seo['media_gift_index']['seo_keyword'],array('giftbag_name'=>$data['giftbag_name'],),'media','keywords'); ?>">
    <meta name="description"
          content="<?php echo seo_replace($seo['media_gift_index']['seo_description'],array('giftbag_name'=>$data['giftbag_name'],),'media','description'); ?>">
    <?php elseif($action_name == detail and $controller_name == Gift): ?>
    <title><?php echo seo_replace($seo['media_gift_detail']['seo_title'],array('giftbag_name'=>$data['giftbag_name'],'game_name'=>$data['game_name']),'media','title'); ?>
    </title>
    <meta name="keywords"
          content="<?php echo seo_replace($seo['media_gift_detail']['seo_keyword'],array('giftbag_name'=>$data['giftbag_name'],'game_name'=>$data['game_name']),'media','keywords'); ?>">
    <meta name="description"
          content="<?php echo seo_replace($seo['media_gift_detail']['seo_description'],array('giftbag_name'=>$data['giftbag_name'],'game_name'=>$data['game_name']),'media','description'); ?>">
    <?php elseif($action_name == index and $controller_name == Article): ?>
    <title><?php echo seo_replace($seo['media_news_list']['seo_title'],array('giftbag_name'=>$data['giftbag_name']),'media','title'); ?>
    </title>
    <meta name="keywords" content="<?php echo seo_replace($seo['media_news_list']['seo_keyword'],[],'media','keywords'); ?>">
    <meta name="description" content="<?php echo seo_replace($seo['media_news_list']['seo_description'],[],'media','description'); ?>">
    <?php elseif($action_name == detail and $controller_name == Article): ?>
    <title><?php echo seo_replace($seo['media_news_detail']['seo_title'],array('news_title'=>$data['post_title']),'media','title'); ?>
    </title>
    <meta name="keywords"
          content="<?php echo seo_replace($seo['media_news_detail']['seo_keyword'],array('news_title'=>$data['post_title'],),'media','keywords'); ?>">
    <meta name="description"
          content="<?php echo seo_replace($seo['media_news_detail']['seo_description'],array('news_title'=>$data['post_title'],),'media','description'); ?>">
    <?php elseif($action_name == pay and $controller_name == Pay): ?>
    <title><?php echo seo_replace($seo['media_recharge']['seo_title'],array('news_title'=>$data['post_title']),'media','title'); ?></title>
    <meta name="keywords"
          content="<?php echo seo_replace($seo['media_recharge']['seo_keyword'],array('news_title'=>$data['post_title'],),'media','keywords'); ?>">
    <meta name="description"
          content="<?php echo seo_replace($seo['media_recharge']['seo_description'],array('news_title'=>$data['post_title'],),'media','description'); ?>">
    <?php else: ?>
    <title><?php echo seo_replace($seo['media_index']['seo_title'],array(),'media','title'); ?></title>
    <meta name="keywords" content="<?php echo seo_replace($seo['media_index']['seo_keyword'],array(),'media','keywords'); ?>">
  <?php endif; ?>
  <meta name="frontend" content="Robin">

  <link rel="stylesheet" href="/themes/simpleboot3/mediapublic/assets/css/public.css">
  <link rel="stylesheet" href="/static/js/layui/css/layui.css">
  <script src="/static/js/layui/layui.all.js"></script>
  <script src="/static/js/public.js"></script>

  <script>
    url = "<?php echo url('Index/get_auth'); ?>";
    send_sms_url = "<?php echo url('User/send_sms'); ?>";
    send_email_url = "<?php echo url('User/send_email'); ?>";
    forget_url = "<?php echo url('User/checkForgetName'); ?>";
    forget_sms_url = "<?php echo url('User/checkForgetPhone'); ?>";
    forget_email_url = "<?php echo url('User/checkForgetEmail'); ?>";
    is_blank = "<?php echo (isset($is_blank) && ($is_blank !== '')?$is_blank:0); ?>";
    //全局变量
    var GV = {
      ROOT: "/",
      WEB_ROOT: "/",
      JS_ROOT: "static/js/"
    };
  </script>
  <style>
    .show {
      display: block;
      text-align: center !important;
      width: 100% !important
    }

    .hide {
      display: none;
      text-align: center !important;
      width: 100% !important
    }

    #embed-captcha {
      width: 304px;
    }
    .can_click{
      background:rgb(1, 143, 255);
    }
    .geetest-refresh {
      position: absolute;
      top: 0;
      right: 0;
      height: 100%;
      width: 36px;
    }
    .geetest-refresh img{
      width: 22px;
      height: 22px;
    }
	.loginclass .layui-layer-content{
	   background: rgb(249, 249, 249);
	   border-radius:5px;
	   box-shadow:0px 0px 20px 0px rgba(86,157,236,0.2);
	}
  .fg a.act.act_1{

    left:0px;
  }
  .fg a.act.act_2{

    left:72px;
  }
  .fg a.act.act_3{
    left:144px;
  }
  .act {
    position: absolute !important;
    left: 0px;
}
.all{
  position: relative;
    /* margin-right: 216px; */
}

  </style>
  
</head>

<body>
<?php 
  // 增加账号注册开关
  $sdk_set = cmf_get_option('media_set');
  $account_register_switch = (int) ($sdk_set['account_register_switch'] ?? 1); // 0 关闭 1 开启
  $phonenum_register_switch = (int) ($sdk_set['phonenum_register_switch'] ?? 1); // 0 关闭 1 开启
  $email_register_switch = (int) ($sdk_set['email_register_switch'] ?? 1); // 0 关闭 1 开启
  $pc_navigation_spend = empty($sdk_set['pc_navigation_user'])?'用户':$sdk_set['pc_navigation_user'];
  // 获取三端显示顺序
  $media_sort = get_media_sort();
  $h5_sort = $media_sort['h5_sort'];
  $sy_sort = $media_sort['sy_sort'];
  $yy_sort = $media_sort['yy_sort'];
  $first_show = $media_sort['first_show'];
  $first_show_num = $media_sort['first_show_num'];
  $total_num = $media_sort['total_num'];
  $nav_num = $media_sort['nav_num'];
  // var_dump($first_show_num);exit;
 ?>
<div class="indexpage">
  <?php if(!(($action_name == open_game or $action_name == open_ygame) and $controller_name == Game)): ?>
  <!-- 头部导航栏 -->

  <header class="header">
    <div class="top">
	   <div class="top-con">
	   <a  class="tn-tab fl js-home homepage"><em class="homepage-icon"></em>设为首页</a>
	   <a class="fl tn-tab collect" onclick="AddFavorite(window.location,document.title)" href="javascript:void(0)"><em class="collect-icon"></em>加入收藏</a>
	   <?php if(AUTH_USER == 1): ?>
          <div class="fg" style="width: 360px;">

            <p>
              <!-- 登录注册 -->

            <p id="total_login" style="text-align: right;float: right;">

			<span class="login">登录</span>
              <?php if(cmf_get_option('media_set')['pc_user_allow_register'] == 1): if(($account_register_switch == 1) or ($phonenum_register_switch == 1) or ($email_register_switch == 1)): ?>
                  <span class="line">|</span><span class="zhuce">注册</span>
                <?php endif; endif; ?>
            </p>
            <div id="total_auth" class="people_info hide"  style="width: 360px;text-align: right;">
              <p class="login_out fg"><p class="login_out fg">[<a class="js-ajax-btn reload-now ajax-no-reload" href="<?php echo url('User/logout'); ?>">退出</a>]</p></p>
              <p class="username fg"><a href="<?php echo url('User/userinfo'); ?>" class="user_account"></a></p>
              <img src="" alt="" class="fg">

            </div>
            </p>
			  <!-- <?php if($union_set): ?>
              <div class="fg welcome" style="width: 50%;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">欢迎来到<?php echo $union_set['app_weixin']; ?>!</div>
              <?php else: ?>
			<div class="fg welcome" style="width: 50%;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">欢迎来到<?php echo cmf_get_option('media_set')['pc_set_qrcode_name']; ?>!</div>
            <?php endif; ?> -->
          </div>
        <?php endif; ?>
	   </div>
	</div>
    <div class="layui-container">
      <div class="layui-row">
        <div class="fl nav_logo">
          <a href="<?php echo url('Index/index'); ?>">
		      <img src="<?php if($union_set[pc_logo]): ?><?php echo cmf_get_image_url($union_set['pc_logo']); else: ?><?php echo cmf_get_image_url(cmf_get_option('media_set')['pc_set_logo']); endif; ?>"
                  alt="" ></a>
        </div>
        <div class="fg search">
            <span></span>
            <label for="search" class="search_label"><input type="text" name="game_name" value="<?php echo input('game_name'); ?>" id="search"
                                       placeholder="输入关键词" autocomplete="off" onfocus="this.placeholder=''" >
                <button type="button" class="search_icon"><img src="/static/images/ico_seach.png"
                                                               alt=""></button></label>
            <div class="inputdowndiv" id="inputdowndiv">
            </div>
        </div>

        <div class="fg" style="margin-right:50px;">
          <nav class="nav">
            <a href="<?php echo url('Index/index'); ?>">
              <li <?php if($controller_name == 'Index'): ?>class="active"<?php endif; ?>><?php if(cmf_get_option('media_set')['pc_navigation_index']): ?>
              <?php echo cmf_get_option('media_set')['pc_navigation_index']; else: ?>首页<?php endif; ?>
              </li>
            </a>
            <div class="all" style="width:<?php echo $nav_num*72; ?>px">
            <?php if(AUTH_GAME == 1 and PERMI > 0 and PERMI != 2): if(cmf_get_option('media_set')['pc_navigation_sy_status'] != '0'): ?>
                <a href="<?php echo url('Game/game_center'); ?>" class="act act_<?php echo $sy_sort; ?>">
                  <li <?php if($controller_name == 'Game' and ($action_name == 'game_center' or $action_name == 'detail')): ?>class="active"<?php endif; ?>><?php if(cmf_get_option('media_set')['pc_navigation_sy']): ?>
                  <?php echo cmf_get_option('media_set')['pc_navigation_sy']; else: ?>手游<?php endif; ?>
                  </li>
                </a>
              <?php endif; endif; if(AUTH_GAME == 1 and PERMI > 0 and PERMI != 1): if(cmf_get_option('media_set')['pc_navigation_h5_status'] != '0'): ?>
                <a href="<?php echo url('Game/game_hcenter'); ?>" class="act act_<?php echo $h5_sort; ?>">
                  <li <?php if($controller_name == 'Game' and ($action_name == 'game_hcenter' or $action_name == 'hdetail')): ?>class="active"<?php endif; ?>>
                  <?php if(cmf_get_option('media_set')['pc_navigation_h5']): ?>
                    <?php echo cmf_get_option('media_set')['pc_navigation_h5']; else: ?>
                    H5
                  <?php endif; ?>
                  </li>
                </a>
              <?php endif; endif; if(YPERMI == 1): if(cmf_get_option('media_set')['pc_navigation_yy_status'] != '0'): ?>
                <a href="<?php echo url('Game/game_ycenter'); ?>"  class="act act_<?php echo $yy_sort; ?>">
                  <li <?php if($controller_name == 'Game' and ($action_name == 'game_ycenter' or $action_name == 'ydetail')): ?>class="active"<?php endif; ?>>
                  <?php if(cmf_get_option('media_set')['pc_navigation_yy']): ?>
                    <?php echo cmf_get_option('media_set')['pc_navigation_yy']; else: ?>
                    页游
                  <?php endif; ?>
                  </li>
                </a>
              <?php endif; endif; ?>
          </div>


            <?php if(cmf_get_option('media_set')['pc_navigation_gift_status'] != '0'): ?>
              <a href="<?php echo url('Gift/gift'); ?>">
                <li <?php if($controller_name == 'Gift'): ?>class="active"<?php endif; ?>><?php if(cmf_get_option('media_set')['pc_navigation_gift']): ?>
                <?php echo cmf_get_option('media_set')['pc_navigation_gift']; else: ?>礼包<?php endif; ?>
                </li>
              </a>
            <?php endif; if(cmf_get_option('media_set')['pc_navigation_spend_status'] != '0'): if(AUTH_PAY == 1): ?>
                <a href="<?php echo url('Pay/pay'); ?>">
                  <li <?php if($controller_name == 'Pay'): ?>class="active"<?php endif; ?>><?php if(cmf_get_option('media_set')['pc_navigation_spend']): ?>
                  <?php echo cmf_get_option('media_set')['pc_navigation_spend']; else: ?>充值<?php endif; ?>
                  </li>
                </a>
              <?php endif; endif; ?>

            <a hidden href="<?php echo url('Discount/index'); ?>">
              <li <?php if($controller_name == 'Discount'): ?>class="active"<?php endif; ?>>
              折扣
              </li>
            </a>

            <?php if(AUTH_USER == 1): if(cmf_get_option('media_set')['pc_navigation_user_status'] != '0'): ?>
              <span class="js_usermune">
                <a class="login" href="javascript:;" style="color: #333;">
                  <li>
                    <?php if(cmf_get_option('media_set')['pc_navigation_user']): ?>
                      <?php echo cmf_get_option('media_set')['pc_navigation_user']; else: ?>用户<?php endif; ?>
                  </li>
                </a>
              </span>
              <?php endif; endif; if(cmf_get_option('media_set')['pc_navigation_info_status'] != '0'): ?>
            <a href="<?php echo url('Article/index'); ?>">
              <li <?php if($controller_name == 'Article' and !in_array($action_name,['about'])): ?>class="active"<?php endif; ?>><?php if(cmf_get_option('media_set')['pc_navigation_info']): ?>
              <?php echo cmf_get_option('media_set')['pc_navigation_info']; else: ?>资讯<?php endif; ?>
              </li>
            </a>
            <?php endif; if(cmf_get_option('media_set')['pc_navigation_service_status'] != '0'): ?>
              <a href="<?php echo url('Service/index'); ?>">
                <li <?php if($controller_name == 'Service'): ?>class="active"<?php endif; ?>>
                <?php if(cmf_get_option('media_set')['pc_navigation_service']): ?>
                  <?php echo cmf_get_option('media_set')['pc_navigation_service']; else: ?>
                  客服
                <?php endif; ?>
                </li>
              </a>
            <?php endif; if(cmf_get_option('media_set')['pc_navigation_client_status']): ?>
              <a href="<?php echo url('download/index'); ?>" target="_blank">
               <li>
                 <?php if(cmf_get_option('media_set')['pc_navigation_client']): ?>
                  <?php echo cmf_get_option('media_set')['pc_navigation_client']; else: ?>
                   客户端
                 <?php endif; ?>
               </li>
              </a>
            <?php endif; ?>

          </nav>
        </div>

      </div>
    </div>
  </header>
  <?php endif; ?>
  <!-- 主体内容 -->
  
    <link rel="stylesheet" href="/themes/simpleboot3/mediapublic/assets/css/index.css">
    <script src="/static/js/zeroclipboard/jquery.zclip.min.js"></script>
    <!-- 轮播广告图 -->
    <div class="carousel">

        <?php 
            // 增加账号注册开关
            $sdk_set = cmf_get_option('media_set');
            $account_register_switch = (int) ($sdk_set['account_register_switch'] ?? 1); // 0 关闭 1 开启
            $phonenum_register_switch = (int) ($sdk_set['phonenum_register_switch'] ?? 1); // 0 关闭 1 开启
            $email_register_switch = (int) ($sdk_set['email_register_switch'] ?? 1); // 0 关闭 1 开启
            // 获取三端显示顺序
            $media_sort = get_media_sort();
            $h5_sort = $media_sort['h5_sort'];
            $sy_sort = $media_sort['sy_sort'];
            $yy_sort = $media_sort['yy_sort'];
            $first_show = $media_sort['first_show'];
            $first_show_num = $media_sort['first_show_num'];
            $total_num = $media_sort['total_num'];
            // var_dump($first_show_num);exit;
         ?>

        <div class="layui-carousel" id="test1">
            <div carousel-item>
                <?php if(is_array($carousel) || $carousel instanceof \think\Collection || $carousel instanceof \think\Paginator): $i = 0; $__LIST__ = $carousel;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <div class="car_item">
                        <a href="<?php echo $vo['url']; ?>" target="<?php echo $vo['target']; ?>">
                        <img src="<?php echo cmf_get_image_url($vo['data']); ?>" alt="" class="lb_img" onerror="this.src='/static/images/empty.jpg';this.onerror=null">
                        </a>
						<?php if($vo['type'] == 1): ?>
						<div class="game-box">
						    <div class="game-box-con">
							    <div class="game-box-con-img">
                                    <img src="<?php echo cmf_get_image_url($vo['game_icon']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" class="game-icon fl">
                                    <?php if($vo['sdk_version'] != 4): ?>
                                        <div class="game-box-con-code fl">
                                            <?php $url = url('Game/detail',['game_id'=>$vo['game_id']],true,true) ?>
                                            <img src="<?php echo url('qrcode', ['url' => base64_encode(base64_encode($url))]); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" class="">
                                        </div>
                                    <?php endif; ?>
								</div>
								<div class="clear"></div>
								<div class="game-name"><?php echo $vo['relation_game_name']; ?></div>
								<div class="game-describe"><?php echo $vo['features']; ?></div>
								<a href="<?php echo $vo['url']; ?>" class="game-btn">查看详情&nbsp;&nbsp;&nbsp;<img src="/themes/simpleboot3/mediapublic/assets/images/game_arrow_right.png"></a>
							</div>
						</div>
						<?php endif; ?>
                    </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
        <?php if(AUTH_USER == 1): ?>
            <!--        首页登录框-->
            <div class="login-contain-box">
                <div class="login-content">
                    <div class="login_modal index-login">
                        <form class="js-ajax-form" action="<?php echo url('User/login'); ?>" method="post">
                            <span class="closemodal"><img src="/static/images/login_btn_close_n.png" alt=""></span>
                            <p class="login_username">
							   <label class="label-name">账号</label>
							   <input type="text"  autocomplete="off" name="account" value="" placeholder="手机号/用户名"></p>
                            <p class="login_password">
							    <label class="label-name">密码</label>
							    <input type="password"  autocomplete="new-password" name="password"  value="" placeholder="密码">
                            </p>
                            <p class="zdlogin">
                                <label for="zdlogin1">
                                    <input type="checkbox" name="zdlogin" checked id="zdlogin1" value="1" class="fl" hidden>
                                    <i class="choice-icon"></i>
                                    <span class="remember-text">记住密码</span>
                                </label>
                            </p>
                            <p class="login_botton">
                                <button id="login_submit" class="js-ajax-submit reload-now ajax-no-reload" type="submit">登录</button>
                            </p>
                        </form>
                        <div class='ml20 mt10'>
                            <p class="fl zhuce_p">
                                <?php if(cmf_get_option('media_set')['pc_user_allow_register'] == 1): if(($account_register_switch == 1) or ($phonenum_register_switch == 1) or ($email_register_switch == 1)): ?>
                                        <span class="zhuce_newuser">注册新用户</span>
                                    <?php endif; endif; ?>
                            </p>
                            <p class="fg mg14"><span class="forget_password fg">忘记密码?</span></p>
                        </div>
						<div class="clear"></div>
						<div class="login-line"></div>
						<div class="clear"></div>
                        <?php if($qq_login == 1 or $weixin_login == 1): ?>


                            <div class="fl fast_login_title">快捷登录</div>


                            <p class=" fast_login_icon fl">
                                <?php if($qq_login == 1): ?><a  class="fast_login_qq" href="<?php echo url('User/thirdlogin',['type'=>'qq']); ?>"> <img
                                        src="/static/images/login_qq.png" alt=""></a><?php endif; if($weixin_login == 1): ?><a class="fast_login_wx" href="<?php echo url('User/thirdlogin',['type'=>'weixin']); ?>"> <img
                                        src="/static/images/login_wx.png" alt="" ></a><?php endif; ?>
                                        <!-- 游客登录 -->
                                 <span  class="fast_login_youke" > <img
                                            src="/static/images/ico_youke.png" alt="" class="login_youke"></span><?php endif; ?>
                            </p>
                        <?php endif; ?>
                    </div>
                    <!-- 登录框变成等级显示 -->
                    <div class="levelBox">
                        <div class="levelInfo_modal">
                            <span class="removeModal"></span>
                            <div class="avatarContainer">
                                <div class="avatarImg">
                                    <img src="<?php echo cmf_get_image_url($user['head_img']); ?>" alt="">
                                </div>
                                <div  class="rightInfoAccount">
                                    <p>
                                        <a href="<?php echo url('media/user/userinfo'); ?>"><span class="account-title"><?php echo $user['account']; ?></span></a>
                                        <a class="js-ajax-btn reload-now ajax-no-reload" href="<?php echo url('media/user/logout'); ?>"><span class="removeAccount">[退出]</span></a>
                                    </p>
                                    <span class="couponNumber">平台币：<span><?php echo $user['balance']; ?></span> </span>
                                    <span class="couponNumber">&nbsp;积分：<span><?php echo $user['point']; ?></span></span>
                                    <a href="<?php echo url('media/pay/pay'); ?>" class="rechargeCouponBtn">充值</a>
                                </div>
                            </div>
                            <?php 
                                $next_level_exp = $user['cumulative'] + $next_pay;
                                $per= round($user['cumulative']/$next_level_exp*100,2)
                             ?>
                            <div class="progressLevelBox">
                                <i class="levelIocn"></i>
                                <span class="levelVipNum">VIP<span><?php echo $user['vip_level']; ?></span></span>
                                <span class="progressLineLevel">
                                    <span class="progressColorLine"style="width:<?php echo $per; ?>%"></span>
                                </span>
                                <!-- 等级弹窗 -->
                                <div class="checkLevelModal">
                                    <p class="showLevelGrade">
                                        <span>VIP等级：</span><span class="defferentLevelColor">VIP<?php echo $user['vip_level']; ?></span><span class="grayTextSmall">&nbsp;(<?php echo $user['cumulative']; ?>\<?php echo $next_level_exp; ?>)</span>
                                    </p>
                                    <?php if($next_pay !== false): ?>
                                        <p class="tipUpGradeNum">再消费<span><?php echo $next_pay; ?></span>即可升级</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="botttomRecommend">
                                <p class="playCurrently">最近玩过</p>
                                <div class="playGameNameGroup">
                                    <ul>
                                        <?php if(is_array($play_game) || $play_game instanceof \think\Collection || $play_game instanceof \think\Paginator): $i = 0; $__LIST__ = $play_game;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if($vo['sdk_version'] == 3): ?>
                                                <li class="gameName-item">
                                                    <a href="<?php echo url('media/game/open_game',['game_id'=>$vo['relation_game_id']]); ?>" class="itemNameShow"><?php echo (isset($vo['game_name']) && ($vo['game_name'] !== '')?$vo['game_name']:''); ?></a>
<!--                                                    <a href="javaScript:;" class="itemNameShow textCenterShow"></a>-->
                                                    <a href="<?php echo url('media/game/open_game',['game_id'=>$vo['relation_game_id']]); ?>" class="itemNameShow textCenterShow grayStartGame">[开始游戏]</a>
                                                </li>
                                            <?php elseif($vo['sdk_version'] == 4): ?>
                                                <li class="gameName-item">
                                                    <a href="<?php echo url('media/game/ydetail',['game_id'=>$vo['relation_game_id']]); ?>" class="itemNameShow"><?php echo (isset($vo['game_name']) && ($vo['game_name'] !== '')?$vo['game_name']:''); ?></a>
<!--                                                    <a href="javaScript:;" class="itemNameShow textCenterShow"></a>-->
                                                    <a href="<?php echo url('media/game/ydetail',['game_id'=>$vo['relation_game_id']]); ?>" class="itemNameShow textCenterShow grayStartGame">[开始游戏]</a>
                                                </li>
                                            <?php else: ?>
                                                <li class="gameName-item">
                                                    <a href="<?php echo url('media/game/detail',['game_id'=>$vo['relation_game_id']]); ?>" class="itemNameShow"><?php echo (isset($vo['game_name']) && ($vo['game_name'] !== '')?$vo['game_name']:''); ?></a>
<!--                                                    <a href="javaScript:;" class="itemNameShow textCenterShow"></a>-->
                                                    <a href="<?php echo url('media/game/detail',['game_id'=>$vo['relation_game_id']]); ?>" class="itemNameShow textCenterShow grayStartGame">[开始游戏]</a>
                                                </li>
                                            <?php endif; endforeach; endif; else: echo "" ;endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </if>
		<div class="">
		</div>

    </div>
    <?php $promote_id = MEDIA_PID; ?>
    <!-- 页面固定显示 -->
	<?php if($recommend_game_sy or $recommend_game_h5 or $recommend_game_pc): ?>
    <div class="recommend-sy">
	    <div class="layui-container">
		<ul class="recommend-menu media_02" id="media_02">
            <?php if(PERMI != 1 and PERMI > 0 and $recommend_game_h5): ?>
                <li id="h5_02" <?php if($first_show_num == 2): ?>class="recommend-menu-con media_02_<?php echo $h5_sort; ?> recommend-menu-active"<?php else: ?>class="recommend-menu-con media_02_<?php echo $h5_sort; ?>"<?php endif; ?>>
                    <span class="recommend-menu-all">H5游戏</span>
                    <span class="recommend-menu-part">H5</span>
                </li>
            <?php endif; if(PERMI != 2 and PERMI > 0 and $recommend_game_sy): ?>
		        <li id="sy_02" <?php if($first_show_num == 1): ?>class="recommend-menu-con media_02_<?php echo $sy_sort; ?> recommend-menu-active"<?php else: ?>class="recommend-menu-con media_02_<?php echo $sy_sort; ?>"<?php endif; ?>>
                    <span class="recommend-menu-all">手机游戏</span>
                    <span class="recommend-menu-part">手游</span>
                </li>
            <?php endif; if(YPERMI == 1 and $recommend_game_pc): ?>
                <li id="yy_02" <?php if($first_show_num == 3): ?>class="recommend-menu-con media_02_<?php echo $yy_sort; ?> recommend-menu-active"<?php else: ?>class="recommend-menu-con media_02_<?php echo $yy_sort; ?>"<?php endif; ?>>
                    <span class="recommend-menu-all">页游游戏</span>
                    <span class="recommend-menu-part">页游</span>
                </li>
            <?php endif; ?>
        </ul>
		<div>
        <?php if(PERMI != 1 and PERMI > 0  and $recommend_game_h5): ?>
            <div <?php if($first_show_num == 2): ?>class="recommend-con js_tab_show"<?php else: ?>class="recommend-con"<?php endif; ?>>
                <ul >
                    <?php if(is_array($recommend_game_h5) || $recommend_game_h5 instanceof \think\Collection || $recommend_game_h5 instanceof \think\Paginator): $i = 0; $__LIST__ = $recommend_game_h5;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <li class="fl recommend-sy-con js-h5Link">
                            <a data-href="<?php echo url('Game/hdetail',['game_id'=>$vo['id']]); ?>" class="aLinkHref"><img src="<?php echo cmf_get_image_url($vo['cover']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" ></a>
                            <div class=" recommend-sy-gamebox">
                               <div class="recommend-sy-gamebox-name"><?php echo $vo['game_name']; ?></div>
                               <div class="recommend-sy-gamebox-mark">
                                 <div class="fl"><?php echo $vo['game_type_name']; ?></div>
                                   <div class="fg"><?php echo get_simple_number($vo['dow_num']); ?>人在玩</div>
                               </div>
                            </div>
                            <div class="bannerBox">
                                <div class="banner-recommendBox">
                                    <div class="recommendBox-item">
                                        <img src="<?php echo $vo['qrcode']; ?>">
                                        <p class="itemText">手机扫码去玩</p>
                                    </div>
                                    <ul class="recommendBtn">
                                        <li class="goToPlay"><a href="<?php echo url('Game/open_game'); ?>?game_id=<?php echo $vo['id']; ?>">一键去玩</a><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_rghit.png" /></li>
                                        <?php if(get_weiduan_down_status($vo['relation_game_id'],1,MEDIA_PID)): ?>
                                        <li class="goToPlay otherColor">
                                            <a download=""  class="down_game" href="javascript:;" down-id="<?php echo $vo['relation_game_id']; ?>" promote_id="<?php echo $promote_id; ?>" down-version="3" down-url="<?php echo url('Downfile/weiduan_down',['game_id'=>$vo['relation_game_id'],'sdk_version'=>1,'promote_id'=>$promote_id]); ?>">下载微端包</a>
                                            <image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_download.png" />
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                            <div class="recommend-sy-btnbox">
                                <a href="<?php echo url('Game/hdetail',['game_id'=>$vo['id']]); ?>" class="recommend-sy-btn fl" ><img src="/themes/simpleboot3/mediapublic/assets/images/icon_game.png" class="recommend-sy-btn-icon">游戏官网</a>
                                <div class="fl recommend-sy-line">|</div>
                                <a href="<?php echo url('Game/hdetail',['game_id'=>$vo['id']]); ?>" class="recommend-sy-btn fl"><img src="/themes/simpleboot3/mediapublic/assets/images/icon_gift.png" class="">领取礼包</a>
                            </div>
                        </li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
                <div class="clear"></div>
                <a href="<?php echo url('Game/game_hcenter'); ?>" class="recommend-sy-more">更多</a>
            </div>
        <?php endif; if(PERMI != 2 and PERMI > 0  and $recommend_game_sy): ?>
		<div <?php if($first_show_num == 1): ?>class="recommend-con js_tab_show"<?php else: ?>class="recommend-con"<?php endif; ?>>
			<ul >
				<?php if(is_array($recommend_game_sy) || $recommend_game_sy instanceof \think\Collection || $recommend_game_sy instanceof \think\Paginator): $i = 0; $__LIST__ = $recommend_game_sy;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			    <li class="fl recommend-sy-con js-yeLink">
				    <a data-href="<?php echo url('Game/detail',['game_id'=>$vo['id']]); ?>" class="aYeHref"><img src="<?php echo cmf_get_image_url($vo['cover']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" ></a>
					<div class=" recommend-sy-gamebox">
					   <div class="recommend-sy-gamebox-name"><?php echo $vo['game_name']; ?></div>
					   <div class="recommend-sy-gamebox-mark">
					     <div class="fl"><?php echo $vo['game_type_name']; ?></div>
                           <div class="fg"><?php if($vo['down_port'] == '1'): ?><?php echo $vo['game_size']; else: ?><?php echo $vo['game_address_size']; ?>MB<?php endif; ?></div>
                       </div>
                    </div>
                    <div class="bannerBox">
                        <div class="banner-recommendBox">
                            <div class="recommendBox-item">
                                <img src="<?php echo $vo['qrcode']; ?>">
                                <p class="itemText">手机扫码下载</p>
                            </div>
                            <ul class="recommendBtn">
                                <?php if(get_down_status2($vo['relation_game_id'],1)): ?>
<!--                                    <li class="androidDown "><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_android.png" /><a download="" <?php if($session['login_auth'] == 0): ?>class="login"<?php else: ?>href="<?php echo url('Downfile/down',['game_id'=>$vo['relation_game_id'],'sdk_version'=>1]); ?>"<?php endif; ?>>安卓版下载</a></li>-->
                                    <li class="androidDown "><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_android.png" /><a download="" class="down_game" href="javascript:;" down-id="<?php echo $vo['relation_game_id']; ?>" down-version="1" down-url="<?php echo url('Downfile/down',['game_id'=>$vo['relation_game_id'],'sdk_version'=>1]); ?>">安卓版下载</a></li>
                                <?php else: ?>
                                    <!--<li class="androidDown grayDown js-phoneDown"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_android.png" /><a class="disabled" href="javaScript:;">安卓版下载</a></li>-->
                                <?php endif; if(get_down_status2($vo['relation_game_id'],2)): ?>
<!--                                    <li class="androidDown appleDown"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_apple.png" /><a <?php if($session['login_auth'] == 0): ?>class="login"<?php else: ?>href="<?php echo url('Downfile/down',['game_id'=>$vo['relation_game_id'],'sdk_version'=>2]); ?>"<?php endif; ?>>苹果版下载</a></li>-->
                                    <li class="androidDown appleDown"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_apple.png" /><a class="down_game" href="javascript:;" down-id="<?php echo $vo['relation_game_id']; ?>" down-version="2" down-url="<?php echo url('Downfile/down',['game_id'=>$vo['relation_game_id'],'sdk_version'=>2]); ?>">苹果版下载</a></li>
                                <?php else: ?>
                                    <!--<li class="androidDown appleDown grayDown js-phoneDown"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_apple.png" /><a class="disabled" href="javaScript:;">苹果版下载</a></li>-->
                                <?php endif; ?>

                            </ul>
                        </div>
                    </div>
					<div class="recommend-sy-btnbox">
					    <a href="<?php echo url('Game/detail',['game_id'=>$vo['id']]); ?>" class="recommend-sy-btn fl" ><img src="/themes/simpleboot3/mediapublic/assets/images/icon_game.png" class="recommend-sy-btn-icon">游戏官网</a>
						<div class="fl recommend-sy-line">|</div>
						<a href="<?php echo url('Game/detail',['game_id'=>$vo['id']]); ?>" class="recommend-sy-btn fl"><img src="/themes/simpleboot3/mediapublic/assets/images/icon_gift.png" class="">领取礼包</a>
					</div>
				</li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
			<div class="clear"></div>
			<a href="<?php echo url('Game/game_center'); ?>" class="recommend-sy-more">更多</a>
		</div>
        <?php endif; if(YPERMI == 1 and $recommend_game_pc): ?>
		<div <?php if($first_show_num == 3): ?>class="recommend-con js_tab_show"<?php else: ?>class="recommend-con"<?php endif; ?> >
		    <ul >
				<?php if(is_array($recommend_game_pc) || $recommend_game_pc instanceof \think\Collection || $recommend_game_pc instanceof \think\Paginator): $i = 0; $__LIST__ = $recommend_game_pc;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			    <li class="fl recommend-sy-con">
				    <a href="<?php echo url('Game/ydetail',['game_id'=>$vo['id']]); ?>"><img src="<?php echo cmf_get_image_url($vo['cover']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" ></a>
					<div class=" recommend-sy-gamebox">
					   <div class="recommend-sy-gamebox-name"><?php echo $vo['game_name']; ?></div>
					   <div class="recommend-sy-gamebox-mark">
					        <div class="fl"><?php echo $vo['game_type_name']; ?></div>
                           <div class="fg"><?php echo get_simple_number($vo['dow_num']); ?>人在玩</div>
                       </div>
					</div>
					<div class="recommend-sy-btnbox">
					    <a href="<?php echo url('Game/ydetail',['game_id'=>$vo['id']]); ?>" class="recommend-sy-btn fl" ><img src="/themes/simpleboot3/mediapublic/assets/images/icon_game.png" class="recommend-sy-btn-icon">游戏官网</a>
						<div class="fl recommend-sy-line">|</div>
						<a href="<?php echo url('Game/ydetail',['game_id'=>$vo['id']]); ?>" class="recommend-sy-btn fl"><img src="/themes/simpleboot3/mediapublic/assets/images/icon_gift.png" class="">领取礼包</a>
					</div>
				</li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
			<div class="clear"></div>
			<a href="<?php echo url('Game/game_ycenter'); ?>" class="recommend-sy-more">更多</a>
		</div>
        <?php endif; ?>
	    </div>
		</div>
	</div>
	<?php endif; ?>
	<div class="clear"></div>
    <?php if($sy_hot_game or $h5_hot_game or $pc_hot_game): ?>
   <div class="hot">
      <div class="hot-menu">
        <div style="width: 100%; position: relative;left: 732px;margin-top: -15px;margin-bottom: 68px;">
            <?php if(PERMI != 1 and PERMI > 0  and $h5_hot_game): ?>
                <!-- <a class="hot-menu-con con_01 hot-menu-con-active">H5游戏</a> -->
            <a <?php if($first_show_num == 2): ?>class="hot-menu-con con_0<?php echo $h5_sort; ?> hot-menu-con-active"<?php else: ?>class="hot-menu-con con_0<?php echo $h5_sort; ?>"<?php endif; ?>>H5游戏</a>

            <?php endif; if(PERMI != 2 and PERMI > 0  and $sy_hot_game): ?>
            <!-- <a  class="hot-menu-con con_03">手机游戏</a> -->
            <a  <?php if($first_show_num == 1): ?>class="hot-menu-con con_0<?php echo $sy_sort; ?> hot-menu-con-active"<?php else: ?>class="hot-menu-con con_0<?php echo $sy_sort; ?>"<?php endif; ?>>手机游戏</a>

            <?php endif; if(YPERMI == 1 and $pc_hot_game): ?>
            <!-- <a class="hot-menu-con con_02">网页游戏</a> -->
            <a <?php if($first_show_num == 3): ?>class="hot-menu-con con_0<?php echo $yy_sort; ?> hot-menu-con-active"<?php else: ?>class="hot-menu-con con_0<?php echo $yy_sort; ?>"<?php endif; ?>>网页游戏</a>

            <?php endif; ?>
      </div>

	  </div>
         <!-- H5游戏 -->
         <?php if(PERMI != 1 and PERMI > 0 and $h5_hot_game): ?>
		  <div <?php if($first_show_num == 2): ?>class="hot-con js_tab_show"<?php else: ?>class="hot-con"<?php endif; ?>>
		     <ul class="layui-container">
				 <?php if(is_array($h5_hot_game) || $h5_hot_game instanceof \think\Collection || $h5_hot_game instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($h5_hot_game) ? array_slice($h5_hot_game,0,3, true) : $h5_hot_game->slice(0,3, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
					 <li class="hot-regame fl js-h5BottomLink">
                        <div data-href="<?php echo url('Game/hdetail',['game_id'=>$vo['id']]); ?>" class="hot-regame-link newH5Link"><img src="<?php echo cmf_get_image_url($vo['hot_cover']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null"  class="hot-regame-img">
						 <img  src="/themes/simpleboot3/mediapublic/assets/images/mantle.png" class="hot-regame-mantle">
						 <div class="hot-regame-box">
							 <div class="hot-regame-name"><?php echo $vo['game_name']; ?></div>
							 <div class="hot-regame-type"><?php echo $vo['game_type_name']; ?></div>
							 <div class="hot-regame-describe"><?php echo $vo['features']; ?></div>
						 </div>
						 <img src="<?php echo cmf_get_image_url($vo['icon']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" class="hot-regame-icon">

						 <!-- <div class="hot-regame-code">
							 <img src="<?php echo $vo['qrcode']; ?>" class="" >
                         </div> -->
                            <div class="showNew-regame">
                                <div class="newBox">
                                    <div class="imageBox">
                                        <img src="<?php echo $vo['qrcode']; ?>">
                                        <p class="phoneText">手机扫码去玩</p>
                                    </div>
                                    <ul class="boxContent">
                                        <li class="textContent"><a href="<?php echo url('Game/open_game'); ?>?game_id=<?php echo $vo['id']; ?>">一键去玩</a><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_rghit.png" class="rightIcon"/></li>
                                        <?php if(get_weiduan_down_status($vo['relation_game_id'],1,MEDIA_PID)): ?>
                                        <li class="downText">
                                            <a download="" class="down_game" href="javascript:;" down-id="<?php echo $vo['relation_game_id']; ?>" promote_id="<?php echo $promote_id; ?>" down-version="3" down-url="<?php echo url('Downfile/weiduan_down',['game_id'=>$vo['relation_game_id'],'sdk_version'=>1,'promote_id'=>$promote_id]); ?>">下载微端包</a>
                                            <image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_download.png"  class="downLoadIcon" />
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
						</div>
					 </li>
				 <?php endforeach; endif; else: echo "" ;endif; ?>
		 	</ul>
		 <div class="clear"></div>
		    <ul class="layui-container">
				<?php if(is_array($h5_hot_game) || $h5_hot_game instanceof \think\Collection || $h5_hot_game instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($h5_hot_game) ? array_slice($h5_hot_game,3,null, true) : $h5_hot_game->slice(3,null, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
					<li class="hot-regame-item js-H5Item fl">
						<a data-href="<?php echo url('Game/hdetail',['game_id'=>$vo['id']]); ?>" class="hot-regame-item-link itemToLink"><img src="<?php echo cmf_get_image_url($vo['icon']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" class="fl hot-regame-item-gameicon"></a>
						<div class="fl">
							<div class="hot-regame-item-name"><?php echo $vo['game_name']; ?></div>
							<div class="hot-regame-item-type"><?php echo $vo['game_type_name']; ?></div>
							<div class="hot-regame-item-edition" >
                                <img src="/static/images/content_icon_h5.png" alt="" class="">
                            </div>
                            <div class="newHot-regame">
                                <div class="hotRegameBox">
                                    <div class="hotImageBox">
                                        <img src="<?php echo $vo['qrcode']; ?>">
                                    </div>
                                    <ul class="hotBoxContent">
                                        <li class="hotText"><a href="<?php echo url('Game/open_game'); ?>?game_id=<?php echo $vo['id']; ?>">一键去玩</a><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_rghit.png" class="rightIcon"/></li>
                                        <?php if(get_weiduan_down_status($vo['relation_game_id'],1,MEDIA_PID)): ?>
                                        <li class="downHotText">
                                            <a download="" class="down_game" href="javascript:;" down-id="<?php echo $vo['relation_game_id']; ?>" promote_id="<?php echo $promote_id; ?>" down-version="3" down-url="<?php echo url('Downfile/weiduan_down',['game_id'=>$vo['relation_game_id'],'sdk_version'=>1,'promote_id'=>$promote_id]); ?>">下载微端包</a>
                                            <image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_download.png"  class="HotdownLoadIcon" />
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                           </div>
							<div class="hot-regame-item-buttons">
								<a href="<?php echo url('Game/hdetail',['game_id'=>$vo['id']]); ?>" class="hot-regame-item-btnagin fl">
									游戏官网
								</a>
								<a href="<?php echo url('Game/hdetail',['game_id'=>$vo['id']]); ?>" class="hot-regame-item-btngift fl">
									领取礼包
								</a>
                            </div>
                        </div>
					</li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
			<div class="clear"></div>
			<a href="<?php echo url('Game/game_hcenter'); ?>" class="recommend-sy-more">更多</a>
		 </div>
         <?php endif; ?>

         <!-- 手机游戏 -->
         <?php if(PERMI != 2 and PERMI > 0 and $sy_hot_game): ?>
            <div id="sy_05"  <?php if($first_show_num == 1): ?>class="hot-con js_tab_show"<?php else: ?>class="hot-con"<?php endif; ?>>
              <ul class="layui-container">
              <?php if(is_array($sy_hot_game) || $sy_hot_game instanceof \think\Collection || $sy_hot_game instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($sy_hot_game) ? array_slice($sy_hot_game,0,3, true) : $sy_hot_game->slice(0,3, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
               <li class="hot-regame fl js-phoneBottomLink">
                   <div data-href="<?php echo url('Game/detail',['game_id'=>$vo['id']]); ?>" class="hot-regame-link aPhoneItem">
                       <img src="<?php echo cmf_get_image_url($vo['hot_cover']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null"  class="hot-regame-img">
                   <img  src="c/mantle.png" class="hot-regame-mantle">
                   <div class="hot-regame-box">
                      <div class="hot-regame-name"><?php echo $vo['game_name']; ?></div>
                      <div class="hot-regame-type"><?php echo $vo['game_type_name']; ?></div>
                      <div class="hot-regame-describe"><?php echo $vo['features']; ?></div>
                   </div>
                   <img src="<?php echo cmf_get_image_url($vo['icon']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" class="hot-regame-icon">
                   <!-- <div class="hot-regame-code">
                       <img src="<?php echo $vo['qrcode']; ?>">
                   </div> -->
                    <div class="showNew-regame">
                        <div class="newBox">
                            <div class="imageBox">
                                <img src="<?php echo $vo['qrcode']; ?>">
                                <p class="phoneText">手机扫码下载</p>
                            </div>
                            <ul class="boxContent">
                                <?php if(get_down_status2($vo['relation_game_id'],1)): ?>
                                    <li class="androidText"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_android.png" /><a download="" class="down_game" href="javascript:;" down-id="<?php echo $vo['relation_game_id']; ?>" down-version="1" down-url="<?php echo url('Downfile/down',['game_id'=>$vo['relation_game_id'],'sdk_version'=>1]); ?>">安卓版下载</a></li>
                                <?php else: ?>
                                    <!--<li class="androidText grayDown js-downLoad"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_android.png" /><a class="disabled " href="javaScript:;">安卓版下载</a></li>-->
                                <?php endif; if(get_down_status2($vo['relation_game_id'],2)): ?>
                                        <li class="androidText appleText"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_apple.png" /><a class="down_game" href="javascript:;" down-id="<?php echo $vo['relation_game_id']; ?>" down-version="2" down-url="<?php echo url('Downfile/down',['game_id'=>$vo['relation_game_id'],'sdk_version'=>2]); ?>">苹果版下载</a></li>
                                    <?php else: ?>
                                        <!--<li class="androidText appleText grayDown js-downLoad"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_apple.png" /><a class="disabled" href="javaScript:;">苹果版下载</a></li>-->
                                    <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
               </li>
              <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <div class="clear"></div>
               <ul class="layui-container">
                   <?php if(is_array($sy_hot_game) || $sy_hot_game instanceof \think\Collection || $sy_hot_game instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($sy_hot_game) ? array_slice($sy_hot_game,3,null, true) : $sy_hot_game->slice(3,null, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                  <li class="hot-regame-item fl js-phoneItem">
                      <a data-href="<?php echo url('Game/detail',['game_id'=>$vo['id']]); ?>" class="hot-regame-item-link aItemPhone"><img src="<?php echo cmf_get_image_url($vo['icon']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" class="fl hot-regame-item-gameicon"></a>
                      <div class="fl">
                           <a href="<?php echo url('Game/detail',['game_id'=>$vo['id']]); ?>"><div class="hot-regame-item-name"><?php echo $vo['game_name']; ?></div></a>
                           <div class="hot-regame-item-type"><?php echo $vo['game_type_name']; ?></div>
                            <div class="hot-regame-item-edition" >
                                <?php switch($vo['sdk_count']): case "2": ?>
                                        <img src="/themes/simpleboot3/mediapublic/assets/images/icon_andriod.png">
                                        <img src="/themes/simpleboot3/mediapublic/assets/images/icon_ios.png">
                                    <?php break; case "1": if($vo['sdk_version'] == '1'): ?>
                                            <img src="/themes/simpleboot3/mediapublic/assets/images/icon_andriod.png">
                                            <?php else: ?>
                                            <img src="/themes/simpleboot3/mediapublic/assets/images/icon_ios.png">
                                        <?php endif; break; endswitch; ?>
                            </div>
                            <div class="hot-regame-item-buttons">
                                <a href="<?php echo url('Game/detail',['game_id'=>$vo['id']]); ?>" class="hot-regame-item-btnagin fl">
                                    下载游戏
                                </a>
                                <a href="<?php echo url('Game/detail',['game_id'=>$vo['id']]); ?>" class="hot-regame-item-btngift fl">
                                    领取礼包
                                </a>
                            </div>
                            <div class="newHot-regame">
                                <div class="hotRegameBox">
                                    <div class="hotImageBox">
                                        <img src="<?php echo $vo['qrcode']; ?>">
                                    </div>
                                    <ul class="hotBoxContent">
                                        <?php if(get_down_status2($vo['relation_game_id'],1)): ?>
                                            <li class="hotAndriodText"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_android.png" /><a download="" class="down_game" href="javascript:;" down-id="<?php echo $vo['relation_game_id']; ?>" down-version="1" down-url="<?php echo url('Downfile/down',['game_id'=>$vo['relation_game_id'],'sdk_version'=>1]); ?>">安卓版下载</a></li>
                                            <?php else: ?>
                                            <!--<li class="hotAndriodText grayDown js-downLoad"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_android.png" /><a class="disabled" href="javaScript:;">安卓版下载</a></li>-->
                                        <?php endif; if(get_down_status2($vo['relation_game_id'],2)): ?>
                                            <li class="hotAndriodText hotAppleText"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_apple.png" /><a class="down_game" href="javascript:;" down-id="<?php echo $vo['relation_game_id']; ?>" down-version="2" down-url="<?php echo url('Downfile/down',['game_id'=>$vo['relation_game_id'],'sdk_version'=>2]); ?>">苹果版下载</a></li>
                                            <?php else: ?>
                                            <!--<li class="hotAndriodText hotAppleText grayDown js-downLoad"><image src="/themes/simpleboot3/mediapublic/assets/images/btn_icon_apple.png" /><a class="disabled" href="javaScript:;">苹果版下载</a></li>-->
                                        <?php endif; ?>
                                    </ul>
                                </div>
                           </div>
                      </div>
                  </li>
                   <?php endforeach; endif; else: echo "" ;endif; ?>
               </ul>
               <div class="clear"></div>
               <a href="<?php echo url('Game/game_center'); ?>" class="recommend-sy-more">更多</a>
            </div>
            <?php endif; ?>

            <!-- 网页游戏 -->
         <?php if(YPERMI == 1 and $pc_hot_game): ?>
             <div id="yy_05" <?php if($first_show_num == 3): ?>class="hot-con js_tab_show"<?php else: ?>class="hot-con"<?php endif; ?>>
                 <ul class="layui-container">
                     <?php if(is_array($pc_hot_game) || $pc_hot_game instanceof \think\Collection || $pc_hot_game instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($pc_hot_game) ? array_slice($pc_hot_game,0,3, true) : $pc_hot_game->slice(0,3, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                         <li class="hot-regame fl">
                             <a href="<?php echo url('Game/ydetail',['game_id'=>$vo['id']]); ?>" class="hot-regame-link"><img src="<?php echo cmf_get_image_url($vo['hot_cover']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null"  class="hot-regame-img">
                                 <img  src="/themes/simpleboot3/mediapublic/assets/images/mantle.png" class="hot-regame-mantle">
                                 <div class="hot-regame-box">
                                     <div class="hot-regame-name"><?php echo $vo['game_name']; ?></div>
                                     <div class="hot-regame-type"><?php echo $vo['game_type_name']; ?></div>
                                     <div class="hot-regame-describe"><?php echo $vo['features']; ?></div>
                                 </div>
                                 <img src="<?php echo cmf_get_image_url($vo['icon']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" class="hot-regame-icon">

                                 <div class="hot-regame-code">
                                     <img src="<?php echo cmf_get_image_url($vo['icon']); ?>" class="" >
                                 </div>
                             </a>
                         </li>
                     <?php endforeach; endif; else: echo "" ;endif; ?>
                 </ul>
                 <div class="clear"></div>
                 <ul class="layui-container">
                     <?php if(is_array($pc_hot_game) || $pc_hot_game instanceof \think\Collection || $pc_hot_game instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($pc_hot_game) ? array_slice($pc_hot_game,3,null, true) : $pc_hot_game->slice(3,null, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                         <li class="hot-regame-item fl">
                             <a href="<?php echo url('Game/ydetail',['game_id'=>$vo['id']]); ?>" class="hot-regame-item-link"><img src="<?php echo cmf_get_image_url($vo['icon']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" class="fl hot-regame-item-gameicon"></a>
                             <div class="fl">
                                 <div class="hot-regame-item-name"><?php echo $vo['game_name']; ?></div>
                                 <div class="hot-regame-item-type"><?php echo $vo['game_type_name']; ?></div>
                                 <div class="hot-regame-item-edition" >
                                     <img src="/themes/simpleboot3/mediapublic/assets/images/icon_pc.png">
                                 </div>
                                 <div class="hot-regame-item-buttons">
                                     <a href="<?php echo url('Game/ydetail',['game_id'=>$vo['id']]); ?>" class="hot-regame-item-btnagin fl">
                                         游戏官网
                                     </a>
                                     <a href="<?php echo url('Game/ydetail',['game_id'=>$vo['id']]); ?>" class="hot-regame-item-btngift fl">
                                         领取礼包
                                     </a>
                                 </div>
                             </div>
                         </li>
                     <?php endforeach; endif; else: echo "" ;endif; ?>
                 </ul>
                 <div class="clear"></div>
                 <a href="<?php echo url('Game/game_ycenter'); ?>" class="recommend-sy-more">更多</a>
             </div>
         <?php endif; ?>
		 </div>
	  </div>
    <?php endif; ?>
     <!-- 最新开服/热门游戏 -->
    <div class="newest">
        <div class="layui-container">
            <div class="new_open">
                <div class="bluediv"></div>
                <p class="new_open_title"><span>最新开服</span></p>
				<div class="new-server">
				    <div class="newtab_menu">
                        <?php if(PERMI != 1 and PERMI > 0): ?>
                            <span <?php if($first_show_num == 2): ?>class="newtab_menu_con fl new_<?php echo $h5_sort; ?> newtab_menu_active new_num_<?php echo $total_num; ?>"<?php else: ?>class="newtab_menu_con fl new_<?php echo $h5_sort; ?> new_num_<?php echo $total_num; ?>"<?php endif; ?>>H5</span>
                        <?php endif; if(PERMI != 2 and PERMI > 0): ?>
				       <span <?php if($first_show_num == 1): ?>class="newtab_menu_con fl new_<?php echo $sy_sort; ?> newtab_menu_active new_num_<?php echo $total_num; ?>"<?php else: ?>class="newtab_menu_con fl new_<?php echo $sy_sort; ?> new_num_<?php echo $total_num; ?>"<?php endif; ?>>手游</span>
                        <?php endif; if(YPERMI == 1): ?>
						<span <?php if($first_show_num == 3): ?>class="newtab_menu_con fl new_<?php echo $yy_sort; ?> newtab_menu_active new_num_<?php echo $total_num; ?>"<?php else: ?>class="newtab_menu_con fl new_<?php echo $yy_sort; ?> new_num_<?php echo $total_num; ?>"<?php endif; ?>>页游</span>
                        <?php endif; ?>
				    </div>
				<div class="clear"></div>
              <div>
                  <?php if(PERMI != 1 and PERMI > 0): ?>
                      <div <?php if($first_show_num == 2): ?>class="new-open-server js_tab_show"<?php else: ?>class="new-open-server"<?php endif; ?>>
                          <ul class="tab-menu">
                              <li class="tab-menu-con tab-menu-active">今日开服</li>
                              <li class="tab-menu-con ">即将开服</li>
                              <li class="tab-menu-con ">已开服</li>
                          </ul>
                          <div class="new_open_con js_tab_show">
                              <div class="new_open_padding">
                                  <!-- 有开服信息时显示 -->
                                  <div class="layui-carousel new_open_fw" id="test6" lay-filter="test7">
                                      <div carousel-item="">
                                          <?php if(is_array($h5_server['today']) || $h5_server['today'] instanceof \think\Collection || $h5_server['today'] instanceof \think\Paginator): $i = 0; $__LIST__ = $h5_server['today'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                              <div>
                                                  <table border="0" class="new_opem_table">

                                                      <tr class="new_open_table_first_tr">
                                                          <td class="new_open_table_first_td">游戏名称</td>
                                                          <td class="new_open_table_two_td"><span style="">区服</span></td>
                                                          <td class="textcenter">时间</td>
                                                      </tr>
                                                      <?php if(is_array($vo) || $vo instanceof \think\Collection || $vo instanceof \think\Paginator): $i = 0; $__LIST__ = $vo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                                          <tr class="new_open_table_other_tr">
                                                              <td class="new_open_table_first_td"> <a href="<?php echo url('Game/hdetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['game_name']; ?></p></a>
                                                              </td>
                                                              <td class="new_open_table_two_td con"><a href="<?php echo url('Game/hdetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['server_name']; ?></p></a>
                                                              </td>
                                                              <td class="open-date"><a href="<?php echo url('Game/hdetail',['game_id'=>$v['relation_game_id']]); ?>"><?php echo date('m-d H:i',$v['start_time']); ?></a></td>
                                                          </tr>
                                                      <?php endforeach; endif; else: echo "" ;endif; ?>
                                                  </table>
                                              </div>
                                          <?php endforeach; endif; else: echo "" ;endif; if(empty($h5_server['today']) || (($h5_server['today'] instanceof \think\Collection || $h5_server['today'] instanceof \think\Paginator ) && $h5_server['today']->isEmpty())): ?>
                                              <div class="no_qufu_text">暂无区服</div>
                                          <?php endif; ?>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="new_open_con">
                              <div class="new_open_padding">
                                  <!-- 有开服信息时显示 -->
                                  <div class="layui-carousel new_open_fw" id="test7" lay-filter="test8">
                                      <div carousel-item="">
                                          <?php if(is_array($h5_server['tomorrow']) || $h5_server['tomorrow'] instanceof \think\Collection || $h5_server['tomorrow'] instanceof \think\Paginator): $i = 0; $__LIST__ = $h5_server['tomorrow'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                              <div>
                                                  <table border="0" class="new_opem_table">
                                                      <tr class="new_open_table_first_tr">
                                                          <td class="new_open_table_first_td">游戏名称</td>
                                                          <td class="new_open_table_two_td"><span style="">区服</span></td>
                                                          <td class="textcenter">时间</td>
                                                      </tr>
                                                      <?php if(is_array($vo) || $vo instanceof \think\Collection || $vo instanceof \think\Paginator): $i = 0; $__LIST__ = $vo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                                          <tr class="new_open_table_other_tr">
                                                              <td class="new_open_table_first_td"> <a href="<?php echo url('Game/hdetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['game_name']; ?></p></a>
                                                              </td>
                                                              <td class="new_open_table_two_td con"><a href="<?php echo url('Game/hdetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['server_name']; ?></p></a>
                                                              </td>
                                                              <td class="open-date"><a href="<?php echo url('Game/hdetail',['game_id'=>$v['relation_game_id']]); ?>"><?php echo date('m-d H:i',$v['start_time']); ?></a></td>
                                                          </tr>
                                                      <?php endforeach; endif; else: echo "" ;endif; ?>
                                                  </table>
                                              </div>
                                          <?php endforeach; endif; else: echo "" ;endif; if(empty($h5_server['tomorrow']) || (($h5_server['tomorrow'] instanceof \think\Collection || $h5_server['tomorrow'] instanceof \think\Paginator ) && $h5_server['tomorrow']->isEmpty())): ?>
                                              <div class="no_qufu_text">暂无区服</div>
                                          <?php endif; ?>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="new_open_con">
                              <div class="new_open_padding">
                                  <!-- 有开服信息时显示 -->
                                  <div class="layui-carousel new_open_fw" id="test8" lay-filter="test9">
                                      <div carousel-item="">
                                          <?php if(is_array($h5_server['yestoday']) || $h5_server['yestoday'] instanceof \think\Collection || $h5_server['yestoday'] instanceof \think\Paginator): $i = 0; $__LIST__ = $h5_server['yestoday'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                              <div>
                                                  <table border="0" class="new_opem_table">
                                                      <tr class="new_open_table_first_tr">
                                                          <td class="new_open_table_first_td">游戏名称</td>
                                                          <td class="new_open_table_two_td"><span style="">区服</span></td>
                                                          <td class="textcenter">时间</td>
                                                      </tr>
                                                      <?php if(is_array($vo) || $vo instanceof \think\Collection || $vo instanceof \think\Paginator): $i = 0; $__LIST__ = $vo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                                          <tr class="new_open_table_other_tr">
                                                              <td class="new_open_table_first_td"> <a href="<?php echo url('Game/hdetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['game_name']; ?></p></a>
                                                              </td>
                                                              <td class="new_open_table_two_td con"><a href="<?php echo url('Game/hdetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['server_name']; ?></p></a>
                                                              </td>
                                                              <td class="open-date"><a href="<?php echo url('Game/hdetail',['game_id'=>$v['relation_game_id']]); ?>"><?php echo date('m-d H:i',$v['start_time']); ?></a></td>
                                                          </tr>
                                                      <?php endforeach; endif; else: echo "" ;endif; ?>
                                                  </table>
                                              </div>
                                          <?php endforeach; endif; else: echo "" ;endif; if(empty($h5_server['yestoday']) || (($h5_server['yestoday'] instanceof \think\Collection || $h5_server['yestoday'] instanceof \think\Paginator ) && $h5_server['yestoday']->isEmpty())): ?>
                                              <div class="no_qufu_text">暂无区服</div>
                                          <?php endif; ?>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  <?php endif; if(PERMI != 2 and PERMI > 0): ?>
				<div <?php if($first_show_num == 1): ?>class="new-open-server js_tab_show"<?php else: ?>class="new-open-server"<?php endif; ?>>
                    <ul class="tab-menu">
                        <li class="tab-menu-con tab-menu-active">今日开服</li>
                        <li class="tab-menu-con ">即将开服</li>
                        <li class="tab-menu-con ">已开服</li>
                    </ul>
                    <div class="new_open_con js_tab_show">
                        <div class="new_open_padding">
                            <!-- 有开服信息时显示 -->
                            <div class=" new_open_fw layui-carousel" id="test3" lay-filter="test4">
                                <div carousel-item="">
                                    <?php if(is_array($server['today']) || $server['today'] instanceof \think\Collection || $server['today'] instanceof \think\Paginator): $i = 0; $__LIST__ = $server['today'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                        <div>
                                            <table border="0" class="new_opem_table">

                                                <tr class="new_open_table_first_tr">
                                                    <td class="new_open_table_first_td">游戏名称</td>
                                                    <td class="new_open_table_two_td"><span style="">区服</span></td>
                                                    <td class="textcenter">时间</td>
                                                </tr>
                                                <?php if(is_array($vo) || $vo instanceof \think\Collection || $vo instanceof \think\Paginator): $i = 0; $__LIST__ = $vo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                                        <tr class="new_open_table_other_tr">
                                                            <td class="new_open_table_first_td"> <a href="<?php echo url('Game/detail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['game_name']; ?></p></a>
                                                            </td>
                                                            <td class="new_open_table_two_td con"><a href="<?php echo url('Game/detail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['server_name']; ?></p></a>
                                                            </td>
                                                            <td class="open-date"><a href="<?php echo url('Game/detail',['game_id'=>$v['relation_game_id']]); ?>"><?php echo date('m-d H:i',$v['start_time']); ?></a></td>
                                                        </tr>
                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                            </table>
                                        </div>
                                    <?php endforeach; endif; else: echo "" ;endif; if(empty($server['today']) || (($server['today'] instanceof \think\Collection || $server['today'] instanceof \think\Paginator ) && $server['today']->isEmpty())): ?>
                                        <div class="no_qufu_text">暂无区服</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="new_open_con">
                        <div class="new_open_padding">
                            <!-- 有开服信息时显示 -->
                            <div class=" new_open_fw layui-carousel" id="test4" lay-filter="test5">
                                <div carousel-item="">
                                    <?php if(is_array($server['tomorrow']) || $server['tomorrow'] instanceof \think\Collection || $server['tomorrow'] instanceof \think\Paginator): $i = 0; $__LIST__ = $server['tomorrow'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                        <div>
                                            <table border="0" class="new_opem_table">

                                                <tr class="new_open_table_first_tr">
                                                    <td class="new_open_table_first_td">游戏名称</td>
                                                    <td class="new_open_table_two_td"><span style="">区服</span></td>
                                                    <td class="textcenter">时间</td>
                                                </tr>
                                                <?php if(is_array($vo) || $vo instanceof \think\Collection || $vo instanceof \think\Paginator): $i = 0; $__LIST__ = $vo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                                        <tr class="new_open_table_other_tr">
                                                            <td class="new_open_table_first_td"> <a href="<?php echo url('Game/detail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['game_name']; ?></p></a>
                                                            </td>
                                                            <td class="new_open_table_two_td con"><a href="<?php echo url('Game/detail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['server_name']; ?></p></a>
                                                            </td>
                                                            <td class="open-date"><a href="<?php echo url('Game/detail',['game_id'=>$v['relation_game_id']]); ?>"><?php echo date('m-d H:i',$v['start_time']); ?></a></td>
                                                        </tr>
                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                            </table>
                                        </div>
                                    <?php endforeach; endif; else: echo "" ;endif; if(empty($server['tomorrow']) || (($server['tomorrow'] instanceof \think\Collection || $server['tomorrow'] instanceof \think\Paginator ) && $server['tomorrow']->isEmpty())): ?>
                                        <div class="no_qufu_text">暂无区服</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="new_open_con">
                        <div class="new_open_padding">
                            <!-- 有开服信息时显示 -->
                            <div class=" new_open_fw layui-carousel" id="test5" lay-filter="test6">
                                <div carousel-item="">
                                    <?php if(is_array($server['yestoday']) || $server['yestoday'] instanceof \think\Collection || $server['yestoday'] instanceof \think\Paginator): $i = 0; $__LIST__ = $server['yestoday'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                        <div>
                                            <table border="0" class="new_opem_table">
                                                <tr class="new_open_table_first_tr">
                                                    <td class="new_open_table_first_td">游戏名称</td>
                                                    <td class="new_open_table_two_td"><span style="">区服</span></td>
                                                    <td class="textcenter">时间</td>
                                                </tr>
                                                <?php if(is_array($vo) || $vo instanceof \think\Collection || $vo instanceof \think\Paginator): $i = 0; $__LIST__ = $vo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                                        <tr class="new_open_table_other_tr">
                                                            <td class="new_open_table_first_td"> <a href="<?php echo url('Game/detail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['game_name']; ?></p></a>
                                                            </td>
                                                            <td class="new_open_table_two_td con"><a href="<?php echo url('Game/detail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['server_name']; ?></p></a>
                                                            </td>
                                                            <td class="open-date"><a href="<?php echo url('Game/detail',['game_id'=>$v['relation_game_id']]); ?>"><?php echo date('m-d H:i',$v['start_time']); ?></a></td>
                                                        </tr>
                                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                            </table>
                                        </div>
                                    <?php endforeach; endif; else: echo "" ;endif; if(empty($server['yestoday']) || (($server['yestoday'] instanceof \think\Collection || $server['yestoday'] instanceof \think\Paginator ) && $server['yestoday']->isEmpty())): ?>
                                        <div class="no_qufu_text">暂无区服</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                  <?php endif; if(YPERMI == 1): ?>
                      <div <?php if($first_show_num == 3): ?>class="new-open-server js_tab_show"<?php else: ?>class="new-open-server"<?php endif; ?>>
                          <ul class="tab-menu">
                              <li class="tab-menu-con tab-menu-active">今日开服</li>
                              <li class="tab-menu-con ">即将开服</li>
                              <li class="tab-menu-con ">已开服</li>
                          </ul>
                          <div class="new_open_con js_tab_show">
                              <div class="new_open_padding">
                                  <!-- 有开服信息时显示 -->
                                  <div class=" new_open_fw layui-carousel" id="test10" lay-filter="test11">
                                      <div carousel-item="">
                                          <?php if(is_array($pc_server['today']) || $pc_server['today'] instanceof \think\Collection || $pc_server['today'] instanceof \think\Paginator): $i = 0; $__LIST__ = $pc_server['today'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                              <div>
                                                  <table border="0" class="new_opem_table">

                                                      <tr class="new_open_table_first_tr">
                                                          <td class="new_open_table_first_td">游戏名称</td>
                                                          <td class="new_open_table_two_td"><span style="">区服</span></td>
                                                          <td class="textcenter">时间</td>
                                                      </tr>
                                                      <?php if(is_array($vo) || $vo instanceof \think\Collection || $vo instanceof \think\Paginator): $i = 0; $__LIST__ = $vo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                                              <tr class="new_open_table_other_tr">
                                                                  <td class="new_open_table_first_td"> <a href="<?php echo url('Game/ydetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['game_name']; ?></p></a>
                                                                  </td>
                                                                  <td class="new_open_table_two_td con"><a href="<?php echo url('Game/ydetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['server_name']; ?></p></a>
                                                                  </td>
                                                                  <td class="open-date"><a href="<?php echo url('Game/ydetail',['game_id'=>$v['relation_game_id']]); ?>"><?php echo date('m-d H:i',$v['start_time']); ?></a></td>
                                                              </tr>
                                                      <?php endforeach; endif; else: echo "" ;endif; ?>
                                                  </table>
                                              </div>
                                          <?php endforeach; endif; else: echo "" ;endif; if(empty($pc_server['today']) || (($pc_server['today'] instanceof \think\Collection || $pc_server['today'] instanceof \think\Paginator ) && $pc_server['today']->isEmpty())): ?>
                                              <div class="no_qufu_text">暂无区服</div>
                                          <?php endif; ?>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="new_open_con">
                              <div class="new_open_padding">
                                  <!-- 有开服信息时显示 -->
                                  <div class=" new_open_fw layui-carousel" id="test11" lay-filter="test12">
                                      <div carousel-item="">
                                          <?php if(is_array($pc_server['tomorrow']) || $pc_server['tomorrow'] instanceof \think\Collection || $pc_server['tomorrow'] instanceof \think\Paginator): $i = 0; $__LIST__ = $pc_server['tomorrow'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                              <div>
                                                  <table border="0" class="new_opem_table">
                                                      <tr class="new_open_table_first_tr">
                                                          <td class="new_open_table_first_td">游戏名称</td>
                                                          <td class="new_open_table_two_td"><span style="">区服</span></td>
                                                          <td class="textcenter">时间</td>
                                                      </tr>
                                                      <?php if(is_array($vo) || $vo instanceof \think\Collection || $vo instanceof \think\Paginator): $i = 0; $__LIST__ = $vo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                                              <tr class="new_open_table_other_tr">
                                                                  <td class="new_open_table_first_td"> <a href="<?php echo url('Game/ydetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['game_name']; ?></p></a>
                                                                  </td>
                                                                  <td class="new_open_table_two_td con"><a href="<?php echo url('Game/ydetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['server_name']; ?></p></a>
                                                                  </td>
                                                                  <td class="open-date"><a href="<?php echo url('Game/ydetail',['game_id'=>$v['relation_game_id']]); ?>"><?php echo date('m-d H:i',$v['start_time']); ?></a></td>
                                                              </tr>
                                                      <?php endforeach; endif; else: echo "" ;endif; ?>
                                                  </table>
                                              </div>
                                          <?php endforeach; endif; else: echo "" ;endif; if(empty($pc_server['tomorrow']) || (($pc_server['tomorrow'] instanceof \think\Collection || $pc_server['tomorrow'] instanceof \think\Paginator ) && $pc_server['tomorrow']->isEmpty())): ?>
                                              <div class="no_qufu_text">暂无区服</div>
                                          <?php endif; ?>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="new_open_con">
                              <div class="new_open_padding">
                                  <!-- 有开服信息时显示 -->
                                  <div class=" new_open_fw layui-carousel" id="test13" lay-filter="test14">
                                      <div carousel-item="">
                                          <?php if(is_array($pc_server['yestoday']) || $pc_server['yestoday'] instanceof \think\Collection || $pc_server['yestoday'] instanceof \think\Paginator): $i = 0; $__LIST__ = $pc_server['yestoday'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                              <div>
                                                  <table border="0" class="new_opem_table">
                                                      <tr class="new_open_table_first_tr">
                                                          <td class="new_open_table_first_td">游戏名称</td>
                                                          <td class="new_open_table_two_td"><span style="">区服</span></td>
                                                          <td class="textcenter">时间</td>
                                                      </tr>
                                                      <?php if(is_array($vo) || $vo instanceof \think\Collection || $vo instanceof \think\Paginator): $i = 0; $__LIST__ = $vo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                                              <tr class="new_open_table_other_tr">
                                                                  <td class="new_open_table_first_td"> <a href="<?php echo url('Game/ydetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['game_name']; ?></p></a>
                                                                  </td>
                                                                  <td class="new_open_table_two_td con"><a href="<?php echo url('Game/ydetail',['game_id'=>$v['relation_game_id']]); ?>"><p><?php echo $v['server_name']; ?></p></a>
                                                                  </td>
                                                                  <td class="open-date"><a href="<?php echo url('Game/ydetail',['game_id'=>$v['relation_game_id']]); ?>"><?php echo date('m-d H:i',$v['start_time']); ?></a></td>
                                                              </tr>
                                                      <?php endforeach; endif; else: echo "" ;endif; ?>
                                                  </table>
                                              </div>
                                          <?php endforeach; endif; else: echo "" ;endif; if(empty($pc_server['yestoday']) || (($pc_server['yestoday'] instanceof \think\Collection || $pc_server['yestoday'] instanceof \think\Paginator ) && $pc_server['yestoday']->isEmpty())): ?>
                                              <div class="no_qufu_text">暂无区服</div>
                                          <?php endif; ?>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  <?php endif; ?>
              </div>
		   </div>
            </div>

		   <div class="hot_gift fl">
                <div class="bluediv"></div>
                <p class="hot_gift_title"><span >热门礼包</span>
                </p>
                <div class="hot_gift_con">
                    <?php if(is_array($gift) || $gift instanceof \think\Collection || $gift instanceof \think\Paginator): $i = 0; $__LIST__ = $gift;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <div class="gift_item fl">
                        <a  href="<?php echo url('Gift/detail',['gift_id'=>$vo['gift_id']]); ?>"><img src="<?php echo cmf_get_image_url($vo['icon']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null" class="gift_item_icon fl"></a>
                        <div class="fl">
                            <a  href="<?php echo url('Gift/detail',['gift_id'=>$vo['gift_id']]); ?>"> <div class="gift_item_name"><?php echo $vo['giftbag_name']; ?></div></a>
                            <div class="gift_item_text"><?php echo $vo['game_name']; ?></div>
                            <div class="gift_item_surplus">剩余<span><?php echo null_to_0($vo['remain_num']/$vo['novice_num']*100); ?>%</span></div>
                            <?php if($vo['received'] == 0): ?>
                                <div <?php if(session('member_auth') and $vo['vip'] > session('member_auth.vip_level')): ?>class="gift_item_receive receive_bag_disabled"<?php else: ?> class="gift_item_receive getgift" <?php endif; ?> data-giftbag_id="<?php echo $vo['gift_id']; ?>">领取礼包</div>
                            <?php else: ?>
                                <div class="gift_item_receive copy" data-novice="<?php echo $vo['novice']; ?>">复制</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; endif; else: echo "" ;endif; if(empty($gift) || (($gift instanceof \think\Collection || $gift instanceof \think\Paginator ) && $gift->isEmpty())): ?>
                <div class="no_bag_text">

                    <p>~暂无礼包~</p>
                 </div>
               <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
    <div class="layui-container">
	    <div class="fl top2notice" >
		    <div>
			   <div class="top2notice-con js_tab_show" ><a href="<?php echo url('Article/detail',['id'=>$huodong[0]['id']]); ?>"><img src="<?php echo cmf_get_image_url($huodong[0]['thumbnail']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null"></a></div>
                <div class="top2notice-con" ><a href="<?php echo url('Article/detail',['id'=>$huodong[1]['id']]); ?>"><img src="<?php echo cmf_get_image_url($huodong[1]['thumbnail']); ?>" onerror="this.src='/static/images/empty.jpg';this.onerror=null"></a></div>
			</div>
            <?php if(!(empty($huodong) || (($huodong instanceof \think\Collection || $huodong instanceof \think\Paginator ) && $huodong->isEmpty()))): ?>
			<div class="top2notice-text">
                <?php if(count($huodong) == 1): ?>
                    <a  class="fl top2notice-title top2notice-active"><?php echo $huodong[0]['post_title']; ?></a>
                    <?php else: ?>
                    <a class="fl top2notice-title top2notice-active"><?php echo $huodong[0]['post_title']; ?></a>
                    <a class="fl top2notice-title"><?php echo $huodong[1]['post_title']; ?></a>
                <?php endif; ?>
			</div>
            <?php endif; ?>
		</div>
		<div class="fl notice">
		    <div class="notice_menu">
			    <div class="notice_menu_con fl notice_menu_active">活动</div>
				<div class="notice_menu_con fl">公告</div>
			</div>
			<a class="notice_more" href="<?php echo url('Article/index'); ?>"><img src="/themes/simpleboot3/mediapublic/assets/images/icon_add.png" class="notice_more_icon"></a>
			<div>
			    <div class="notice_con js_tab_show">
                    <?php if($huodong[2]): ?>
				    <a href="<?php echo url('Article/detail',['id'=>$huodong[2]['id']]); ?>" class="frist_title"><?php echo $huodong[2]['post_title']; ?></a>
                    <?php endif; if(is_array($huodong) || $huodong instanceof \think\Collection || $huodong instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($huodong) ? array_slice($huodong,3,null, true) : $huodong->slice(3,null, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <a class="notice_title" href="<?php echo url('Article/detail',['id'=>$vo['id']]); ?>">
					   <span class="fl notice_figure"></span>
					   <div class="notice_text fl"><?php echo $vo['post_title']; ?></div>
					   <span class="fg notice_time"><?php echo date('m/d',$vo['update_time']); ?></span>
					</a>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
				</div>
				 <div class="notice_con">
                     <?php if($article[0]): ?>
				        <a href="<?php echo url('Article/detail',['id'=>$article[0]['id']]); ?>" class="frist_title"><?php echo $article[0]['post_title']; ?></a>
                     <?php endif; if(is_array($article) || $article instanceof \think\Collection || $article instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($article) ? array_slice($article,1,null, true) : $article->slice(1,null, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                     <a class="notice_title" href="<?php echo url('Article/detail',['id'=>$vo['id']]); ?>">
					   <span class="fl notice_figure"></span>
					   <div class="notice_text fl"><?php echo $vo['post_title']; ?></div>
					   <span class="fg notice_time"><?php echo date('m/d',$vo['update_time']); ?></span>
					</a>
                     <?php endforeach; endif; else: echo "" ;endif; ?>
				</div>
			</div>
		</div>
	</div>
	<div class="clear"></div>
	<!-- 复制礼包窗口 -->
    <div class="receive_bag_modal">
        <div class="receive_bag_modal_header">
            <span>礼包领取成功</span>
            <span class="close_receive_bag_modal"><img src="/static/images/delete_icon.png" alt=""></span>
        </div>
        <div class="receive_bag_modal_con">
            <p class="receive_bag_modal_firstline">
                <span class="colblack">激活码 : </span>
                <input type="text" id="novice" class="fasfegxv" value="">
            </p>
            <p class="receive_bag_modal_secondline">
                <span>可在[<a href="<?php echo url('User/mygift'); ?>">我的礼包</a>]中查看</span>
            </p>
            <div class="">
                <button data-novice="" class="copy1 receive_bag_modal_thirdline">复制</button>
            </div>
        </div>
    </div>
 </div>
    </body>

    <script>
        $(function () {
            $(".down_game").click(function () {
                var down_url = $(this).attr('down-url');
                var down_id = $(this).attr('down-id');
                var down_version = $(this).attr('down-version');
                var promote_id = $(this).attr('down-promote_id');
                //请求

                $.ajax({
                    url: "<?php echo url('Downfile/get_ban_status'); ?>",
                    type: 'post',
                    dataType: 'json',
                    data: {game_id: down_id,type:4,sdk_version:down_version,promote_id:promote_id},
                    success: function (res) {
                        if (res.code != 1) {
                            layer.msg(res.msg);
                        } else {

                            location.href = down_url;
                        }
                    }, error() {
                        layer.msg('服务器错误');
                    }
                })
            })
        })
    </script>
    <script>
        // 点击等级弹窗x图标，弹窗隐藏
        $('.removeModal').click(function() {
            $('.levelInfo_modal').css('display','none')
        })
        // 用户状态
        window.login_auth = 0;
        $.ajax({
            type:'get',
            url:'<?php echo url("get_user_status"); ?>',
            async:false,
            success:function (res) {
                if(res.status!=0){
                    window.login_auth = 1;
                    //登录框
                    $('.login_modal').addClass('hide').removeClass('show');
                    if($('.login_modal').hasClass('hide')) {
                       $('.levelInfo_modal').css('display','block')
                    }
                    //免费注册
                    mfzz = '<a href="';
                    mfzz += '<?php echo url("User/userinfo"); ?>';
                    mfzz += '">';
                    mfzz += '<div><img src="/static/images/reg.png" alt=""><p class="sale_item_title">免费注册</p></div></a>';
                    $('.js_mfzz').empty().append(mfzz);
                    //实名认证
                    smrz = '<a href="<?php echo url('User/realauth'); ?>">\n' +
                        '<div>\n' +
                        '<img src="/static/images/yes.png" alt="">\n' +
                        '<p class="sale_item_title">实名认证</p>\n' +
                        '</div>\n' +
                        '</a>';
                    $('.js_smrz').empty().append(smrz);
                    //游戏账单
                    yxzd = '<a href="<?php echo url('user/myorder'); ?>">\n' +
                        '<div>\n' +
                        '<img src="/static/images/mobile.png" alt="">\n' +
                        '<p class="sale_item_title">游戏账单</p>\n' +
                        '</div>'
                        +'</a>';
                    $('.js_yxzd').empty().append(yxzd);
                    //修改资料
                    xgzl = '<a href="<?php echo url('user/userinfo'); ?>">\n' +
                        '<div>\n' +
                        '<img src="/static/images/pen.png" alt="">\n' +
                        '<p class="sale_item_title">修改资料</p>\n' +
                        '</div>\n' +
                        '</a>'
                    $('.js_xgzl').empty().append(xgzl);
                    //修改密码
                    xgmm = '<a href="<?php echo url('User/password'); ?>">\n' +
                        ' <div>\n' +
                        '<img src="/static/images/password.png" alt="">\n' +
                        '<p class="sale_item_title">修改密码</p>\n' +
                        '</div>\n' +
                        '</a>';
                    $('.js_xgmm').empty().append(xgmm);
                }
                //登录框写入账密
                $('.login_modal').find('input[name=account]').val(res.data.cookie_login_account);
                $('.login_modal').find('input[name=password]').val(res.data.cookie_login_password);
                //是否允许注册
                if(res.data.pc_user_allow_register!=1){
                    $('.js_allow_zz').removeClass('mianfei_zhuce');
                }
            }
        })
    </script>
    <script>
        $(function () {
            // 交换位置---------- START
            // var h5_02 = $('#h5_02'), sy_02 = $('#sy_02');
            // var p1 = h5_02.position().top, p2 = sy_02.position().top;
            // h5_02.animate({top:p2}, 1000); sy_02.animate({top:p1}, 1000);

            // var media_02_sort = ['yy_02', 'h5_02', 'sy_02'];
            // var media_02_new = [];

            // $.each(media_02_sort, function(index, item) {
            //     var that = $('#'+item)
            //     media_02_new.push({id: that.attr('id'), top: that.position().top})
            // })

            //var media_02_child = $('#media_02').children();

            // $.each(media_02_sort, function(index, item) {
            //     var that = $('#'+item)
            //     var other = $(media_02_child[index]);
            //     // var p1 = that.position().top;
            //     // var p2 = other.position().top;
            //     // that.animate({top:p2}, 1000);
            //     // other.animate({top:p1}, 1000)
            // })
            // $.each($('#media_02').children(), function(index, item) {
            //     console.log(item)
            //     console.log(index)
            //     var that = $(item)
            //     if (that.attr('id') != media_02_sort[index]) {
            //         var other = $('#'+media_02_sort[index]);
            //         var p1 = that.position().top;
            //         var p2 = other.position().top;
            //         that.animate({top:p2}, 1000);
            //         other.animate({top:p1}, 1000)
            //     }
            // })


            // exchange(h5_02,sy_02);
            // function exchange(a,b){
            //     var n = a.next(), p = b.prev();
            //     b.insertBefore(n);
            //     a.insertAfter(p);
            // };

            // 交换位置---------- END
            // var media_02_sort = ['yy_02', 'h5_02', 'sy_02']
            // var media_02 = $('#media_02');
            // var media_02_child = media_02.children()
            // var media_02_new = []
            // $.each(media_02_child, function(index, item) {

            // })
            // 跳转
            $('.js-h5Link').click(function() {
                var e = event || window.event
                var target = e.target
                if($(target).is('a[download]') || ($(target).is('li') && $(target).children('a[download]'))) {

                }else {
                    window.location.href = $(this).children('a').attr('data-href')
                }

            })
            $('.js-phoneLink').click(function() {
                var e = event || window.event
                var target = e.target
                if($(target).is('a[download]') || ($(target).is('li') && $(target).children('a[download]'))) {

                }else {
                    window.location.href = $(this).children('a').attr('data-href')
                }

            })
            $('.js-yeLink').click(function() {
                var e = event || window.event
                var target = e.target
                if($(target).is('a[download]') || ($(target).is('li') && $(target).children('a[download]'))) {

                }else {
                    window.location.href = $(this).children('a').attr('data-href')
                }

            })
            $('.js-h5BottomLink').click(function() {
                var e = event || window.event
                var target = e.target
                if($(target).is('a[download]') || ($(target).is('li') && $(target).children('a[download]'))) {

                }else {
                    window.location.href = $(this).children('div').attr('data-href')
                }


            })
            $('.js-H5Item').click(function(event) {
                var e = event || window.event
                var target = e.target
                if($(target).is('a[download]') || ($(target).is('li') && $(target).children('a[download]'))) {

                }else {
                    window.location.href = $(this).children('a').attr('data-href')
                }

            })
            $('.js-phoneBottomLink').click(function() {
                var e = event || window.event
                var target = e.target
                if($(target).is('a[download]') || ($(target).is('li') && $(target).children('a[download]'))) {

                }else {
                    window.location.href = $(this).children('div').attr('data-href')
                }
            })
            $('.js-phoneItem').click(function() {
                var e = event || window.event
                var target = e.target
                if($(target).is('a[download]') || ($(target).is('li') && $(target).children('a[download]'))) {

                }else {
                    window.location.href = $(this).children('a').attr('data-href')
                }

            })

            $('.js-downLoad').click(function() {
                return false
            })

            $('.js-phoneDown').click(function() {
                return false
            })



            $('.new_open_fw .layui-carousel-ind li').html('<div class="zhanweidivs"></div>')
            $('.getgift').click(function () {
                event.stopPropagation();
                var $this = $(this);
                var login_auth = "<?php echo $session['login_auth']; ?>";
                if (login_auth == 1) {
                    var gift_id = $this.attr('data-giftbag_id');
                    $.ajax({
                        type: 'post',
                        url: '<?php echo url("Gift/getgift"); ?>',
                        async: false,
                        data: {gift_id: gift_id},
                        dataType: 'json',
                        success: function (data) {
                            if (data.code == 1) {
                                $("#novice").val(data.novice);
                                $this.parent().find('button').text('已领取');
                                var conss = $('.receive_bag_modal');
                                layer.open({
                                    type: 1,
                                    title: false,
                                    closeBtn: false,
                                    area: ['325px', '191px'],
                                    offset: 'auto',
                                    content: conss,
                                    btnAlign: 'c',
                                    shadeClose: true,
                                    end: function () {
                                        $('.receive_bag_modal').hide();
                                        window.location.reload();
                                    }
                                })
                            } else {
                                layer.msg(data.msg, {skin: 'demo-red'});
                            }
                        },
                        error: function (xhr, type) {
                            alert('服务器错误');
                        }
                    });
                } else {
                    var conss = $('.login_modals')
                    layer.open({
                        type: 1,
                        title: false,
                        closeBtn: false,
                        area: ['305px', '320px'],
			            skin:'loginclass',
                        offset: 'auto',
                        content: conss,
                        btnAlign: 'c',
                        shadeClose: true,
                        end: function () {
                            $('.login_modals').hide()
                        }
                    })
                }
            })
            $('.copy1').click(function () {
                var str = $("#novice").val();
                Copy(str);
                layer.msg("复制成功", { time: 1000 });
            })
            $('.copy').click(function () {
                var str = $(this).attr('data-novice');
                Copy(str);
                layer.msg("复制成功", { time: 1000 });
            })
            function Copy(str) {
                var save = function (e) {
                    e.clipboardData.setData('text/plain', str);
                    e.preventDefault();
                }
                document.addEventListener('copy', save);
                document.execCommand('copy');
                document.removeEventListener('copy', save);
            }
            // 底部切换

			// var newtablength=parseInt($(".newtab_menu_con").length);
			// var width=(parseFloat(1/newtablength))*100;

			  // $.each($(".newtab_menu_con"), function (index, item) {
			  //     $(item).css({left: index * width+'%', width: width +'%'})
              //     if (index == newtablength-1) {
              //         $(item).css({'border-top-right-radius': '5px', 'border-bottom-right-radius': '5px'})
              //     }
              //     if(index==0){
              //         $(item).css({'border-top-left-radius': '5px', 'border-bottom-left-radius': '5px'})
              //     }
              // })


			// console.log(width+"%");
            // $(".recommend-menu-con:first").addClass("recommend-menu-active");
			// $(".recommend-con:first").addClass("js_tab_show");
            // $(".hot-menu-con:first").addClass("hot-menu-con-active");
			// $(".hot-con:first").addClass("js_tab_show");
			// $(".newtab_menu_con:first").addClass("newtab_menu_active");
			// $(".new-open-server").eq(0).addClass("js_tab_show");

			$(".top2notice-title").click(function(){
			   var index=$(this).index();
			    $(this).addClass("top2notice-active").siblings().removeClass("top2notice-active");
			   $(".top2notice-con").eq(index).addClass("js_tab_show").siblings().removeClass("js_tab_show");
			})
			$(".recommend-menu-con").click(function(){
			    var index=$(this).index();
			    $(this).addClass("recommend-menu-active").siblings().removeClass("recommend-menu-active");
			    $(".recommend-con").eq(index).addClass("js_tab_show").siblings().removeClass("js_tab_show");
			})
			//热门手游H5切换
			$(".hot-menu-con").click(function(){
			   var index=$(this).index();
			    $(this).addClass("hot-menu-con-active").siblings().removeClass("hot-menu-con-active");
			   $(".hot-con").eq(index).addClass("js_tab_show").siblings().removeClass("js_tab_show");
			})
            // 公告切换
			$(".notice_menu_con").click(function(){
			var index=$(this).index();
			     $(this).addClass("notice_menu_active").siblings().removeClass("notice_menu_active");
				 $(".notice_con").eq(index).addClass("js_tab_show").siblings().removeClass("js_tab_show");


			})
            //最新开服切换
			$(".newtab_menu_con").click(function(){
			   var index=$(this).index();
			   $(this).addClass("newtab_menu_active").siblings().removeClass("newtab_menu_active");
			   $(".new-open-server").eq(index).addClass("js_tab_show").siblings().removeClass("js_tab_show");
			})
			$(".tab-menu-con").click(function(){
			   var index=$(this).index();
			   $(this).addClass("tab-menu-active").siblings().removeClass("tab-menu-active");
			   $(".js_tab_show .new_open_con").eq(index).addClass("js_tab_show").siblings().removeClass("js_tab_show");
			})
        })
        layui.use('carousel', function () {
            var carousel = layui.carousel;
            carousel.render({
                elem: '#test1'
                , width: '100%'
                , height: '680px'
                , arrow: 'always'
            });
        });
        layui.use('carousel', function () {
            var carousel = layui.carousel;
            carousel.render({
                elem: '#test3'
                , width: '100%'
                , height: '310px'
                , arrow: 'none'
                , indicator: 'outside'
                , autoplay: false
                , interval: '4000'
            });
        });
		layui.use('carousel', function () {
            var carousel = layui.carousel;
            carousel.render({
                elem: '#test4'
                , width: '100%'
                , height: '310px'
                , arrow: 'none'
                , indicator: 'outside'
                , autoplay: false
                , interval: '4000'
            });
        });
		layui.use('carousel', function () {
            var carousel = layui.carousel;
            carousel.render({
                elem: '#test5'
                , width: '100%'
                , height: '310px'
                , arrow: 'none'
                , indicator: 'outside'
                , autoplay: false
                , interval: '4000'
            });
        });
		layui.use('carousel', function () {
            var carousel = layui.carousel;
            carousel.render({
                elem: '#test6'
                , width: '100%'
                , height: '310px'
                , arrow: 'none'
                , indicator: 'outside'
                , autoplay: false
                , interval: '4000'
            });
        });
		layui.use('carousel', function () {
            var carousel = layui.carousel;
            carousel.render({
                elem: '#test7'
                , width: '100%'
                , height: '310px'
                , arrow: 'none'
                , indicator: 'outside'
                , autoplay: false
                , interval: '4000'
            });
        });
		layui.use('carousel', function () {
            var carousel = layui.carousel;
            carousel.render({
                elem: '#test8'
                , width: '100%'
                , height: '310px'
                , arrow: 'none'
                , indicator: 'outside'
                , autoplay: false
                , interval: '4000'
            });
        });layui.use('carousel', function () {
            var carousel = layui.carousel;
            carousel.render({
                elem: '#test10'
                , width: '100%'
                , height: '310px'
                , arrow: 'none'
                , indicator: 'outside'
                , autoplay: false
                , interval: '4000'
            });
            carousel.render({
                elem: '#test11'
                , width: '100%'
                , height: '310px'
                , arrow: 'none'
                , indicator: 'outside'
                , autoplay: false
                , interval: '4000'
            });
            carousel.render({
                elem: '#test13'
                , width: '100%'
                , height: '310px'
                , arrow: 'none'
                , indicator: 'outside'
                , autoplay: false
                , interval: '4000'
            });
        });
        $('.close_receive_bag_modal').click(function () {
            layer.closeAll()
        })
        var prev_btn=document.getElementsByClassName('layui-carousel-arrow')[0];
        var next_btn=document.getElementsByClassName('layui-carousel-arrow')[1];
        if(prev_btn){
            prev_btn.classList.add("prev_btn");
        }
        if(next_btn){
            next_btn.classList.add("next_btn");
        }
        $(".fast_login_youke").click(function(){
            $(".").css("display","block")
        })
    </script>

  <?php if(AUTH_USER == 1): ?>
    <!-- 登录弹窗 -->
   <div class="login_modals" >
                        <form class="js-ajax-form" action="<?php echo url('User/login'); ?>" method="post">
                            <span class="closemodals"><img src="/static/images/login_btn_close_n.png" alt=""></span>
                            <p class="login_username">
							   <label class="label-name">账号</label>
							   <input type="text"  autocomplete="off" name="account" value="" placeholder="手机号/用户名"></p>
                            <p class="login_password">
							    <label class="label-name">密码</label>
							    <input type="password"  autocomplete="new-password" name="password"  value="" placeholder="密码">
                            </p>
                            <p class="zdlogin">
                                <label for="zdlogin">
                                    <input type="checkbox" name="zdlogin" checked id="zdlogin" value="1" class="fl" hidden>
                                    <i class="choice-icon"></i>
                                    <span class="remember-text">记住密码</span>
                                </label>
                            </p>
                            <p class="login_botton">
                                <button id="login_submit" class="js-ajax-submit reload-now ajax-no-reload" type="submit">登录</button>
                            </p>
                        </form>
                        <div class='ml20 mt10'>
                            <p class="fl zhuce_p">
                                <?php if(cmf_get_option('media_set')['pc_user_allow_register'] == 1): if(($account_register_switch == 1) or ($phonenum_register_switch == 1) or ($email_register_switch == 1)): ?>
                                    <span class="zhuce_newuser">注册新用户</span>
                                  <?php endif; endif; ?>
                            </p>
                            <p class="fg mg14"><span class="forget_password fg">忘记密码?</span></p>
                        </div>
						<div class="clear"></div>
						<div class="login-line"></div>
						<div class="clear"></div>

                        <?php if($qq_login == 1 or $weixin_login == 1): ?>


                            <div class="fl fast_login_title">快捷登录</div>


                            <p class=" fast_login_icon fl">
                                <?php if($qq_login == 1): ?><a  class="fast_login_qq" href="<?php echo url('User/thirdlogin',['type'=>'qq','gid'=>input('game_id'),'pid'=>input('pid')]); ?>"> <img
                                        src="/static/images/login_qq.png" alt=""></a><?php endif; if($weixin_login == 1): ?><a class="fast_login_wx" href="<?php echo url('User/thirdlogin',['type'=>'weixin','gid'=>input('game_id'),'pid'=>input('pid')]); ?>"> <img
                                        src="/static/images/login_wx.png" alt="" ></a><?php endif; ?>
                            </p>
                        <?php endif; ?>
                    </div>
<!-- 注册弹窗 -->
<div class="register-box">
  <div class="zhuce_modal" id="zhucemodal">
    <p class="zhucemodal_title">用户注册 <span><img src="/static/images/delete_icon.png" alt=""></span></p>

    <div class="zhuce_type">
      <?php if(($phonenum_register_switch == 1)): ?>
        <div class="fl zhuce_type_item">
          <p class="active_zhuce_type_title">手机注册</p>
        <div class="zhuce_type_hx active_zhuce_type"></div>
        </div>
      <?php endif; if(($account_register_switch == 1)): ?>
        <div class="fl zhuce_type_item">
          <p>账号注册</p>
        <div class="zhuce_type_hx"></div>
        </div>
      <?php endif; if(($email_register_switch == 1)): ?>
        <div class="fl zhuce_type_item">
          <p>邮箱注册</p>
        <div class="zhuce_type_hx"></div>
        </div>
      <?php endif; ?>

    </div>
    <div class="zhuce_fengexian"></div>
    <div class="zhuce_mobile_con">
      <form class="js-ajax-form" action="<?php echo url('User/register'); ?>" method="post">
        <div class="zhuce_phone zhuce_modal_item clear mt25">
          <p class="fl zhuce_modal_item_label">手机号</p>
          <input type="text" name="account" id="register_phone" placeholder="输入11位手机号" class="long_input_text fl">
          <span class="error_text ml120"></span>
        </div>
        <div class="zhuce_phone zhuce_modal_item clear">
          <p class="fl">&nbsp;</p>
          <div class="zhuce_phone_slide">
            <div class="geetest_box">
              <div class="geetest-heart"><span></span></div>
              <a href="javascript:;" id="verify_pop2">点击按钮进行验证</a>
              <a href="javascript:;" id="verify_refresh2" class="geetest-refresh">
                <img src="/themes/simpleboot3/mediapublic/assets/images/refresh.png" >
              </a>
              <input type="hidden" class="verify_tag" name="verify_tag">
              <input type="hidden" class="verify_token" name="verify_token">
            </div>
          </div>
        </div>
        <div class="zhuce_phone zhuce_modal_item clear">
          <p class="fl zhuce_modal_item_label">短信验证码</p>
          <input type="text" name="code" id="register_code" placeholder="短信验证码" class="duan_input_text fl">
          <div class="fl getyanzhengma">获取验证码</div>
          <span class="error_text ml120"></span>
        </div>
        <div class="zhuce_phone zhuce_modal_item clear">
          <p class="fl zhuce_modal_item_label">密码</p>
          <input type="password" name="password" id="register_password" placeholder="6-15位字母或数字组合"
                 class="long_input_text fl">
          <span class="error_text ml120 clear"></span>
        </div>
        <div class="zhuce_phone zhuce_modal_item clear">
          <p class="fl zhuce_modal_item_label">确认密码</p>
          <input type="password" name="repassword" id="register_repassword" placeholder="确认密码"
                 class="long_input_text fl">
          <span class="error_text ml120 clear"></span>
        </div>
        <div hidden class="auth_phone zhuce_modal_item clear mt25">
          <p class="fl">姓名</p><input type="text" name="real_name" maxlength="25" placeholder="请输入真实姓名" id="phone_realname"
                                     class="long_input_text">
          <span class="error_text ml120"></span>
        </div>
        <div hidden class="auth_phone zhuce_modal_item clear">
          <p class="fl">身份证号</p><input type="text" name="idcard" maxlength="18" placeholder="请输入身份证号码" id="phone_idcard"
                                       class="long_input_text">
          <span class="error_text ml120"></span>
        </div>
        <div class="zhuce_phone agree_user_pro">
          <label>
            <input type="checkbox" checked name="agreement" value="1" class="fl mobile_yzm" hidden>
            <i class="choice-icon"></i>
            <p>我已阅读并同意<span><a target="_blank" href="<?php echo url('article/about',['id'=>27]); ?>">《<?php echo $portal['post_title']; ?>》</a><a target="_blank" href="<?php echo url('article/about',['id'=>16]); ?>">《<?php echo $portal['post_title_yinsi']; ?>》</a></span></p>
          </label>
        </div>
        <div class=" agree_zhuce_btn">
          <input type="hidden" name="register_type" value="2">
          <?php if(get_user_config_info('age')['real_register_status'] > 0): ?>
            <button hidden class="btn_submit auth_phone js-ajax-submit" type="submit" disabled>接受协议并注册</button>
            <button class="btn auth_phone_btn" type="button" disabled>下一步</button>
            <?php else: ?>
            <button class="js-ajax-submit auth_phone_btn" type="submit" disabled>接受协议并注册</button>
          <?php endif; ?>
        </div>
      </form>
      <p class="zhuce_modal_tap">已有账号，<span>立即登录</span></p>
    </div>
    <div class="zhuce_zhanghao_con">
      <form class="js-ajax-form" action="<?php echo url('User/register',['gid'=>input('game_id'),'pid'=>input('pid')]); ?>" method="post">
        <div class="zhuce_name zhuce_modal_item clear mt25">
          <p class="fl">账号</p><input type="text" name="account" placeholder="6-15位字母或数字组合" id="register_phone1"
                                     class="long_input_text">
          <span class="error_text ml120"></span>
        </div>
        <div class="zhuce_name zhuce_modal_item clear">
          <p class="fl">密码</p><input type="password" name="password" id="register_password1" placeholder="6-15位字母或数字组合"
                                     class="long_input_text">
          <span class="error_text ml120"></span>
        </div>
        <div class="zhuce_name zhuce_modal_item clear">
          <p class="fl">确认密码</p><input type="password" name="repassword" id="register_repassword1" placeholder="确认密码" class="long_input_text">
          <span class="error_text ml120"></span>
        </div>
        <div class="zhuce_name zhuce_modal_item clear">
          <p class="fl">&nbsp;</p>
          <div class="zhuce_name_slide">
            <div class="geetest_box">
              <div class="geetest-heart"><span></span></div>
              <a href="javascript:;" id="verify_pop1">点击按钮进行验证</a>
              <a href="javascript:;" id="verify_refresh1" class="geetest-refresh">
                <img src="/themes/simpleboot3/mediapublic/assets/images/refresh.png" >
              </a>
              <input type="hidden" class="verify_tag" name="verify_tag">
              <input type="hidden" class="verify_token" name="verify_token">
            </div>
          </div>
        </div>
        <div class="zhuce_name agree_user_pro">
          <label>
            <input type="checkbox" checked name="agreement" value="1" class="fl" hidden>
            <i class="choice-icon"></i>
            <p>我已阅读并同意<span><a target="_blank" href="<?php echo url('article/about',['id'=>27]); ?>">《<?php echo $portal['post_title']; ?>》</a><a target="_blank" href="<?php echo url('article/about',['id'=>16]); ?>">《<?php echo $portal['post_title_yinsi']; ?>》</a></span></p>
          </label>
        </div>
        <div hidden class="auth_name zhuce_modal_item clear mt25">
          <p class="fl">姓名</p><input type="text" name="real_name" maxlength="25" placeholder="请输入真实姓名" id="register_realname"
                                     class="long_input_text">
          <span class="error_text ml120"></span>
        </div>
        <div hidden class="auth_name zhuce_modal_item clear ">
          <p class="fl">身份证号</p><input type="text" name="idcard" maxlength="18" id="register_idcard" placeholder="请输入身份证号码" class="long_input_text">
          <span class="error_text ml120"></span>
        </div>
        <div class=" agree_zhuce_btn2">
          <input type="hidden" name="register_type" value="1">
          <?php if(get_user_config_info('age')['real_register_status']  > 0): ?>
            <button hidden class="btn_submit auth_name js-ajax-submit" type="submit" disabled>接受协议并注册</button>
            <button class="btn auth_name_btn" type="button" disabled>下一步</button>
          <?php else: ?>
            <button class="js-ajax-submit auth_name_btn" type="submit" disabled>接受协议并注册</button>
          <?php endif; ?>
        </div>
      </form>
      <p class="zhuce_modal_tap ">已有账号，<span>立即登录</span></p>
    </div>
    <div class="zhuce_email_con">
      <form class="js-ajax-form" action="<?php echo url('User/register'); ?>" method="post">
        <div class="zhuce_email zhuce_modal_item clear mt25">
          <p class="fl zhuce_modal_item_label">邮箱地址</p>
          <input type="text" name="account" id="register_email" placeholder="输入邮箱" class="long_input_text fl">
          <span class="error_text ml120"></span>
        </div>
        <div class="zhuce_email zhuce_modal_item clear">
          <p class="fl zhuce_modal_item_label">验证码</p>
          <input type="text" name="code" id="register_email_code" placeholder="验证码" class="duan_input_text fl">
          <div class="fl getyanzhengma_email">获取验证码</div>
          <span class="error_text ml120"></span>
        </div>
        <div class="zhuce_email zhuce_modal_item clear">
          <p class="fl zhuce_modal_item_label">密码</p>
          <input type="password" name="password" id="register_email_password" placeholder="6-15位字母或数字组合"
                 class="long_input_text fl">
          <span class="error_text ml120 clear"></span>
        </div>
        <div class="zhuce_email zhuce_modal_item clear">
          <p class="fl zhuce_modal_item_label">确认密码</p>
          <input type="password" name="repassword" id="register_email_repassword" placeholder="确认密码"
                 class="long_input_text fl">
          <span class="error_text ml120 clear"></span>
        </div>
        <div hidden class="auth_email zhuce_modal_item clear mt25">
          <p class="fl">姓名</p><input type="text" name="real_name" maxlength="25" placeholder="请输入真实姓名" id="email_realname"
                                     class="long_input_text">
          <span class="error_text ml120"></span>
        </div>
        <div hidden class="auth_email zhuce_modal_item clear ">
          <p class="fl">身份证号</p><input type="text" name="idcard" placeholder="请输入身份证号码" maxlength="18" id="email_idcard"
                                       class="long_input_text">
          <span class="error_text ml120"></span>
        </div>
        <div class="zhuce_email agree_user_pro">
          <label>
            <input type="checkbox" checked name="agreement" value="1" class="fl email_yzm" hidden>
            <i class="choice-icon"></i>
            <p>我已阅读并同意<span><a target="_blank" href="<?php echo url('article/about',['id'=>27]); ?>">《<?php echo $portal['post_title']; ?>》</a><a target="_blank" href="<?php echo url('article/about',['id'=>16]); ?>">《<?php echo $portal['post_title_yinsi']; ?>》</a></span></p>
          </label>
        </div>
        <div class="agree_zhuce_btn3">
          <input type="hidden" name="register_type" value="3">
          <?php if(get_user_config_info('age')['real_register_status']  > 0): ?>
            <button hidden class="btn_submit auth_email js-ajax-submit" type="submit" disabled>接受协议并注册</button>
            <button class="btn auth_email_btn" type="button" disabled>下一步</button>
            <?php else: ?>
            <button class="js-ajax-submit auth_email_btn" type="submit" disabled>接受协议并注册</button>
          <?php endif; ?>
        </div>
      </form>
      <p class="zhuce_modal_tap">已有账号，<span>立即登录</span></p>
    </div>
  </div>
</div>

<!-- 找回密码弹窗 1-->
<div class="retrieve_pwd_modal">
  <p class="retrieve_pwd_title">找回密码<span><img src="/static/images/delete_icon.png" alt=""></span></p>
  <div class="retrieve_pwd_summny">
    <p class="fl onecol active_pwd_col">输入账号 <span>></span></p>
    <p class="fl twocol">短信验证 <span>></span></p>
    <p class="fl threecol ">设置密码</p>
  </div>
  <div class="retrieve_pwd_username">
    <input type="text" id="forget_account" placeholder="账号">
  </div>
  <div class="retrieve_pwd_onclickbtn">
    <p>确定</p>
  </div>
  <p class="zhuce_modal_tap ">已有账号，<span>立即登录</span></p>
</div>
<!-- 找回密码弹窗 2-->
<div class="retrieve_pwd_algin_modal" id="forget">
  <p class="retrieve_pwd_title">找回密码<span><img src="/static/images/delete_icon.png" alt=""></span></p>
  <div class="retrieve_pwd_summny">
    <p class="fl onecol active_pwd_col">输入账号 <span>></span></p>
    <p class="fl twocol active_pwd_col">短信验证 </p>
    <p class="fl threecol"><span class="gieagf">></span>设置密码</p>
  </div>
  <div class="retrieve_pwd_username">
    <input type="text" id="forget_phone" placeholder="绑定手机号">
  </div>
  <div class="retrieve_pwd_username">
    <div class="retrieve_pwd_slide">
      <div class="geetest_box">
        <div class="geetest-heart"><span></span></div>
        <a href="javascript:;" id="verify_pop3">点击按钮进行验证</a>
        <a href="javascript:;" id="verify_refresh3" class="geetest-refresh">
          <img src="/themes/simpleboot3/mediapublic/assets/images/refresh.png" >
        </a>
        <input type="hidden" class="verify_tag" name="verify_tag">
        <input type="hidden" class="verify_token" name="verify_token">
      </div>
    </div>
  </div>
  <div class="retrieve_pwd_yzm">
    <input type="text" id="forget_code" placeholder="验证码" class="fl">
    <div class="getyam_btn fl">
      <p>获取验证码</p>
    </div>
  </div>
  <div class="retrieve_pwd_algin_onclickbtn clear">
    <p>确定</p>
  </div>
  <p class="toggle_forgetpwd_email">短信用不了? <span>邮箱找回></span></span></p>
</div>
<!-- 邮箱找回密码 -->
<div class="retrieve_pwd_email_modal" id="forget_ema">
  <p class="retrieve_pwd_title">找回密码<span><img src="/static/images/delete_icon.png" alt=""></span></p>
  <div class="retrieve_pwd_summny">
    <p class="fl onecol active_pwd_col">输入账号 <span>></span></p>
    <p class="fl twocol active_pwd_col mt5">邮箱验证 </p>
    <p class="fl threecol"><span class="gieagf">></span>设置密码</p>
  </div>
  <div class="retrieve_pwd_username">
    <input type="text" id="forget_email" placeholder="绑定邮箱号">
  </div>
  <div class="retrieve_pwd_yzm">
    <input type="text" id="forget_email_code" placeholder="验证码" class="fl">
    <div class="getyam_btns fl">
      <p>获取验证码</p>
    </div>
  </div>
  <div class="retrieve_pwd_algin_onclickbtns clear">
    <p>确定</p>
  </div>
  <p class="toggle_forgetpwd_mobile">邮箱用不了? <span>短信找回></span></span></p>
</div>
<!--短信 找回密码弹窗 3-->
<div class="retrieve_pwd_last_modal">
  <form class="js-ajax-form" action="<?php echo url('User/forget_password'); ?>" method="post">
    <p class="retrieve_pwd_title">找回密码<span><img src="/static/images/delete_icon.png" alt=""></span></p>
    <div class="retrieve_pwd_summny">
      <p class="fl onecol active_pwd_col">输入账号 <span>></span></p>
      <p class="fl twocol active_pwd_col">短信验证 <span>></span></p>
      <p class="fl threecol active_pwd_col mt5">设置密码</p>
    </div>
    <div class="retrieve_pwd_username">
      <input type="password" name="password" placeholder="新密码（6-15位字母或数字组合）">
    </div>
    <div class="retrieve_pwd_username">
      <input type="password" name="repassword" placeholder="确认新密码">
    </div>
    <div class="retrieve_pwd_last_onclickbtn clear">
      <input type="hidden" name="code_type" value="phone">
      <button class="js-ajax-submit" type="submit">确定</button>
    </div>
  </form>
</div>
<!-- 邮箱 找回密码弹窗 3-->
<div class="retrieve_pwd_last_modals">
  <form class="js-ajax-form" action="<?php echo url('User/forget_password'); ?>" method="post">
    <p class="retrieve_pwd_title">找回密码<span><img src="/static/images/delete_icon.png" alt=""></span></p>
    <div class="retrieve_pwd_summny">
      <p class="fl onecol active_pwd_col">输入账号 <span>></span></p>
      <p class="fl twocol active_pwd_col">邮箱验证 <span>></span></p>
      <p class="fl threecol active_pwd_col mt5">设置密码</p>
    </div>
    <div class="retrieve_pwd_username">
      <input type="password" name="password" placeholder="新密码（6-15位字母或数字组合）">
    </div>
    <div class="retrieve_pwd_username">
      <input type="password" name="repassword" placeholder="确认新密码">
    </div>
    <div class="retrieve_pwd_last_onclickbtn clear">
      <input type="hidden" name="code_type" value="email">
      <button class="js-ajax-submit" type="submit">确定</button>
    </div>
  </form>
</div>
<?php endif; if(!(($action_name == open_game or $action_name == open_ygame) and $controller_name == Game)): ?>
<!-- 页面右侧悬浮框 -->
<div class="hover_modal">
  <div class="hover_modal_item1">
    <img src="/static/images/to_sale.png" alt="">
    <p>客服</p>
  </div>
  <div class="hover_modal_item2">
    <img src="/static/images/to_wx.png" alt="">
    <p>微信</p>
  </div>
  <div class="hover_modal_item3">
    <a href="javascript:;">
      <img src="/static/images/to_qq.png" alt="">
      <p>QQ</p>
    </a>

  </div>
  <div class="hover_modal_item4">
    <img src="/static/images/to_top.png" alt="">
  </div>
  <div class="comment">
    <div class="right_hover_tel">
      <img src="/static/images/right_hover_tel.png" alt="" class="fl"><p class="fl">
      <?php if($union_set[tel]): ?><?php echo $union_set['tel']; else: ?><?php echo cmf_get_option('kefu_set')['pc_set_server_tel']; endif; ?>
    </p> </div>
  </div>
  <div class="comment2">
    <p class="right_hover_wx"><img
            src="<?php if($union_set[qrcode]): ?><?php echo cmf_get_image_url($union_set['qrcode']); else: ?><?php echo cmf_get_image_url(cmf_get_option('media_set')['pc_set_qrcode']); endif; ?>"
            alt="" onerror="this.src='/static/images/empty.jpg';this.onerror=null"/>
    <p class="guanzhupub">关注<span class="xiguruanjianpub">
            <?php if($union_set[app_weixin]): ?><?php echo $union_set['app_weixin']; else: ?><?php echo cmf_get_option('media_set')['pc_set_qrcode_name']; endif; ?>
          </span>公众号</p>
    </p>
  </div>
  <div class="comment3">
    <p class="right_hover_qq">

      <?php if(empty($union_set[qq]) and get_xgkf_info(0)): ?>
        <a  class="xgkf_aq" target="_blank">
          在线客服
        </a>
      <?php else: ?>
        <img src="/static/images/right_hover_qq.png" alt="">
        <a href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php if($union_set[qq]): ?><?php echo $union_set['qq']; else: ?><?php echo cmf_get_option('kefu_set')['pc_set_server_qq']; endif; ?>&amp;site=qq&amp;menu=yes"
           target="_blank">
          <?php if($union_set[qq]): ?>
            <?php echo $union_set['qq']; else: ?>
            <?php echo cmf_get_option('kefu_set')['pc_set_server_qq']; endif; ?>
        </a>
      <?php endif; ?>
    </p>
  </div>
</div>
<!-- 游客登录-->
<div class="youkePop">
  <p class="retrieve_pwd_title1">设置登录密码
    <!-- <span><img src="/static/images/delete_icon.png" alt=""></span> -->
  </p>
  <div class="retrieve_pwd_username1">
    <div class="div1">
    <p class="nei-text">账号</p>
    <input type="text" id="zhanghao" class="zhanghao" value="11111111">
    <img src="/themes/simpleboot3/mobilepublic/assets/images/common_btn_delet.png" alt="" class="clear_texts1 fristclear_texts" style="display: none;">
    </div>
    <div class="div1">
      <p class="nei-text">密码</p>
      <input type="text" id="mimma" class="mima" value="11111111" placeholder="6-15位字母或数字">
      <img src="/themes/simpleboot3/mobilepublic/assets/images/common_btn_delet.png" alt="" class="clear_texts1 fristclear_texts" style="display: none;">
   </div>
  </div>
  <div class="retrieve_pwd_onclickbtn1">
    <p>注册</p>
  </div>
</div>
<!-- 底部 -->
<div class="game_detail_footer clear">
  <footer class="footer">
    <?php if(!(empty($links) || (($links instanceof \think\Collection || $links instanceof \think\Paginator ) && $links->isEmpty()))): ?>
    <div class="footer_link">
	    <div class="fl">友情链接</div>
		<div class="fl footer_link_con">
            <?php if(is_array($links) || $links instanceof \think\Collection || $links instanceof \think\Paginator): $i = 0; $__LIST__ = $links;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <a target="_blank" href="<?php echo $vo['link_url']; ?>" class="footer_link_link"><?php echo $vo['title']; ?></a>
            <?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
	</div>
      <div class="footer_nav_hx"></div>
    <?php endif; ?>
    <div class="footer_con tuiguangFooter">
      <div class="footer_logo_img fl">
        <img class="footer_logo"
             src="<?php if($union_set[pc_ft_logo]): ?><?php echo cmf_get_image_url($union_set['pc_ft_logo']); else: ?><?php echo cmf_get_image_url(cmf_get_option('media_set')['pc_set_logo_foot']); endif; ?>"
             alt="" >
      </div>

      <div class="first_con fl ml48"></div>
      <?php if(!(empty($articleLists) || (($articleLists instanceof \think\Collection || $articleLists instanceof \think\Paginator ) && $articleLists->isEmpty()))): ?>
        <div class="breadnav fl">
          <?php if(is_array($articleLists) || $articleLists instanceof \think\Collection || $articleLists instanceof \think\Paginator): $i = 0; $__LIST__ = $articleLists;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <a target="_blank" href="<?php echo url('Article/about',['id'=>$vo['id']]); ?>">
              <p class="first_nav_con newNav_con_items"><?php echo $vo['title']; ?></p>
            </a>
          <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
      <?php else: ?>
        <div class="breadnav fl">
          <a target="_blank" href="<?php echo url('Article/about'); ?>">
            <p class="first_nav_con">关于我们</p>
          </a>
          <p class="footer_nav_fh">|</p>
          <a target="_blank" href="<?php echo url('Article/about',['id'=>12]); ?>">
            <p class="footer_nav_con">商务合作</p>
          </a>

          <p class="footer_nav_fh">|</p>
          <a target="_blank" href="<?php echo url('Article/about',['id'=>28]); ?>">
            <p class="footer_nav_con">合作伙伴</p>
          </a>

          <p class="footer_nav_fh">|</p>
          <a target="_blank" href="<?php echo url('Article/supervise'); ?>">
            <p class="footer_nav_con">家长监督</p>
          </a>
          <!-- <p class="footer_nav_fh">|</p>
                <p class="footer_nav_con">客服帮助</p> -->

          <?php if(!empty(cmf_get_option('media_set')['support_show_status'])): ?>
            <p class="footer_nav_fh">|</p>
            <a class="linkxigu" href="https://www.vlsdk.com/" target="_blank">
              <p class="footer_nav_con">技术支持</p>
            </a>
          <?php endif; ?>

          <p class="footer_nav_fh">|</p>
          <a target="_blank" href="<?php echo url('Article/about',['id'=>18]); ?>">
            <p class="last_nav_con">企业招聘</p>
          </a>
      </div>
      <?php endif; if($union_set): ?>

        <div class="infos">
          <p>
            <span><img src="/themes/simpleboot3/mediapublic/assets/images/public_shield.png" ></span>
            <span><?php if(empty($union_set['pc_set_for_the_record']) || (($union_set['pc_set_for_the_record'] instanceof \think\Collection || $union_set['pc_set_for_the_record'] instanceof \think\Paginator ) && $union_set['pc_set_for_the_record']->isEmpty())): ?><?php echo cmf_get_option('media_set')['pc_set_for_the_record']; else: ?><?php echo $union_set['pc_set_for_the_record']; endif; ?></span>
              <span style="margin-left:50px"><?php if(empty($union_set['pc_set_telecom_license']) || (($union_set['pc_set_telecom_license'] instanceof \think\Collection || $union_set['pc_set_telecom_license'] instanceof \think\Paginator ) && $union_set['pc_set_telecom_license']->isEmpty())): ?><?php echo cmf_get_option('media_set')['pc_set_telecom_license']; else: ?><?php echo $union_set['pc_set_telecom_license']; endif; ?></span>
          </p>
          <p>
              <span><?php if(empty($union_set['pc_set_license']) || (($union_set['pc_set_license'] instanceof \think\Collection || $union_set['pc_set_license'] instanceof \think\Paginator ) && $union_set['pc_set_license']->isEmpty())): ?><?php echo cmf_get_option('media_set')['pc_set_license']; else: ?><?php echo $union_set['pc_set_license']; endif; ?></span>

            <?php if(!empty(cmf_get_option('media_set')['icp_organ_link'])): ?>
                <span style="margin-left:50px"><a target="_blank" style="color: rgba(255,255,255,0.3);" href="<?php echo cmf_get_option('media_set')['icp_organ_link']; ?>"><?php if(empty($union_set['pc_set_for_the_record_icp']) || (($union_set['pc_set_for_the_record_icp'] instanceof \think\Collection || $union_set['pc_set_for_the_record_icp'] instanceof \think\Paginator ) && $union_set['pc_set_for_the_record_icp']->isEmpty())): ?><?php echo cmf_get_option('media_set')['pc_set_for_the_record_icp']; else: ?><?php echo $union_set['pc_set_for_the_record_icp']; endif; ?></a></span>
            <?php else: ?>
                <span style="margin-left:50px"><a target="_blank" style="color: rgba(255,255,255,0.3);" href="http://www.beian.gov.cn/portal/index.do"><?php if(empty($union_set['pc_set_for_the_record_icp']) || (($union_set['pc_set_for_the_record_icp'] instanceof \think\Collection || $union_set['pc_set_for_the_record_icp'] instanceof \think\Paginator ) && $union_set['pc_set_for_the_record_icp']->isEmpty())): ?><?php echo cmf_get_option('media_set')['pc_set_for_the_record_icp']; else: ?><?php echo $union_set['pc_set_for_the_record_icp']; endif; ?></a></span>
            <?php endif; ?>


            <!-- <span style="margin-left:50px"><a target="_blank" style="color: rgba(255,255,255,1);" href="http://www.beian.gov.cn/portal/index.do"><?php echo $union_set['pc_set_for_the_record_icp']; ?></a></span> -->

          </p>
            <p><?php if(empty($union_set['pc_set_copyright']) || (($union_set['pc_set_copyright'] instanceof \think\Collection || $union_set['pc_set_copyright'] instanceof \think\Paginator ) && $union_set['pc_set_copyright']->isEmpty())): ?><?php echo cmf_get_option('media_set')['pc_set_copyright']; else: ?><?php echo $union_set['pc_set_copyright']; endif; ?></p>
        </div>

      <?php else: ?>
        <div class="infos">
          <p>
            <span><img src="/themes/simpleboot3/mediapublic/assets/images/public_shield.png" ></span>

            <?php if(!empty(cmf_get_option('media_set')['public_security_organ_link'])): ?>
              <span style="margin-left:0px"><a target="_blank" style="color: rgba(255,255,255,0.3);" href="<?php echo cmf_get_option('media_set')['public_security_organ_link']; ?>"><?php echo cmf_get_option('media_set')['pc_set_for_the_record']; ?></a></span>
            <?php else: ?>
              <span><?php echo cmf_get_option('media_set')['pc_set_for_the_record']; ?></span>
            <?php endif; ?>

            <span style="margin-left:50px"><?php echo cmf_get_option('media_set')['pc_set_telecom_license']; ?></span>
          </p>

          <p>
            <span><?php echo cmf_get_option('media_set')['pc_set_license']; ?></span>
            <?php if(!empty(cmf_get_option('media_set')['icp_organ_link'])): ?>
              <span style="margin-left:50px"><a target="_blank" style="color: rgba(255,255,255,0.3);" href="<?php echo cmf_get_option('media_set')['icp_organ_link']; ?>"><?php echo cmf_get_option('media_set')['pc_set_for_the_record_icp']; ?></a></span>
            <?php else: ?>
              <span style="margin-left:50px"><a target="_blank" style="color: rgba(255,255,255,0.3);" href="http://www.beian.gov.cn/portal/index.do"><?php echo cmf_get_option('media_set')['pc_set_for_the_record_icp']; ?></a></span>
            <?php endif; ?>

          </p>
          <p><?php echo cmf_get_option('media_set')['pc_set_copyright']; ?></p>
        </div>
      <?php endif; ?>
    </div>
    <!-- 修改后的 -->
    <div class="reportBottomDetail">
      <div class="reportCenterInfo">
        <a href=" https://www.12377.cn/" target="_blank"><i class="safeInternet safeGameIcon"></i> 中国互联网举报中心 </a>
        <a href="http://www.cyberpolice.cn/wfjb/" target="_blank"><i class="breakingLaw safeGameIcon"></i> 网络违法举报中心 </a>
        <a href="https://www.12321.cn/" target="_blank"><i class="rubbishInfo safeGameIcon"></i> 垃圾信息举报中心</a>
        <a href="javaScript:;"  id="goToRefer"><i class="gameCheckPlatform safeGameIcon"></i> 已接入中宣部网络游戏防沉迷实名认证系统</a>
        <a href="https://www.game12315.com/" target="_blank"><i class="gameReportCenter safeGameIcon"></i> 中国网络游戏投诉平台</a>
      </div>
    </div>
    <div class="footer_nav_hx"></div>
    <p class="footer_nav_news"><?php echo cmf_get_option('media_set')['pc_game_prompt']; ?></p>
  </footer>
</div>
<?php endif; ?>
</div>
</body>
<script src="/static/js/wind.js"></script>
  <script>
    // 首页，鼠标放上去显示全部
    $(".nav li").hover(function () {
      var title_val= $(this).text();
      $(this).attr("title",title_val);
    });
    $(".fg .js_usermune li").hover(function () {
      var title_val1= $(this).text();
      $(this).attr("title",title_val1);
    });
  // var title_val=$('.act').text();
  // $(".act").attr("title",title_val);
    $('#goToRefer').click(function() {
       open_new_window('https://wlc.nppa.gov.cn/fcm_company/index.html#/login?redirect=%2F')
      //window.location.href = 'https://wlc.nppa.gov.cn/fcm_company/index.html#/login?redirect=%2F'
    })

    function open_new_window(full_link)
    {
        window.open('javascript:window.name;', '<script>location.replace("'+full_link+'")<\/script>');
    }


      var is_real_auth = "<?php echo get_user_config_info('age')['real_register_status']; ?>";
      var phone_is_phone = false;
      var phone_is_yzm = false;
      var phone_is_pwd = false;
      var phone_is_aginpwd = false;
      var phone_is_agree = true;
      var phone_is_z_yam = false;

      var user_is_username = false;
      var user_is_userpwd = false;
      var user_is_useragreepwd = false;
      var user_is_yzm = false;
      if(is_real_auth == 1 ){
          var phone_is_real_name = false;
          var phone_is_idcard = false;
          var user_is_real_name = false;
          var user_is_idcard = false;
          var email_is_real_name = false;
          var email_is_idcard = false;
      }else{
          var phone_is_real_name = true;
          var phone_is_idcard = true;
          var user_is_real_name = true;
          var user_is_idcard = true;
          var email_is_real_name = true;
          var email_is_idcard = true;
      }
      var email_is_email = false;
      var email_is_yzm = false;
      var email_is_pwd = false;
      var email_is_agree = true;
      var email_is_aginpwd = false;
    //普通号注册智能验证
    $('#verify_pop1').on('click',function(){
      if($('body').find('.pop-caption-box').length>0) {return false;}
      user_is_yzm = false;
      //回调函数
      window.caption_callback_function = function(tag,token){
        $('#verify_pop1').off('click').text('验证成功');
        $('#verify_pop1').siblings('.verify_tag').val(tag);
        $('#verify_pop1').siblings('.verify_token').val(token);
        user_is_yzm = true;
        if (user_is_username && user_is_userpwd && user_is_useragreepwd && user_is_yzm) {
            $('.agree_zhuce_btn2 .auth_name_btn').addClass('can_click')
            $('.agree_zhuce_btn2 .auth_name_btn').prop('disabled', false)
            if(user_is_real_name && user_is_idcard) {
                $('.agree_zhuce_btn2 .btn_submit').addClass('can_click')
                $('.agree_zhuce_btn2 .btn_submit').prop('disabled', false)
            }else{
                $('.agree_zhuce_btn2 .btn_submit').removeClass('can_click')
                $('.agree_zhuce_btn2 .btn_submit').prop('disabled', true)
            }
        } else {
            $('.agree_zhuce_btn2 .auth_name_btn').removeClass('can_click')
            $('.agree_zhuce_btn2 .auth_name_btn').prop('disabled', true)
        }
      }
      url = "<?php echo url('user/caption/verify_pop'); ?>"
      $.get(url, function (html) {
        $('body').append(html);
      });
      return false;
    })
    $('#verify_refresh1').click(function () {
      $('#verify_pop1').siblings('.verify_tag').val('');
      $('#verify_pop1').siblings('.verify_token').val('');
      $('#verify_pop1').off('click').on('click',function(){
        if($('body').find('.pop-caption-box').length>0) {return false;}
        user_is_yzm = false;
        //回调函数
        window.caption_callback_function = function(tag,token){
          $('#verify_pop1').off('click').text('验证成功');
          $('#verify_pop1').siblings('.verify_tag').val(tag);
          $('#verify_pop1').siblings('.verify_token').val(token);
          user_is_yzm = true;
          if (user_is_username && user_is_userpwd && user_is_useragreepwd && user_is_yzm) {
            $('.agree_zhuce_btn2 .auth_name_btn').addClass('can_click')
            $('.agree_zhuce_btn2 .auth_name_btn').prop('disabled', false)
          } else {
            $('.agree_zhuce_btn2 .auth_name_btn').removeClass('can_click')
            $('.agree_zhuce_btn2 .auth_name_btn').prop('disabled', true)
          }
        }
        url = "<?php echo url('user/caption/verify_pop'); ?>"
        $.get(url, function (html) {
          $('body').append(html);
        });
        return false;
      }).text('点击按钮进行验证');
      return false;
    });
    //手机号注册智能验证
    $('#verify_pop2').on('click',function(){
      if($('body').find('.pop-caption-box').length>0) {return false;}
      //回调函数
      phone_is_z_yam = false;
      window.caption_callback_function = function(tag,token){
        $('#verify_pop2').off('click').text('验证成功');
        $('#verify_pop2').siblings('.verify_tag').val(tag);
        $('#verify_pop2').siblings('.verify_token').val(token);
        phone_is_z_yam = true;
        if (phone_is_phone && phone_is_yzm && phone_is_pwd && phone_is_aginpwd && phone_is_agree && phone_is_z_yam) {
          $('.agree_zhuce_btn .auth_phone_btn').addClass('can_click')
          $('.agree_zhuce_btn .auth_phone_btn').prop('disabled', false)
        } else {
          $('.agree_zhuce_btn .auth_phone_btn').removeClass('can_click')
          $('.agree_zhuce_btn .auth_phone_btn').prop('disabled', true)
        }
      }
      url = "<?php echo url('user/caption/verify_pop'); ?>"
      $.get(url, function (html) {
        $('body').append(html);
      });
      return false;
    })
    $('#verify_refresh2').click(function () {
      $('#verify_pop2').siblings('.verify_tag').val('');
      $('#verify_pop2').siblings('.verify_token').val('');
      $('#verify_pop2').off('click').on('click',function(){
        if($('body').find('.pop-caption-box').length>0) {return false;}
        //回调函数
        phone_is_z_yam = false;
        window.caption_callback_function = function(tag,token){
          $('#verify_pop2').off('click').text('验证成功');
          $('#verify_pop2').siblings('.verify_tag').val(tag);
          $('#verify_pop2').siblings('.verify_token').val(token);
          phone_is_z_yam = true;
          if (phone_is_phone && phone_is_yzm && phone_is_pwd && phone_is_aginpwd && phone_is_agree && phone_is_z_yam) {
            $('.agree_zhuce_btn .auth_phone_btn').addClass('can_click')
            $('.agree_zhuce_btn .auth_phone_btn').prop('disabled', false)
          } else {
            $('.agree_zhuce_btn .auth_phone_btn').removeClass('can_click')
            $('.agree_zhuce_btn .auth_phone_btn').prop('disabled', true)
          }
        }
        url = "<?php echo url('user/caption/verify_pop'); ?>"
        $.get(url, function (html) {
          $('body').append(html);
        });
        return false;
      }).text('点击按钮进行验证');
      return false;
    });
    //忘记密码智能验证
    $('#verify_pop3').on('click',function(){
      if($('body').find('.pop-caption-box').length>0) {return false;}
      //回调函数
      window.caption_callback_function = function(tag,token){
        $('#verify_pop3').off('click').text('验证成功');
        $('#verify_pop3').siblings('.verify_tag').val(tag);
        $('#verify_pop3').siblings('.verify_token').val(token);
      }
      url = "<?php echo url('user/caption/verify_pop'); ?>"
      $.get(url, function (html) {
        $('body').append(html);
      });
      return false;
    })
    $('#verify_refresh3').click(function () {
      $('#verify_pop3').siblings('.verify_tag').val('');
      $('#verify_pop3').siblings('.verify_token').val('');
      $('#verify_pop3').off('click').on('click',function(){
        if($('body').find('.pop-caption-box').length>0) {return false;}
        //回调函数
        window.caption_callback_function = function(tag,token){
          $('#verify_pop3').off('click').text('验证成功');
          $('#verify_pop3').siblings('.verify_tag').val(tag);
          $('#verify_pop3').siblings('.verify_token').val(token);
        }
        url = "<?php echo url('user/caption/verify_pop'); ?>"
        $.get(url, function (html) {
          $('body').append(html);
        });
        return false;
      }).text('点击按钮进行验证');
      return false;
    });
  $(document).ready(function () {
    function changezhucebtn() {
      if (phone_is_phone && phone_is_yzm && phone_is_pwd && phone_is_aginpwd  && phone_is_z_yam) {
        $('.auth_phone_btn').addClass('can_click');
        $('.auth_phone_btn').prop('disabled', false);
        if(phone_is_real_name && phone_is_idcard) {
            $('.agree_zhuce_btn .btn_submit').addClass('can_click')
            $('.agree_zhuce_btn .btn_submit').prop('disabled', false)
        }else{
            $('.agree_zhuce_btn .btn_submit').removeClass('can_click')
            $('.agree_zhuce_btn .btn_submit').prop('disabled', true)
        }
      } else {
        $('.agree_zhuce_btn .btn_submit').removeClass('can_click')
        $('.agree_zhuce_btn .btn_submit').prop('disabled', true)
      }
    }
    function changezhucebtns() {
      //console.log(user_is_username, user_is_userpwd, user_is_useragreepwd)
      if (user_is_username && user_is_userpwd && user_is_useragreepwd  && user_is_yzm) {
        $('.auth_name_btn').addClass('can_click');
        $('.auth_name_btn').prop('disabled', false);
        if(user_is_real_name && user_is_idcard){
            $('.agree_zhuce_btn2 .btn_submit').addClass('can_click');
            $('.agree_zhuce_btn2 .btn_submit').prop('disabled', false);
        }else{
            $('.agree_zhuce_btn2 .btn_submit').removeClass('can_click');
            $('.agree_zhuce_btn2 .btn_submit').prop('disabled', true);
        }
      } else {
        $('.agree_zhuce_btn2 button').removeClass('can_click');
        $('.agree_zhuce_btn2 button').prop('disabled', true);
      }
    }
      function changezhucebtn_email() {
          //console.log(email_is_email, email_is_yzm, email_is_pwd,email_is_agree,email_is_aginpwd)
          if (email_is_email && email_is_yzm && email_is_pwd && email_is_agree && email_is_aginpwd) {
              $('.auth_email_btn').addClass('can_click');
              $('.auth_email_btn').prop('disabled', false);
              if(email_is_real_name && email_is_idcard) {
                  $('.agree_zhuce_btn3 .btn_submit').addClass('can_click')
                  $('.agree_zhuce_btn3 .btn_submit').prop('disabled', false)
              }else{
                  $('.agree_zhuce_btn3 .btn_submit').removeClass('can_click')
                  $('.agree_zhuce_btn3 .btn_submit').prop('disabled', true)
              }
          } else {
              $('.agree_zhuce_btn3 button').removeClass('can_click')
              $('.agree_zhuce_btn3 button').prop('disabled', true)
          }
      }
      $(".auth_name_btn").click(function () {
          var $this = $(this);
          if($this.text() == "下一步"){
              $(".auth_name").show();
              $(".zhuce_name").hide();
              $this.text("上一步").addClass("pre-step-style");
              $('.zhuce_zhanghao_con .zhuce_modal_tap').hide()
          }else if($this.text() == "上一步"){
              $(".auth_name").hide();
              $(".zhuce_name").show();
              $this.text("下一步").removeClass('pre-step-style');
              $('.zhuce_zhanghao_con .zhuce_modal_tap').show()
          }
      })

      $(".auth_phone_btn").click(function () {
          var $this = $(this);
          if($this.text() == "下一步"){
              $(".auth_phone").show();
              $(".zhuce_phone").hide();
              $this.text("上一步").addClass("pre-step-style");
              $('.zhuce_mobile_con .zhuce_modal_tap').hide()
          }else if($this.text() == "上一步"){
              $(".auth_phone").hide();
              $(".zhuce_phone").show();
              $this.text("下一步").removeClass('pre-step-style');
              $('.zhuce_mobile_con .zhuce_modal_tap').show()
          }
      })
      $(".auth_email_btn").click(function () {
          var $this = $(this);
          if($this.text() == "下一步"){
              $(".auth_email").show();
              $(".zhuce_email").hide();
              $this.text("上一步").addClass("pre-step-style");
              $('.zhuce_email_con .zhuce_modal_tap').hide()
          }else if($this.text() == "上一步"){
              $(".auth_email").hide();
              $(".zhuce_email").show();
              $this.text("下一步").removeClass('pre-step-style');
              $('.zhuce_email_con .zhuce_modal_tap').show()
          }
      })
    $('.mobile_yzm').change(function () {
      if ($('.mobile_yzm').prop('checked')) {
        phone_is_agree = true
        changezhucebtn()
      } else {
        phone_is_agree = false
        changezhucebtn()
      }
    })

    $('.email_yzm').change(function () {
        if ($('.email_yzm').prop('checked')) {
            email_is_agree = true;
            changezhucebtn_email();
        } else {
            email_is_agree = false;
            changezhucebtn_email();
        }
    })
    //验证码刷新
    $("#getcaptcha,#getcaptcha2").click(function(event) {
        this.src = "<?php echo url('User/set_captcha'); ?>?"+Math.random();
    });
    $('.zhuce_zhanghao_con').hide();
    $('.zhuce_email_con').hide();
    // 处理搜索框效果
    $('#search').bind("input propertychange", function (event) {
      $("#inputdowndiv").hide();
      var game_name = $("#search").val();
      $("#inputdowndiv").html('');
      if (game_name == '') {
        return false;
      }

      $.ajax({
        url: "<?php echo url('Index/search'); ?>",
        type: 'post',
        dataType: 'json',
        async: false,
        data: { game_name: game_name },
        success: function (res) {
          if (res.code == 1) {
              var html = '';
              $.each(res.data, function (i, item) {
                if ((item.game_name).includes(game_name)) {
                  var reg = new RegExp(game_name, "g")
                  item.game_name = (item.game_name).replace(reg, '<span>' + game_name + '</span>')
                  html += '<a href="' + item.url + '"><p class="fl">' + item.game_name + '</p></a>';
                } else {
                  html += '<a href="' + item.url + '"><p class="fl">' + item.game_name + '</p></a>';
                }
              });
              $("#inputdowndiv").html(html);
              $("#inputdowndiv").show();
          }
        }
      })

    });
    $('#register_phone').bind('input propertychange', function () {
      var $this = $(this);
      if ($this.val()) {
        $.ajax({
          url: "<?php echo url('User/checkRegisterName'); ?>",
          type: 'post',
          dataType: 'json',
          data: { account: $this.val(), register_type: 2 },
          success: function (res) {
            if (res.code != 1) {
              $this.parent().find('.error_text').text(res.msg);
              phone_is_phone = false
              changezhucebtn()
            } else {
              phone_is_phone = true
              changezhucebtn()
              $this.parent().find('.error_text').text('');
            }
          }, error: function () {
            phone_is_phone = false
            changezhucebtn()
            layer.msg('服务器错误');
          }
        })
      }
    })
    $('#phone_realname').bind('input propertychange', function () {
        var $this = $(this);
        var reg = /^[\u4E00-\u9FA5]+$/;
        if ($this.val()) {
            if ($this.val().length > 25 || $this.val().length < 2 || reg.test($this.val()) == false) {
                phone_is_real_name = false
                changezhucebtn()
                $this.parent().find('.error_text').text('姓名格式错误');
            } else {
                phone_is_real_name = true
                changezhucebtn()
                $this.parent().find('.error_text').text('');
            }
        }else{
            if(is_real_auth == 2){
                phone_is_real_name = true
                changezhucebtns()
                $this.parent().find('.error_text').text('');
            }
        }
    })
    $('#phone_idcard').bind('input propertychange', function () {
        var $this = $(this);
        if ($this.val()) {
            if ($this.val().length > 18 || $this.val().length < 15) {
                phone_is_idcard = false
                changezhucebtn()
                $this.parent().find('.error_text').text('证件号码错误');
            } else {
                phone_is_idcard = true
                changezhucebtn()
                $this.parent().find('.error_text').text('');
            }
        }else{
            if(is_real_auth == 2){
                phone_is_idcard = true
                changezhucebtns()
                $this.parent().find('.error_text').text('');
            }
        }
    })
    $('#register_code').bind('input propertychange', function () {
      var $this = $(this);
      if ($this.val()) {
        if ($this.val().length == 6) {
          $this.parent().find('.error_text').text('');
          phone_is_yzm = true
          changezhucebtn()
        } else {
          phone_is_yzm = false
          changezhucebtn()
          $this.parent().find('.error_text').text('请输入正确的验证码');
        }
      }
    })
    $("#register_phone1").bind('input propertychange', function () {
      var $this = $(this);
      if ($this.val()) {
        $.ajax({
          url: "<?php echo url('User/checkRegisterName'); ?>",
          type: 'post',
          dataType: 'json',
          data: { account: $this.val(), register_type: 1 },
          success: function (res) {
            if (res.code != 1) {
              user_is_username = false
              changezhucebtns()
              $this.parent().find('.error_text').text(res.msg);
            } else {
              user_is_username = true
              changezhucebtns()
              $this.parent().find('.error_text').text('');
            }
          }, error: function () {
            user_is_username = false
            changezhucebtns()
            layer.msg('服务器错误');
          }
        })
      }
    })
    $("#captcha2").bind('input propertychange', function () {
          var $this = $(this);
          if ($this.val()) {
              $this.parent().find('.error_text').text('');
              email_is_yzm = true
              changezhucebtn_email()
          }
      })

    $('#register_password1').bind('input propertychange', function () {
      var $this = $(this);
      if ($this.val()) {
        if ($this.val().length > 15 || $this.val().length < 6) {
          user_is_userpwd = false
          changezhucebtns()
          $this.parent().find('.error_text').text('6-15位字母或数字组合');
        } else {
          user_is_userpwd = true
          changezhucebtns()
          $this.parent().find('.error_text').text('');
        }
      }
    })
    $('#register_password').bind('input propertychange', function () {
      var $this = $(this);
      if ($this.val()) {
        if ($this.val().length > 15 || $this.val().length < 6) {
          phone_is_pwd = false
          changezhucebtn()
          $this.parent().find('.error_text').text('6-15位字母或数字组合');
        } else {
          phone_is_pwd = true
          changezhucebtn()
          $this.parent().find('.error_text').text('');
        }
      }
    })
    $('#register_repassword').bind('input propertychange', function () {
      var $this = $(this);
      if ($this.val()) {
        if ($this.val().length > 15 || $this.val().length < 6) {
          $this.parent().find('.error_text').text('6-15位字母或数字组合');
          phone_is_aginpwd = false
          changezhucebtn()
        } else if ($this.val() != $("#register_password").val()) {
          phone_is_aginpwd = false
          changezhucebtn()
          $this.parent().find('.error_text').text('两次输入的密码不一致');
        } else {
          phone_is_aginpwd = true
          changezhucebtn()
          $this.parent().find('.error_text').text('');
        }
      }
    })
    $('#register_repassword1').bind('input propertychange', function () {
      var $this = $(this);
      if ($this.val()) {
        if ($this.val().length > 15 || $this.val().length < 6) {
          user_is_useragreepwd = false
          changezhucebtns()
          $this.parent().find('.error_text').text('6-15位字母或数字组合');
        } else if ($this.val() != $("#register_password1").val()) {
          user_is_useragreepwd = false
          changezhucebtns()
          $this.parent().find('.error_text').text('两次输入的密码不一致');
        } else {
          user_is_useragreepwd = true
          changezhucebtns()
          $this.parent().find('.error_text').text('');
        }
      }
    })
      $('#register_realname').bind('input propertychange', function () {
          var $this = $(this);
          var reg = /^[\u4E00-\u9FA5]+$/;
          if ($this.val()) {
              if ($this.val().length > 25 || $this.val().length < 2 || reg.test($this.val()) == false) {
                  user_is_real_name = false
                  changezhucebtns()
                  $this.parent().find('.error_text').text('姓名格式错误');
              } else {
                  user_is_real_name = true
                  changezhucebtns()
                  $this.parent().find('.error_text').text('');
              }
          }else{
              if(is_real_auth == 2){
                  user_is_real_name = true
                  changezhucebtns()
                  $this.parent().find('.error_text').text('');
              }
          }
      })
      $('#register_idcard').bind('input propertychange', function () {
          var $this = $(this);
          if ($this.val()) {
              if ($this.val().length > 18 || $this.val().length < 15) {
                  user_is_idcard = false
                  changezhucebtns()
                  $this.parent().find('.error_text').text('证件号码错误');
              } else {
                  user_is_idcard = true
                  changezhucebtns()
                  $this.parent().find('.error_text').text('');
              }
          }else{
              if(is_real_auth == 2){
                  user_is_idcard = true
                  changezhucebtns()
                  $this.parent().find('.error_text').text('');
              }
          }
      })
    $('#register_email_code').bind('input propertychange', function () {
        var $this = $(this);
        if ($this.val()) {
            if ($this.val().length == 6) {
                $this.parent().find('.error_text').text('');
                email_is_yzm = true;
                changezhucebtn_email();
            } else {
                email_is_yzm = false;
                changezhucebtn_email();
                $this.parent().find('.error_text').text('请输入正确的验证码');
            }
        }
    })
      $("#register_email").bind('input propertychange', function () {
          var $this = $(this);
          if ($this.val()) {
              $.ajax({
                  url: "<?php echo url('User/checkRegisterName'); ?>",
                  type: 'post',
                  dataType: 'json',
                  data: { account: $this.val(), register_type: 3 },
                  success: function (res) {
                      if (res.code != 1) {
                          email_is_email = false;
                          changezhucebtn_email();
                          $this.parent().find('.error_text').text(res.msg);
                      } else {
                          email_is_email = true;
                          changezhucebtn_email();
                          $this.parent().find('.error_text').text('');
                      }
                  }, error: function () {
                      email_is_email = false;
                      changezhucebtn_email();
                      layer.msg('服务器错误');
                  }
              })
          }
      })
      $('#register_email_password').bind('input propertychange', function () {
          var $this = $(this);
          if ($this.val()) {
              if ($this.val().length > 15 || $this.val().length < 6) {
                  email_is_pwd = false;
                  changezhucebtn_email();
                  $this.parent().find('.error_text').text('6-15位字母或数字组合');
              } else {
                  email_is_pwd = true;
                  changezhucebtn_email();
                  $this.parent().find('.error_text').text('');
              }
          }
      })

      $('#register_email_repassword').bind('input propertychange', function () {
          var $this = $(this);
          if ($this.val()) {
              if ($this.val().length > 15 || $this.val().length < 6) {
                  $this.parent().find('.error_text').text('6-15位字母或数字组合');
                  email_is_aginpwd = false;
                  changezhucebtn_email();
              } else if ($this.val() != $("#register_email_password").val()) {
                  email_is_aginpwd = false;
                  changezhucebtn_email();
                  $this.parent().find('.error_text').text('两次输入的密码不一致');
              } else {
                  email_is_aginpwd = true;
                  changezhucebtn_email();
                  $this.parent().find('.error_text').text('');
              }
          }
      })
      $('#email_realname').bind('input propertychange', function () {
          var $this = $(this);
          var reg = /^[\u4E00-\u9FA5]+$/;
          if ($this.val()) {
              if ($this.val().length > 25 || $this.val().length < 2 || reg.test($this.val()) == false) {
                  email_is_real_name = false
                  changezhucebtn_email()
                  $this.parent().find('.error_text').text('姓名格式错误');
              } else {
                  email_is_real_name = true
                  changezhucebtn_email()
                  $this.parent().find('.error_text').text('');
              }
          }else{
              if(is_real_auth == 2){
                  email_is_real_name = true
                  changezhucebtn_email()
                  $this.parent().find('.error_text').text('');
              }
          }
      })
      $('#email_idcard').bind('input propertychange', function () {
          var $this = $(this);
          if ($this.val()) {
              if ($this.val().length > 18 || $this.val().length < 15) {
                  email_is_idcard = false
                  changezhucebtn_email()
                  $this.parent().find('.error_text').text('证件号码错误');
              } else {
                  email_is_idcard = true
                  changezhucebtn_email()
                  $this.parent().find('.error_text').text('');
              }
          }else{
              if(is_real_auth == 2){
                  email_is_idcard = true
                  changezhucebtn_email()
                  $this.parent().find('.error_text').text('');
              }
          }
      })
    $('.hover_modal_item1').hover(function () {
      $('.hover_modal_item1 img').attr('src', '/static/images/to_sale_hover.png')
      $('.hover_modal_item1').css('background-color', '#018FFF')
      $('.hover_modal_item1 p').css('color', 'white')
      $('.comment').show()
    }, function () {
      $('.hover_modal_item1 img').attr('src', '/static/images/to_sale.png')
      $('.hover_modal_item1').css('background-color', 'white')
      $('.hover_modal_item1 p').css('color', '#222222')
      $('.comment').hide()
    })
    $(".xgkf_aq").click(function () {
      // var uid = '';
      // var name = '';
      // var avatar = '';
      // if(window.login_auth == 1){
      //   uid = user_session_json.login_user_id;
      //   name = user_session_json.login_account;
      //   avatar = user_session_json.login_head_img;
      // }
      var xgkf_ = "<?php echo get_xgkf_info(1); ?>";
     // window.open( xgkf_+"&uid="+uid+"&name="+name+"&avatar="+avatar);
     window.open( xgkf_);
    })
    $('.hover_modal_item2').hover(function () {
      $('.hover_modal_item2 img').attr('src', '/static/images/to_wx_hover.png')
      $('.hover_modal_item2').css('background-color', '#018FFF')
      $('.hover_modal_item2 p').css('color', 'white')
      $('.comment2').show()
    }, function () {
      $('.hover_modal_item2 img').attr('src', '/static/images/to_wx.png')
      $('.hover_modal_item2').css('background-color', 'white')
      $('.hover_modal_item2 p').css('color', '#222222')
      $('.comment2').hide()
    })
    $('.hover_modal_item3').hover(function () {
      $('.hover_modal_item3 img').attr('src', '/static/images/to_qq_hover.png')
      $('.hover_modal_item3').css('background-color', '#018FFF')
      $('.hover_modal_item3 p').css('color', 'white')
      $('.comment3').show()
    }, function () {
      $('.hover_modal_item3 img').attr('src', '/static/images/to_qq.png')
      $('.hover_modal_item3').css('background-color', 'white')
      $('.hover_modal_item3 p').css('color', '#222222')
      $('.comment3').hide()
    })
    $('.hover_modal_item4').hover(function () {
      $('.hover_modal_item4 img').attr('src', '/static/images/to_top_hover.png')
      $('.hover_modal_item4').css('background-color', '#018FFF')
      $('.hover_modal_item4 p').css('color', 'white')
    }, function () {
      $('.hover_modal_item4 img').attr('src', '/static/images/to_top.png')
      $('.hover_modal_item4 img').attr('src', '/static/images/to_top.png')
      $('.hover_modal_item4').css('background-color', 'white')
      $('.hover_modal_item4 p').css('color', '#222222')
    })

      //下一步
      $('.js-next-step.can_click').click(function () {
          $('.zhuce_mobile_part1').hide();
          $('.zhuce_mobile_part2').show();
      });
      $('.js-next-step1.can_click').click(function () {
          $('.zhuce_zhanghao_part1').hide();
          $('.zhuce_zhanghao_part2').show();
      });
      $('.js-next-step2.can_click').click(function () {
          $('.zhuce_email_part1').hide();
          $('.zhuce_email_part2').show();
      });
    //上一步
      $('.js-pre-step').click(function () {
          $('.zhuce_mobile_part2').hide();
          $('.zhuce_mobile_part1').show();
      })
      $('.js-pre-step1').click(function () {
          $('.zhuce_zhanghao_part2').hide();
          $('.zhuce_zhanghao_part1').show();
      })
      $('.js-pre-step2').click(function () {
          $('.zhuce_email_part2').hide();
          $('.zhuce_email_part1').show();
      })

    $('button.js-ajax-submit').on('click', function (e) {

      var $form = $(this).closest('.js-ajax-form');
      var url = $form.attr('action');
      var form_data = $form.serializeArray();
      $.post(url, form_data, function (res) {
        if (res.code == 0) {
          layer.msg(res.msg);
          return false;
        }
        layer.msg(res.msg);
        if (res.url) {
          setTimeout(function () {
            location.href = res.url;
          }, 1000);
        } else {
          setTimeout(function () {
            location.reload();
          }, 1000);
        }
      });
      return false;
    });


    $('a.js-ajax-btn').on('click', function (e) {
      var url = $(this).attr('href');
      $.get(url, function (res) {
        if (res.code == 0) {
          layer.msg(res.msg);
          return false;
        }
        layer.msg(res.msg);
        setTimeout(function () {
          location.reload();
        }, 1000);
      })
    })


  })
</script>
<script>
    window.login_auth = 0;
  $.ajax({
    type:'get',
    url:'<?php echo url("get_user_status"); ?>',
    success:function (res) {
      if(res.status!=0){
          window.login_auth= 1;
        $('.register-box').remove();//移除注册弹窗
        user_session_json = res.data;
        //登录信息
        $('#total_login').addClass('hide');
        $('#total_auth').removeClass('hide');
        $('#total_auth').find('img').attr('src',user_session_json.login_head_img);
        $('#total_auth').find('.user_account').text(user_session_json.login_account);

        usermenu_nav = "<?php echo $pc_navigation_spend; ?>";

        //用户导航菜单//静态化
        usermenu = '<a href="<?php echo url('User/userinfo'); ?>">\n' +
                '                  <li  class="';
        if(res.data.menu_controller_name=='user'){
          usermenu+='active';
        }
        usermenu +='">\n' +
                '                    '+usermenu_nav+'' +
                '                  </li>\n' +
                '                </a>';
        $('.js_usermune').empty().append(usermenu);
      }
      var login_account = res.data.cookie_login_account;
      var login_password = res.data.cookie_login_password;
      var last_login_account = res.data.cookie_last_login_account;
      //登录弹窗
      $('.login_modals').find('input[name=account]').val(res.data.cookie_login_account);
      $('.login_modals').find('input[name=password]').val(res.data.cookie_login_password);
      $('#forget_account').val(res.data.cookie_login_account);
      if(last_login_account == login_account && login_password != null&&window.login_auth!=1){
          //自动登录
          //$("#login_submit").trigger("click")
          $("#login_submit").click();
      }
    }
  })
  $('.js-home').click(function() {
			SetHome(window.location.href);
		});
		//设为首页
		function SetHome(url) {
			if(document.all) {
				document.body.style.behavior = 'url(#default#homepage)';
				document.body.setHomePage(url);
			} else {
				alert("您好,您的浏览器不支持自动设置页面为首页功能,请您手动在浏览器里设置该页面为首页!");
			}
		}
		//加入收藏
     function AddFavorite(sURL, sTitle) {
      sURL = encodeURI(sURL);
     try{
          window.external.addFavorite(sURL, sTitle);
     }catch(e) {
    try{
          window.sidebar.addPanel(sTitle, sURL, "");
     }catch (e) {
       alert("加入收藏失败，请使用Ctrl+D进行添加,或手动在浏览器里进行设置。");
     }
}
}

// 模拟点击事件 模拟点击 手机号注册/账号注册/邮箱注册
$(function(){

  var account_register_switch = "<?php echo $account_register_switch; ?>";
  var phonenum_register_switch = "<?php echo $phonenum_register_switch; ?>";
  var email_register_switch = "<?php echo $email_register_switch; ?>";
  setTimeout(function () {
    $('.zhuce_type_item').eq(0).click(); // 模拟点击
  },100);
  $('.zhuce_mobile_con').hide()
  $('.zhuce_zhanghao_con').hide()
  $('.zhuce_email_con').hide()

  if(account_register_switch == 1){

  }

});
// input 右侧x号 点击清除
$('body').on('focus', 'input[type=text],input[type=password],input[type=number]', function() {

$(this).siblings('.clear_texts1').show()

return false;
});
$('body').on('blur', 'input[type=text],input[type=password],input[type=number]', function() {
$(this).siblings('.clear_texts1').hide()
return false;
});
$('body').on('mousedown', '.clear_texts1', function() {
$(this).hide().siblings('input').val('').focus();
parent = $(this).closest('.jsclear').data('value');
if(parent!=undefined){
    change_but = "<?php echo $if_next; ?>">0?'registered_modal_next_btn':'registered_modal_pub_btn';
    if(parent='registered_modal_real'){
        change_but = 'registered_modal_pub_btn';
    }
    change_submit_btn($('.'+parent),$('.'+parent).find('.'+change_but))
}
return false;
});

// $(function() {
//   var nav = $('.all')
//   var wid = 0
//   $.each(nav.find('.act'),function(index,item) {
//     wid += $(item).width()*1
//   })
//   nav.css('width',wid)
// })

</script>
</html>

