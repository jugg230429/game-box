<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:108:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/recharge/paytype/add.html";i:1722672315;s:101:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/public/header.html";i:1632734362;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
            position: absolute;
            left: 5px;
            top: 37%;
        }
        .mailer-test .form-required {
            top: 15%;
        }
        .mailer-test .form-horizontal .control-label {
            width: 30%;
        }

        .btn.disabled, .btn[disabled], fieldset[disabled] .btn {
            background-color: #999;
            border-color: #999;
        }

        .btn.disabled:hover, .btn[disabled]:hover, fieldset[disabled] .btn:hover {
            background-color: #999;
            border-color: #999;
        }


        /*新加*/
        .dropdown-menu > .active > a, .dropdown-menu > .active > a:hover, .dropdown-menu > .active > a:focus {
            background-color: #1E91FF;
        }

        .dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus {
            background-color: #1E91FF;
        }

        tbody > .data_summary {
            background-color: #e6e6e6;
        }

    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
        var saveAsImage = 'http://<?php echo $_SERVER["HTTP_HOST"]; ?>/themes/admin_simpleboot3/public/assets/images/data_btn_download_n.png';
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <link rel="stylesheet" href="/themes/admin_simpleboot3/public/assets/css/bootstrap-select.css">
    <script src="/static/js/layer/layer.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap-select.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/defaults-zh_CN.js"></script>
    <link rel="stylesheet" type="text/css" media="all" href="/static/js/datejs/daterangepicker.css"/>
    <script type="text/javascript" src="/static/js/datejs/moment.min.js"></script>
    <script type="text/javascript" src="/static/js/datejs/daterangepicker.js"></script>
    <script>
        btn_tijiao_load_img_id = 0;
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container: 'body',
                html: true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
            $('.pagination .jspagerow').change(function () {
                value = $('.pagination .jspagerow option:selected').attr('vv');
                $('#page').remove();
                $('#search_form').append('<input type="hidden" id="page" name="row" value="' + value + '">');
                $('#search_btn').click();
            });

            $("body").bind("keydown", function (event) {
                if (event.keyCode == 116) {
                    event.preventDefault(); //阻止默认刷新
                    //location.reload();
                    //采用location.reload()在火狐下可能会有问题，火狐会保留上一次链接
                    location = location;
                }
            })
        });

        var unSelected = "#acb6c0";
        var selected = "#2C3E50";
        $(function () {
            $("select").css("color", unSelected);
            $("option").css("color", selected);
            $("select").change(function () {
                var selItem = $(this).val();
                if (selItem == $(this).find('option:first').val()) {
                    $(this).css("color", unSelected);
                } else {
                    $(this).css("color", selected);
                }
            });
        })

    </script>
    <script>
        // 更改button状态
        function change_submit_btn(consa, registe_btn) {
            j = 0;
            consa.find('input,select').each(function (i, n) {
                that = $(this);
                that.hasClass('jsmust')&&!that.val()?registe_btn.prop('disabled',true):j++;
            });
            if(j==consa.find('input,select').length){
                registe_btn.prop('disabled',false);
            }
        }
    </script>
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
        #think_page_trace_open {
        z-index: 9999;
    }
    </style>
    <?php endif; ?>

</head>
<body>
<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li class="active"><a href="javascript:;">新增<?php echo $promote_name; ?>支付参数</a></li>
        
    </ul>
    <form class="form-horizontal js-ajax-form margin-top-20" action="<?php echo url('add'); ?>" method="post">
        <input type="hidden" value="<?php echo $type; ?>">
        <div class="form-group">
            <label for="input-name" class="col-sm-2 control-label"></span>游戏名称：</label>
            <div class="col-md-6 col-sm-10 form-select">
                <select name="game_id" id="game_id" class="selectpicker " game_id="<?php echo input('request.game_id'); ?>" data-live-search="true" style="width: 420px;">
                    <option value="0">默认</option>
                    <?php $_result=get_game_list('id,game_name',[]);if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <option game-id="<?php echo $vo['id']; ?>" value="<?php echo $vo['id']; ?>" ><?php echo $vo['game_name']; ?></option>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label for="input-name" class="col-sm-2 control-label"><span class="form-required">*</span>渠道名称：</label>
            <div class="col-md-6 col-sm-10 form-select">
                <select name="promote_id" id="promote_id" class="selectpicker " data-live-search="true" style="width: 420px;">
                    <?php if(is_array($promote_list) || $promote_list instanceof \think\Collection || $promote_list instanceof \think\Paginator): $i = 0; $__LIST__ = $promote_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $vo['promote_id']; ?>" ><?php echo $vo['promote_name']; ?></option>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label for="input-name" class="col-sm-2 control-label"><span class="form-required">*</span>支付类型</label>
            <div class="col-md-6 col-sm-10 form-select">
                <select name="type" id="type" class="selectpicker " data-live-search="true" style="width: 420px;">
                    <option value="1" >支付宝</option>  
                    <option value="2" >微信</option> 
                </select>
            </div>
        </div>
        <div class="form-group">
            <label for="input-name" class="col-sm-2 control-label"><span class="form-required">*</span>商户号：</label>
            <div class="col-md-6 col-sm-10">
                <input type="text" class="form-control fl user-input" id="partner" name="partner">
            </div>
        </div>
        <div class="form-group">
            <label for="input-name" class="col-sm-2 control-label"><span class="form-required">*</span>秘钥：</label>
            <div class="col-md-6 col-sm-10">
                <input type="text" class="form-control fl user-input" id="key" name="key">
				<span  class="fl user-remarks "> 商户平台获取</span>
            </div>
        </div>
        <div class="form-group">
            <label for="input-name" class="col-sm-2 control-label">支付下单地址：</label>
            <div class="col-md-6 col-sm-10">
                <input type="text" class="form-control fl user-input" id="order_address" name="order_address">
				<span  class="fl user-remarks "> 商户支付请求地址</span>
            </div>
        </div>
        <div class="form-group">
            <label for="input-name" class="col-sm-2 control-label">通道编码：</label>
            <div class="col-md-6 col-sm-10">
                <input type="text" class="form-control fl user-input" id="channel_coding" name="channel_coding">
				 <span  class="fl user-remarks ">通道编码</span>
            </div>
        </div>
        <div class="form-group">
            <label for="input-name" class="col-sm-2 control-label">回调ip组：</label>
            <div class="col-md-6 col-sm-10">
                <input type="text" class="form-control fl user-input" id="callback_ip" name="callback_ip">
				 <span  class="fl user-remarks ">英文逗号隔开</span>
            </div>
        </div>
        <div class="form-group">
            <label for="input-name" class="col-sm-2 control-label"><span class="form-required">*</span>权重：</label>
            <div class="col-md-6 col-sm-10">
                <input type="text" class="form-control fl user-input" id="weight" name="weight">
            </div>
        </div>
   
        <div class="form-group">
            <label class="col-sm-2 control-label"><span class="form-required">&nbsp;</span>启用状态：</label>
            <div class="col-md-6 col-sm-10">
                <label class="radio-inline fl mr100">
                    <input type="radio" name="status" value="0"> 禁用
                </label>
                <label class="radio-inline fl">
                    <input type="radio" name="status" value="1" checked> 启用
                </label>
				<span  class="fl user-remarks ml26">微端微信APP支付开启状态</span>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-1 col-sm-10">
                <button type="submit" class="btn btn-primary js-ajax-submit save-btn">确定</button>
            </div>
        </div>
    </form>
</div>
<script src="/static/js/admin.js"></script>
</body>
</html>