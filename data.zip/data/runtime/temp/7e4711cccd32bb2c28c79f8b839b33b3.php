<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:110:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/recharge/paytype/lists.html";i:1722673476;s:101:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/public/header.html";i:1632734362;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
            position: absolute;
            left: 5px;
            top: 37%;
        }
        .mailer-test .form-required {
            top: 15%;
        }
        .mailer-test .form-horizontal .control-label {
            width: 30%;
        }

        .btn.disabled, .btn[disabled], fieldset[disabled] .btn {
            background-color: #999;
            border-color: #999;
        }

        .btn.disabled:hover, .btn[disabled]:hover, fieldset[disabled] .btn:hover {
            background-color: #999;
            border-color: #999;
        }


        /*新加*/
        .dropdown-menu > .active > a, .dropdown-menu > .active > a:hover, .dropdown-menu > .active > a:focus {
            background-color: #1E91FF;
        }

        .dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus {
            background-color: #1E91FF;
        }

        tbody > .data_summary {
            background-color: #e6e6e6;
        }

    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
        var saveAsImage = 'http://<?php echo $_SERVER["HTTP_HOST"]; ?>/themes/admin_simpleboot3/public/assets/images/data_btn_download_n.png';
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <link rel="stylesheet" href="/themes/admin_simpleboot3/public/assets/css/bootstrap-select.css">
    <script src="/static/js/layer/layer.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap-select.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/defaults-zh_CN.js"></script>
    <link rel="stylesheet" type="text/css" media="all" href="/static/js/datejs/daterangepicker.css"/>
    <script type="text/javascript" src="/static/js/datejs/moment.min.js"></script>
    <script type="text/javascript" src="/static/js/datejs/daterangepicker.js"></script>
    <script>
        btn_tijiao_load_img_id = 0;
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container: 'body',
                html: true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
            $('.pagination .jspagerow').change(function () {
                value = $('.pagination .jspagerow option:selected').attr('vv');
                $('#page').remove();
                $('#search_form').append('<input type="hidden" id="page" name="row" value="' + value + '">');
                $('#search_btn').click();
            });

            $("body").bind("keydown", function (event) {
                if (event.keyCode == 116) {
                    event.preventDefault(); //阻止默认刷新
                    //location.reload();
                    //采用location.reload()在火狐下可能会有问题，火狐会保留上一次链接
                    location = location;
                }
            })
        });

        var unSelected = "#acb6c0";
        var selected = "#2C3E50";
        $(function () {
            $("select").css("color", unSelected);
            $("option").css("color", selected);
            $("select").change(function () {
                var selItem = $(this).val();
                if (selItem == $(this).find('option:first').val()) {
                    $(this).css("color", unSelected);
                } else {
                    $(this).css("color", selected);
                }
            });
        })

    </script>
    <script>
        // 更改button状态
        function change_submit_btn(consa, registe_btn) {
            j = 0;
            consa.find('input,select').each(function (i, n) {
                that = $(this);
                that.hasClass('jsmust')&&!that.val()?registe_btn.prop('disabled',true):j++;
            });
            if(j==consa.find('input,select').length){
                registe_btn.prop('disabled',false);
            }
        }
    </script>
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
        #think_page_trace_open {
        z-index: 9999;
    }
    </style>
    <?php endif; ?>

</head>
<body>
<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li class="active first" ><a href="#A" data-toggle="tab">支付宝</a></li>
        <li class="second"><a href="#B" data-toggle="tab">微信（扫码/H5）</a></li>
        <?php if(PERMI != 1): ?>
        <li class="promote"><a href="#E" data-toggle="tab">支付渠道</a></li>
        <!-- <li><a href="<?php echo url('weiduan'); ?>">微信（微端）</a></li> -->
        <?php endif; ?>
        <li class="four"><a href="#C" data-toggle="tab">平台币</a></li>
        <li class="five"><a href="#D" data-toggle="tab">绑币</a></li>
        <li class="six"><a href="#G" data-toggle="tab">支付宝（提现）</a></li>
        <span class="title_remark">说明：用于配置网站所用到的支付功能相关参数</span>
    </ul>
    <form class="form-horizontal js-ajax-form " role="form" action="<?php echo url('set_pay'); ?>"
          method="post">
        <fieldset>
            <div class="tabbable">
                <div class="tab-content">
                    <div class="tab-pane active" id="A">
                        <div class="describe" style="margin-bottom: 20px">
                            <div>说明①：支付宝可申请电脑网站支付、手机网站支付、APP支付，根据运营需求申请对应支付方式</div>
                            <div>说明②：H5游戏需申请当面付</div>
                            <div>说明③：当在服务平台打包上架版游戏包时，选择第三方支付则为WAP支付，选择苹果内购则为苹果内购支付；当打包非上架版游戏包时，选择第三方支付则为WAP支付，选择苹果内购则为APP支付（android版游戏无需设置）</div>
                        </div>
						<div class="clear"></div>
                        <div class="form-group">
                            <label for="input-site-name" class="col-sm-2 control-label"><span
                                    class="form-required"><!-- * --></span>启用状态</label>
                            <div class="col-md-6 col-sm-10">
							    <div class="fl user-input">
                                    <label class="fl mr50 pt7"><input type="radio" name="zfb[status]" value="1" <?php if($zfb['status'] == 1): ?> checked <?php endif; ?>> 启用</label>
                                    <label class="fl pt7"><input type="radio" name="zfb[status]" value="0" <?php if($zfb['status'] == 0): ?> checked <?php endif; ?>> 禁用</label>
							    </div>
                                <span  class="fl user-remarks  l18" style="line-height: 36px;">
                                    支付宝启用状态，控制多个站点内是否显示支付宝支付入口；
                                </span>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-offset-1 col-sm-10">
                                <button type="submit" class="btn btn-primary js-ajax-submit save-btn" data-refresh="1">
                                    <?php echo lang('SAVE'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="B">
                        <div class="describe">
                            <div>说明①：微信（扫码）支付即支持pc扫码支付，wap/H5支付</div>
                            <div>说明②：推荐在微信公众平台配置公众号，申请开通扫码支付权限</div>
                            <div>说明③：仅申请微信（扫码）支付，不需要提供文网文</div>
                        </div>

                        <div class="form-group">
                            <label for="input-site_seo_title" class="col-sm-2 control-label">启用状态：</label>
                            <div class="col-md-8 col-sm-10">
                               <label class="fl mr50 pt7"> <input type="radio" name="wx[status]" value="1" <?php if($wxscan['status'] == 1): ?> checked <?php endif; ?>> 启用</label>
                               <label class="fl pt7"> <input type="radio" name="wx[status]" value="0" <?php if($wxscan['status'] == 0): ?> checked <?php endif; ?>> 禁用</label>
                                 <span  class="fl user-remarks ml25">
                                    微信扫码启用状态，控制在PC官网、WAP站、SDK、推广系统官网上是否显示微信支付入口
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-1 col-sm-10">
                                <button type="submit" class="btn btn-primary js-ajax-submit save-btn" data-refresh="0">
                                    确定
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="C" style="margin-top: -40px;">
<!--                        <div class="describe">-->

<!--                        </div>-->
                        <div class="form-group" style="margin-top: 50px">
                            <label for="input-site_seo_title" class="col-sm-2 control-label">启用状态：</label>
                            <div class="col-md-6 col-sm-10">
                                <div class="fl pt7">
                                    <input type="radio" name="ptb_pay[status]" value="1" <?php if($ptb_pay['status'] == 1): ?> checked <?php endif; ?>> 启用<label class="mr50"></label>
                                    <input type="radio" name="ptb_pay[status]" value="0" <?php if($ptb_pay['status'] == 0): ?> checked <?php endif; ?>> 禁用
                                </div>
                                <span  class="fl user-remarks ml33" style="margin-left: 20px;margin-top: 1px;">
                                    默认开启，控制SDK支付、推广后台-会长代充时是否开启平台币支付
                                </span>
                            </div>
                        </div>
                        <div class="form-group" style="margin-top: 20px">
                            <label for="input-site_seo_title" class="col-sm-2 control-label">充值状态：</label>
                            <div class="col-md-6 col-sm-10">
                                <div class="fl pt7">
                                    <input type="radio" name="ptb_pay[recharge_status]" value="on" <?php if($ptb_pay['config']['recharge_status'] != 'off'): ?> checked <?php endif; ?>> 启用<label class="mr50"></label>
                                    <input type="radio" name="ptb_pay[recharge_status]" value="off" <?php if($ptb_pay['config']['recharge_status'] == 'off'): ?> checked <?php endif; ?>> 禁用
                                </div>
                                <span  class="fl user-remarks ml33" style="width:800px;margin-left: 20px;margin-top: 1px;">
                                    默认开启，控制SDK-余额-平台币、PC官网-充值-支付宝/微信支付、WAP站/盒子APP-我的-账户充值页是否显示平台币充值入口，禁用时不显示
                                </span>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-offset-1 col-sm-10">
                                <button type="submit" class="btn btn-primary js-ajax-submit save-btn" data-refresh="0">
                                    确定
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane" id="D"  style="margin-top: -40px;">
<!--                        <div class="describe">-->

<!--                        </div>-->
                        <div class="form-group" style="margin-top: 50px">
                            <label for="input-site_seo_title" class="col-sm-2 control-label">启用状态：</label>
                            <div class="col-md-6 col-sm-10">
                                <div class="fl pt7">
                                    <input type="radio" name="bind_pay[status]" value="1" <?php if($bind_pay['status'] == 1): ?> checked <?php endif; ?>> 启用<label class="mr50"></label>
                                    <input type="radio" name="bind_pay[status]" value="0" <?php if($bind_pay['status'] == 0): ?> checked <?php endif; ?>> 禁用
                                </div>
                                <span  class="fl user-remarks ml33" style="margin-left: 20px;margin-top: 1px;">
                                    默认开启，控制SDK内绑币支付是否开启
                                </span>
                            </div>
                        </div>
                        <div class="form-group" style="margin-top: 20px">
                            <label for="input-site_seo_title" class="col-sm-2 control-label">充值状态：</label>
                            <div class="col-md-6 col-sm-10">
                                <div class="fl pt7">
                                    <input type="radio" name="bind_pay[recharge_status]" value="on" <?php if($bind_pay['config']['recharge_status'] != 'off'): ?> checked <?php endif; ?>> 启用<label class="mr50"></label>
                                    <input type="radio" name="bind_pay[recharge_status]" value="off" <?php if($bind_pay['config']['recharge_status'] == 'off'): ?> checked <?php endif; ?>> 禁用
                                </div>
                                <span  class="fl user-remarks ml33" style="width: 800px;margin-left: 20px;margin-top: 1px;">
                                    默认开启，控制PC官网-充值-、WAP站/盒子APP-我的-账户充值页是否显示绑币充值入口，禁用时不显示
                                </span>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-offset-1 col-sm-10">
                                <button type="submit" class="btn btn-primary js-ajax-submit save-btn" data-refresh="0">
                                    确定
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="G">
                        <div class="describe" style="margin-bottom: 20px">
                            <div>说明①：企业开发者若涉及 资金类支出接口 接入，必须使用 公钥证书 方式</div>
                        </div>
                        <div class="clear"></div>
                        <div class="form-group">
                            <label for="input-site-name" class="col-sm-2 control-label"><span
                                    class="form-required"><!-- * --></span>合作伙伴身份ID（PID）</label>
                            <div class="col-md-6 col-sm-10">
                                <input type="text" class="form-control fl user-input "   name="zfb_tx[pid]"
                                       value="<?php echo (isset($zfb_tx['config']['pid']) && ($zfb_tx['config']['pid'] !== '')?$zfb_tx['config']['pid']:''); ?>">
                                <span  class="fl user-remarks l18" style="width: 800px;">合作账户中心--mapi网关产品密钥--合作伙伴身份（PID）份者id，以2088开头的16位纯数字</span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="input-site-name" class="col-sm-2 control-label"><span
                                    class="form-required"><!-- * --></span>MD5密钥</label>
                            <div class="col-md-6 col-sm-10">
                                <input type="text" class="form-control fl user-input"   name="zfb_tx[key]"
                                       value="<?php echo (isset($zfb_tx['config']['key']) && ($zfb_tx['config']['key'] !== '')?$zfb_tx['config']['key']:''); ?>">
                                <span  class="fl user-remarks ">账户中心--mapi网关产品密钥--合作伙伴密钥</span>

                            </div>
                        </div>

                        <div class="form-group">
                            <label for="input-site-name" class="col-sm-2 control-label"><span
                                    class="form-required"><!-- * --></span>打款帐户</label>
                            <div class="col-md-6 col-sm-10">
                                <input type="text" class="form-control fl user-input"   name="zfb_tx[account]"
                                       value="<?php echo (isset($zfb_tx['config']['account']) && ($zfb_tx['config']['account'] !== '')?$zfb_tx['config']['account']:''); ?>">
                                <span  class="fl user-remarks ">卖家支付宝帐户</span>

                            </div>
                        </div>

                        <div class="form-group">
                            <label for="input-site-name" class="col-sm-2 control-label"><span
                                    class="form-required"><!-- * --></span>APPID</label>
                            <div class="col-md-6 col-sm-10">
                                <input type="text" class="form-control fl user-input"   name="zfb_tx[appid]"
                                       value="<?php echo (isset($zfb_tx['config']['appid']) && ($zfb_tx['config']['appid'] !== '')?$zfb_tx['config']['appid']:''); ?>">
                                <span  class="fl user-remarks ">应用APPID</span>

                            </div>
                        </div>


                        <div class="form-group">
                            <div class="col-sm-offset-1 col-sm-10">
                                <button type="submit" class="btn btn-primary js-ajax-submit save-btn" data-refresh="1">
                                    <?php echo lang('SAVE'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </fieldset>
    </form>
    <div  id="E" style="display: none;">
        <div class="describe">
            <div>支付渠道列表</div>
        </div>
        <form id="search_form" class="well form-inline  fr" method="get" action="<?php echo url('lists'); ?>">
            <?php if(AUTH_GAME == 1): ?>
                <select name="game_id" id="game_id" class="selectpicker " game_id="<?php echo input('request.game_id'); ?>" data-live-search="true" data-size="8" style="width: 100px;">
                    <option value="">游戏名称</option>
                    <?php $_result=get_game_list('id,game_name');if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <option game-id="<?php echo $vo['id']; ?>" value="<?php echo $vo['id']; ?>" ><?php echo $vo['game_name']; ?></option>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
            <?php endif; ?>
            <input type="submit" class="btn btn-primary" id="search_btn" value="搜索" />
        </form>
        <form class="js-ajax-form" action="" method="post">
            <div class="table-actions position" style="margin-left: -10px;">
                <a href="<?php echo url('add'); ?>" class="btn btn-danger  mtb17" >新增</a>
                <button class="btn btn-danger  js-ajax-submit  mtb17" type="submit"
                        data-action="<?php echo url('del'); ?>" data-subcheck="true" data-msg="您确定删除吗？">
                    删除
                </button>
            </div>
            <table class="table table-hover table-bordered">
                <thead>
                <tr>
                    <th><input type="checkbox" class="js-check-all" data-direction="x" data-checklist="js-check-x"></th>
                    <th>游戏ID</th>
                    <th>游戏名称</th>
                    <th>渠道</th>
                    <th>支付类型</th>
                    <th>商户号</th>
                    <th>秘钥</th>
                    <th>下单地址</th>
                    <th>通道编码</th>
                    <th>回调IP</th>
                    <th>权重</th>
                    <th>启用状态</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody>
                <?php if(empty($data_lists) || (($data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator ) && $data_lists->isEmpty())): ?>
                    <tr><td colspan="8" style="text-align: center;">暂无数据</td></tr>
                    <?php else: if(is_array($data_lists) || $data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator): if( count($data_lists)==0 ) : echo "" ;else: foreach($data_lists as $key=>$vo): ?>
                        <tr>
                            <th><input type="checkbox" class="js-check" data-yid="js-check-y" data-xid="js-check-x" name="ids[]"
                                       value="<?php echo $vo['id']; ?>" title="ID:<?php echo $vo['id']; ?>"></th>
                            <td><?php echo $vo['game_id']; ?></td>
                            <td><?php echo $vo['game_name']; ?></td>
                            <td><?php echo $promote_list[$vo['promote_id']]['promote_name']; ?></td>
                            <td><?php echo $type_list[$vo['type']]; ?></td>
                            <td><?php echo $vo['partner']; ?></td>
                            <td><?php echo $vo['key']; ?></td>
                            <td><?php echo $vo['order_address']; ?></td>
                            <td><?php echo $vo['channel_coding']; ?></td>
                            <td><?php echo $vo['callback_ip']; ?></td>
                            <td><?php echo $vo['weight']; ?></td>
                            <td><span <?php if($vo['status'] == 1): ?> class="label label-success"<?php else: ?>class="label label-danger"<?php endif; ?>><?php echo $vo['status_name']; ?></span></td>
                            <td>
                                <a href="<?php echo url('edit',['id'=>$vo['id']]); ?>" >编辑</a>
                                <a href="<?php echo url('del',['ids'=>$vo['id']]); ?>" class="js-ajax-delete" data-msg="您确定删除吗？">删除</a>
                            </td>
                        </tr>
                    <?php endforeach; endif; else: echo "" ;endif; endif; ?>
                </tbody>
            </table>
            <div class="pagination">
                <?php echo $page; ?>
            </div>
        </form>
    </div>

</div>
<script type="text/javascript" src="/static/js/admin.js"></script>
<script>
    $('.promote').click(function() {
        $('#E').show()
        $('#A').hide()
        $('#B').hide()
        $('#C').hide()
        $('#D').hide()
    })

    $('.first').click(function() {
        $('#A').show().siblings().hide()
        $('#E').hide()
    })
    $('.second').click(function() {
        $('#B').show().siblings().hide()
        $('#E').hide()
    })
    $('.third').click(function() {
        $('#F').show().siblings().hide()
        $('#E').hide()
    })
    $('.four').click(function() {
        $('#C').show().siblings().hide()
        $('#E').hide()
    })
    $('.five').click(function() {
        $('#D').show().siblings().hide()
        $('#E').hide()
    })
    $('.six').click(function() {
        $('#G').show().siblings().hide()
        $('#E').hide()
    })

    game_id = $("#game_id").attr('game_id');
    $("#game_id").selectpicker('val', game_id);

    var is_promote = "<?php echo $is_promote; ?>";
    if(is_promote==1){
        $(".promote").trigger('click');
        $('.promote').addClass('active').siblings().removeClass('active');
    }

</script>
</body>
</html>
