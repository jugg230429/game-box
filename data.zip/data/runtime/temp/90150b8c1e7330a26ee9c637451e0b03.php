<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:109:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/promote/promote/lists.html";i:1632734360;s:101:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/public/header.html";i:1632734362;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
            position: absolute;
            left: 5px;
            top: 37%;
        }
        .mailer-test .form-required {
            top: 15%;
        }
        .mailer-test .form-horizontal .control-label {
            width: 30%;
        }

        .btn.disabled, .btn[disabled], fieldset[disabled] .btn {
            background-color: #999;
            border-color: #999;
        }

        .btn.disabled:hover, .btn[disabled]:hover, fieldset[disabled] .btn:hover {
            background-color: #999;
            border-color: #999;
        }


        /*新加*/
        .dropdown-menu > .active > a, .dropdown-menu > .active > a:hover, .dropdown-menu > .active > a:focus {
            background-color: #1E91FF;
        }

        .dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus {
            background-color: #1E91FF;
        }

        tbody > .data_summary {
            background-color: #e6e6e6;
        }

    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
        var saveAsImage = 'http://<?php echo $_SERVER["HTTP_HOST"]; ?>/themes/admin_simpleboot3/public/assets/images/data_btn_download_n.png';
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <link rel="stylesheet" href="/themes/admin_simpleboot3/public/assets/css/bootstrap-select.css">
    <script src="/static/js/layer/layer.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap-select.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/defaults-zh_CN.js"></script>
    <link rel="stylesheet" type="text/css" media="all" href="/static/js/datejs/daterangepicker.css"/>
    <script type="text/javascript" src="/static/js/datejs/moment.min.js"></script>
    <script type="text/javascript" src="/static/js/datejs/daterangepicker.js"></script>
    <script>
        btn_tijiao_load_img_id = 0;
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container: 'body',
                html: true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
            $('.pagination .jspagerow').change(function () {
                value = $('.pagination .jspagerow option:selected').attr('vv');
                $('#page').remove();
                $('#search_form').append('<input type="hidden" id="page" name="row" value="' + value + '">');
                $('#search_btn').click();
            });

            $("body").bind("keydown", function (event) {
                if (event.keyCode == 116) {
                    event.preventDefault(); //阻止默认刷新
                    //location.reload();
                    //采用location.reload()在火狐下可能会有问题，火狐会保留上一次链接
                    location = location;
                }
            })
        });

        var unSelected = "#acb6c0";
        var selected = "#2C3E50";
        $(function () {
            $("select").css("color", unSelected);
            $("option").css("color", selected);
            $("select").change(function () {
                var selItem = $(this).val();
                if (selItem == $(this).find('option:first').val()) {
                    $(this).css("color", unSelected);
                } else {
                    $(this).css("color", selected);
                }
            });
        })

    </script>
    <script>
        // 更改button状态
        function change_submit_btn(consa, registe_btn) {
            j = 0;
            consa.find('input,select').each(function (i, n) {
                that = $(this);
                that.hasClass('jsmust')&&!that.val()?registe_btn.prop('disabled',true):j++;
            });
            if(j==consa.find('input,select').length){
                registe_btn.prop('disabled',false);
            }
        }
    </script>
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
        #think_page_trace_open {
        z-index: 9999;
    }
    </style>
    <?php endif; ?>

<link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/pro_promote.css" rel="stylesheet">
</head>

<body>
<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li class="active"><a href="<?php echo url('promote/lists'); ?>">渠道列表</a></li>
        <!-- <li><a href="<?php echo url('add'); ?>">添加渠道</a></li> -->
        <li class=""><a href="<?php echo url('promote/promote_level'); ?>">等级划分</a></li>
    </ul>
    <form id="search_form" class="well form-inline fr" method="get" action="<?php echo url('lists'); ?>">
        <select name="promote_id" id="promote_id" class="selectpicker bs-select-hidden" promote_id="<?php echo input('request.promote_id'); ?>" data-size="8" data-live-search="true" style="width: 100px;">
            <option value="">渠道ID</option>
            <?php $_result=get_promote_list();if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <option game-id="<?php echo $vo['id']; ?>" value="<?php echo $vo['id']; ?>" ><?php echo $vo['id']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </select>
        <select name="account" id="account" class="selectpicker bs-select-hidden" account="<?php echo input('request.account'); ?>" data-live-search="true" data-size="8" style="width: 100px;">
            <option value="">渠道账号</option>
            <?php $_result=get_promote_list();if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <option value="<?php echo $vo['account']; ?>" ><?php echo $vo['account']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </select>
        <?php $pmap['parent_id'] = 0 ?>
        <select name="parent_id" id="parent_id" class="selectpicker bs-select-hidden" parent_id="<?php echo input('request.parent_id'); ?>" data-live-search="true" data-size="8" style="width: 100px;">
            <option value="">上线渠道</option>
            <?php $_result=get_promote_list($pmap);if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <option value="<?php echo $vo['id']; ?>" ><?php echo $vo['account']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </select>
        <select name="busier_id" id="busier_id" class="selectpicker bs-select-hidden" busier_id="<?php echo input('request.busier_id'); ?>" data-live-search="true" data-size="8" style="width: 100px;">
            <option value="">所属商务</option>
            <option value="0" >官方</option>
            <?php $_result=get_business_lists([],'id,account');if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <option value="<?php echo $vo['id']; ?>" ><?php echo $vo['account']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </select>
        <select name="register_type" id="register_type" class="selectpicker" register_type="<?php echo input('request.register_type'); ?>" style="width: 120px;">
            <option value="">类型</option>
            <option value="0">个人</option>
            <option value="1">公会</option>
            <option value="2">公众号</option>
            <option value="3">其它</option>
        </select>
        <select name="level" id="level" class="selectpicker" level="<?php echo input('request.level'); ?>" style="width: 120px;">
            <option value="">等级</option>
            <option value="1">一级渠道</option>
            <option value="2">二级渠道</option>
            <option value="3">三级渠道</option>
        </select>

        <select name="status" id="status" class="selectpicker" status="<?php echo input('request.status'); ?>" style="width: 120px;">
            <option value="">显示状态</option>
            <option value="1">正常</option>
            <option value="0">待审核</option>
            <option value="-1">已锁定</option>
        </select>
        <select name="promote_level" id="promote_level" class="selectpicker" status="<?php echo input('request.promote_level'); ?>" style="width: 120px;">
            <?php $promote_level = cmf_get_option('promote_level_set'); ?>
                <option value="">推广等级</option>
            <?php if(is_array($promote_level) || $promote_level instanceof \think\Collection || $promote_level instanceof \think\Paginator): $i = 0; $__LIST__ = $promote_level;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                <option value="<?php echo $vo['level']; ?>"><?php echo $vo['level_name']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </select>

        <input type="submit" class="btn btn-search" id="search_btn" value="搜索" />
        <a class="btn btn-clear" href="<?php echo url('lists'); ?>">清空</a>
        <a class="btn btn-export js-ajax-dialog-btn-xz" data-msg="确定导出吗？" href="<?php echo url('Export/expUser',array_merge(['id'=>1,'xlsname'=>'渠道列表'],input())); ?>">导出</a>
    </form>
    <form class="js-ajax-form" action="" method="post">
        <div class="table-actions position" style="margin-left: -10px;">
            <a href="<?php echo url('add'); ?>" class="btn btn-success   js-ajax-submit mbt17">新增</a>
            <button class="btn btn-success   js-ajax-submit mbt17" type="submit"
                    data-action="<?php echo url('changeStatus',['status'=>0]); ?>" data-subcheck="true" data-msg="您确定审核吗？">
                审核
            </button>
            <button class="btn btn-success   js-ajax-submit mbt17" type="submit"
                    data-action="<?php echo url('changeStatus',['status'=>1,'type'=>'lock']); ?>" data-subcheck="true" data-msg="您确定锁定吗？">
                锁定
            </button>
            <button class="btn btn-success   js-ajax-submit mbt17" type="submit"
                    data-action="<?php echo url('changeStatus',['status'=>-1,'type'=>'lock']); ?>" data-subcheck="true" data-msg="您确定解锁吗？">
                解锁
            </button>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <button class="btn   js-ajax-submit mtb17 btn-audit" type="submit"
                    data-action="<?php echo url('set_config_auto_audit',['status'=>$autostatus]); ?>" data-subcheck="false" data-msg="您确定操作吗？">
                <input type="checkbox" id="auto-check" name="" <?php if($autostatus == 1): ?>checked<?php endif; ?> class="auto-checkbox promote_auto_audit"><label for="auto-check" class="fl"></label><div class="span-audit"> 自动审核</div>
            </button>
        </div>
        <div style="overflow: auto hidden; width:100%">
        <table class="table table-hover table-bordered" style="margin-left: 0px;">
            <thead>
            <tr style="white-space: nowrap;">
                <th width="15">

                    <input type="checkbox" id="all-checkbox" class="table-item-checkbox js-check-all" data-direction="x" data-checklist="js-check-x">
                    <label for="all-checkbox" class=""></label>
                </th>
                <th>ID</th>
                <th>渠道账号</th>
                <th>姓名</th>
                <th>手机号</th>
                <th>渠道押金</th>
                <th>平台币余额</th>
                <?php if(AUTH_USER == 1): ?><th>总流水</th><?php endif; ?>
                <th>总注册</th>
                <th>结算类型</th>
                <th>推广等级</th>
                <th>渠道类型</th>
                <th>自动结算周期/天</th>
                <th>不可推广游戏</th>
                <th>注册时间</th>
                <th>最后登录时间</th>
                <th>等级</th>
                <th>上线渠道</th>
                <th>商务专员</th>
                <th>状态</th>
                <th width="130">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if(empty($data_lists) || (($data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator ) && $data_lists->isEmpty())): ?>
                <tr><td colspan="21" style="text-align: center;">暂无数据</td></tr>
                <?php else: if(is_array($data_lists) || $data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator): if( count($data_lists)==0 ) : echo "" ;else: foreach($data_lists as $key=>$vo): 
                        $total_balance += $vo['balance_coin'];
                        $pay_amount = get_promote_user_pay($vo['id']);
                        $total_amount += $pay_amount;
                        $total_count += $vo['user_count'];
                     ?>
                    <tr style="white-space: nowrap;">
                        <td>
                            <input type="checkbox" id="ids-checkbox<?php echo $vo['id']; ?>" class="table-item-checkbox js-check"  data-yid="js-check-y" data-xid="js-check-x" name="ids[]"
                            value="<?php echo $vo['id']; ?>" >
                            <label for="ids-checkbox<?php echo $vo['id']; ?>" class=""></label>
                        </td>
                        <td><?php echo $vo['id']; ?></td>
                        <td><?php echo $vo['account']; ?></td>
                        <td><?php echo $vo['real_name']; ?></td>
                        <td><?php echo $vo['mobile_phone']; ?></td>
                        <td><a href="javascript:;" class="editCashTab underline" data-title="修改已交押金" promote-id="<?php echo $vo['id']; ?>"  field='cash_money' ><?php echo $vo['cash_money']; ?></a></td>
                        <td><?php echo $vo['balance_coin']; ?></td>
                        <?php if(AUTH_USER == 1): ?><td><?php echo $pay_amount; ?></td><?php endif; ?>
                        <td><?php echo $vo['user_count']; ?></td>
                        <td><?php echo get_info_status($vo['pattern'],21); ?></td>
                        <td><?php echo $vo['level_name']; ?></td>
                        <td><?php echo get_info_status($vo['register_type'],28); ?></td>
                        <!-- 自动结算周期 -->
                        <td>
                            <?php if($vo['promote_level'] == 1): ?>
                                <a href="javascript:;" class="editTab underline" data-title="自动结算周期" promote-id="<?php echo $vo['id']; ?>" promote-account="<?php echo $vo['account']; ?>"><?php echo $vo['settlement_day_period']; ?></a>
                            <?php else: ?>
                            --
                            <?php endif; ?>

                        </td>

                        <td><?php if($vo['promote_level'] == 1): ?><a href="javascript:void(0);" class="ajax-view" data-id="<?php echo $vo['id']; ?>"><?php if(empty($vo['game_ids']) || (($vo['game_ids'] instanceof \think\Collection || $vo['game_ids'] instanceof \think\Paginator ) && $vo['game_ids']->isEmpty())): ?>0<?php else: ?><?php echo count(explode(',',$vo['game_ids'])); endif; ?></a><?php else: ?>--<?php endif; ?></td>
                        <td><?php echo date('Y-m-d H:i:s',$vo['create_time']); ?></td>
                        <td><?php echo get_login_time($vo['last_login_time']); ?></td>
                        <td><?php echo $vo['parent_id']==0?'一级渠道':($vo['promote_level']==2?'二级渠道':'三级渠道'); ?></td>
                        <td><?php echo $vo['parent_id']==0?get_promote_name($vo['id']):get_promote_name($vo['parent_id']); ?></td>
                        <td><?php echo $vo['busier_id']==0?官方:get_business_entity($vo['busier_id'],'account')['account']; ?></td>
                        <td>
                            <span <?php if($vo['status'] == 1): ?> class="label" style="color: #3FAD46;font-size:14px" <?php elseif($vo['status'] == 0): ?>class="label " style="color: #f0ad4e;font-size:14px"<?php else: ?>class="label" style="color:#d9534f;font-size:14px"<?php endif; ?>><?php echo get_info_status($vo['status'],10); ?></span>
                        </td>
                        <td>
                            <?php if($vo['status'] !=  0): ?>
                                <a href="<?php echo url('edit',['id'=>$vo['id']]); ?>">编辑</a>
                            <?php endif; ?>
                            <a href="<?php echo url('changeStatus',['ids'=>$vo['id'],'status'=>$vo['status'],'type'=>'lock']); ?>" class="js-ajax-dialog-btn"><?php echo get_info_status($vo['status'],11); ?></a>

                            <?php if($vo['status'] ==  0): ?>
                                <a href="<?php echo url('del',['ids'=>$vo['id']]); ?>" class="js-ajax-dialog-btn" style="color: red">删除</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                <tr style="background: #E4E4E4;">
                    <td colspan="3">累计汇总</td>
                    <td></td>
                    <td></td>
                    <td style="color:rgba(255, 177, 112)"><strong><?php echo sprintf("%.2f",$total_cash_money); ?></strong></td>
                    <td style="color:rgba(255, 177, 112)"><strong><?php echo sprintf("%.2f",$total_balance_coin); ?></strong></td>
                    <td style="color:rgba(255, 177, 112)"><strong><?php echo sprintf("%.2f",$total_pay_amount); ?></strong></td>
                    <td style="color:rgba(255, 177, 112)"><strong><?php echo $total_user_count; ?></strong></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
         </div>
    </form>
    <div class="pagination"><?php echo $page; ?>

    </div>
</div>
<!-- <div class="pro_promot" style="display:none">
    <form action="<?php echo url('Promote/savePromoteGame'); ?>" id="ajaxForm" method="post" />
    <input type="hidden" name="promote_id" id="se_promote_id" value="" />
    <div class="pro_promot_main">
        <div class="pro_promot_title">
            <div class="fl pro_promot_title_text">
                <div class="fl pro_promot_title_bigtext">不可推广游戏</div>（选中的游戏将不在推广后台展示，渠道不可进行游戏申请并推广；二三级渠道推广权限同一级）</div>
            <div class="pro_promot_close fr" style="display: none;"><img src="/themes/admin_simpleboot3/public/assets/images/pro_promot_close.png"></div>
        </div>
        <div class="pro_promot_con">
            <div class="pro_promot_account"><div class="pro_promot_select_title fl">渠道账号：</div><span class="pro_promot_number fl"></span></div>
            <div class="clear"></div>

                <div class="pro_promot_select_title pro_promot_mt20 fl">选择游戏：</div>


            <div class="pro_promot_game fl">

                <ul id="game_list" class="z_clearfix game_list">

                </ul>
            </div>
            <div class="clear"></div>
            <div class="pro_promot_btn">
                <div class="fr pro_promot_btn_confirm">确定</div>
                <div class="fl pro_promot_btn_cancel">取消</div>
            </div>
        </div>
    </div>
    </form>
</div> -->



<!-- 新的不可修改渠道 -->
<div class="pro_promot" style="display:none">
    <form action="<?php echo url('Promote/savePromoteGame'); ?>" id="ajaxForm" method="post" />
    <input type="hidden" name="promote_id" id="se_promote_id" value="" />
    <div class="promoteModal">
        <div class="promoteModal-header">
            <div class="modalheader-ttile fl">
                <div class="fl headerTitleName">不可推广游戏</div>
                （选中的游戏将不在推广后台展示，渠道不可进行游戏申请并推广，二三级渠道推广权限同一级）
            </div>
            <div class="fr btnCloseModal"><img src="/themes/admin_simpleboot3/public/assets/images/btn_close_pop.png" alt=""></div>
        </div>
        <div class="promoteModal-body">
            <div style="padding-left:27px">
                <span class="mainTextSame">渠道账号：</span>
                <span class="gameNameShowText"></span>
            </div>
            <div class="promoteChooseAllInfo">
                <div>
                    <span class="mainTextSame fl">不可申请游戏：</span>
                    <div class="fl" style="margin-left: 2px;">
                        <a href="javaScript:;" class="firstChooseNum defferentTextColor firstNumCurrent js-show-all">全部</a>
                        <a href="javaScript:;" class="firstChooseNum js-screen" key="ABCD">ABCD </a>
                        <a href="javaScript:;" class="firstChooseNum js-screen" key="EFGH">EFGH</a>
                        <a href="javaScript:;" class="firstChooseNum js-screen" key="IJKL">IJKL</a>
                        <a href="javaScript:;" class="firstChooseNum js-screen" key="MNOP">MNOP</a>
                        <a href="javaScript:;" class="firstChooseNum js-screen" key="QRST">QRST</a>
                        <a href="javaScript:;" class="firstChooseNum js-screen" key="UVWX">UVWX</a>
                        <a href="javaScript:;" class="firstChooseNum js-screen" key="YZ">YZ</a>
                    </div>
                </div>
                <div>
                    <input type="text" class="inputSearchContent" placeholder="输入游戏名称">
                    <button class="searchButtonPromote">搜索</button>
                </div>
            </div>
            <div class="promoteGameSelect">

            </div>
        </div>
        <div class="promoteModal-footer">
            <div class="fl footerAllCheckBtn">
                <label class="" for="">
                    <input type="checkbox" class="checkBoxIcon" id="jsgamecheckall">
                    <i class="checkBoxIcon"></i>
                    <span class="mainTextSame" >全选</span>
                </label>
            </div>
            <div class="fl">
                <button class="cancelModalBtn">取消</button>
                <button class="confirmModalBtn">确定</button>
            </div>
        </div>
    </div>
    </form>
</div>
<script src="/static/js/admin.js"></script>
<script src="/static/js/layer/layer.js"></script>
<script type="text/javascript">
    //点击取消按钮，弹窗关闭
    $('.cancelModalBtn').click(function(){
        $('.pro_promot').css('display','none');
        return false;
    });
    $('.btnCloseModal').click(function() {
        $('.pro_promot').css('display','none');
        return false;
    });



    promote_id = $("#promote_id").attr('promote_id');
    account = $("#account").attr('account');
    parent_id = $("#parent_id").attr('parent_id');
    busier_id = $("#busier_id").attr('busier_id');
    register_type = $("#register_type").attr('register_type');
    $("#promote_id").selectpicker('val', promote_id);
    $("#account").selectpicker('val', account);
    $("#busier_id").selectpicker('val', busier_id);
    $("#parent_id").selectpicker('val', parent_id);
    $("#register_type").selectpicker('val', register_type);
    $("#level").selectpicker('val', $('#level').attr('level'));
    $("#status").selectpicker('val', $('#status').attr('status'));
    //打开弹窗

    $(function () {
        $(".ajax-view").click(function(){
            //获取游戏列表
            var url = "<?php echo url('Promote/getPromoteGame'); ?>";
            var id = $(this).attr('data-id');
            $.post(url,{id:id},function(res){
                if(res.code==1){
                    var game_list = res.data.game_list;
                    var promote_info = res.data.promote_info;
                    $('.gameNameShowText').html(promote_info.account);
                    var lis = [];
                    var pids = '';
                    if(promote_info['game_ids']){
                        pids = ','+promote_info['game_ids'].toString()+','; //字符分割
                    }
                    $.each(game_list,function(index,ele){
                        if(ele.game_name.length>7){
                            ele.game_name = ele.game_name .substring(0,7)+"..."
                        }
                        lis.push('<li class="fl pro_promot_game_con short-'+ele.short_f+'" id="'+ele.game_name+'">');

                        if(promote_info['game_ids']==''){
                            lis.push('<label class="promoteSelectLabel" >' +
                                '<input type="checkbox" value="'+ele.id+'" name="game_ids[]" class="checkBoxIcon jsgameid">' +
                                '<i class="checkBoxIcon"></i>' +
                                '<span class="mainTextSame limitTextStyle">'+ele.game_name+'</span>' +
                                '<i class="overTextStyle">'+ele.game_name+'</i>' +
                                '</label>');
                        }else{

                            if(pids.indexOf(','+ele.id+',')>-1){
                                lis.push('<label class="promoteSelectLabel">' +
                                    '<input type="checkbox" value="'+ele.id+'" name="game_ids[]" checked="checked" class="checkBoxIcon jsgameid">' +
                                    '<i class="checkBoxIcon"></i>' +
                                    '<span class="mainTextSame limitTextStyle">'+ele.game_name+'</span>' +
                                    '<i class="overTextStyle">'+ele.game_name+'</i>' +
                                    '</label>');
                            }else{
                                lis.push('<label class="promoteSelectLabel">' +
                                    '<input type="checkbox" value="'+ele.id+'" name="game_ids[]" class="checkBoxIcon jsgameid">' +
                                    '<i class="checkBoxIcon"></i>' +
                                    '<span class="mainTextSame limitTextStyle">'+ele.game_name+'</span>' +
                                    '<i class="overTextStyle">'+ele.game_name+'</i>' +
                                    '</label>');
                            }
                        }
                    });
                    $(".promoteGameSelect").html(lis.join(''));
                    $("#se_promote_id").val(res.data.promote_info.id);
                    $(".pro_promot").css("display","block");
                    jsgameid();
                }else{
                    alert('请求失败');
                }
            });
        });

        //保存修改
        $(".pro_promot_btn_confirm").click(function(){
            $("#ajaxForm").ajaxSubmit(function(res){
                layer.msg(res.msg);
                setTimeout(function () {
                    top.location.reload();
                },1000);
                $(".pro_promot").hide();
            });
            return false;
        });

        //关闭弹窗
        $(".pro_promot_close").click(function(){
            $(".pro_promot").css("display","none");
        });
        //取消修改
        $(".pro_promot_btn_cancel").click(function(){
            $(".pro_promot").css("display","none");
            //layer.msg('修改已取消');
        });


        //保存修改
        $(".confirmModalBtn").click(function(){
            $("#ajaxForm").ajaxSubmit(function(res){
                layer.msg(res.msg);
                location.reload();
                $(".pro_promot").hide();
            });
            return false;
        });

        $("#jsgamecheckall").click(function(){
           $('.promoteGameSelect').find(".jsgameid:visible").prop("checked",this.checked);
        });

        //全部显示
        $(".js-show-all").click(function () {
            $(this).addClass('firstNumCurrent').siblings().removeClass('firstNumCurrent')
            $(".pro_promot_game_con").show();
            return false;
        });
        //筛选条件
        $(".js-screen").click(function () {
           $(this).addClass('firstNumCurrent').siblings().removeClass('firstNumCurrent')
            var keys = $(this).attr("key");
            var keyArr = keys.split("");

            $(".pro_promot_game_con").hide();
            keyArr.forEach(function (ele) {
                $(".short-" + ele + "").show();
            });
            return false;
        });

        //搜索
        $('.searchButtonPromote').click(function () {
            var content = $(".inputSearchContent").val();
            if (content == '') {
                $(".pro_promot_game_con").show();
                return false;
            }
            $(".pro_promot_game_con").hide();
            $("li[id*=" + content + "]").show();
            return false;
        });

    })

    //可申请游戏 全选及全选反选 功能  @author  zwm  date 20180604
    function jsgameid(){
        $(".jsgameid").click(function(){
            var option = $(this).closest('ul').find(".jsgameid"),
                checkall = $(this).closest('ul').siblings('.jsgamecheckallbox').find('.jsgamecheckall');
            option.each(function(i){
                if(!this.checked){
                    checkall.prop("checked", false);
                    return false;
                }else{
                    checkall.prop("checked", true);
                }
            });
        });
    }

    // 渠道自动结算周期编辑
    $(function(){
        //设置分成比例
        $(".editTab").click(function(){
            var that = $(this);
            var title = that.attr("data-title");
            var promote_id = that.attr("promote-id");
            var promote_account = that.attr("promote-account");
            var num = that.text();
            // console.log(num);
            // console.log(promote_id);
            // console.log(promote_account);
            layer.prompt({
                formType:0,
                title:title,
                value:num,
                placeholder:'请输入自动结算周期(整数)'
            }, function(value) {
                if (!/^(((\d|[1-9]\d)(\.\d{1,2})?)|100|100.0|100.00)$/.test(value)) {
                    layer.msg('输入错误，请输入数字',{time:2000});
                    return false;
                }
                $.ajax({
                    async: false,
                    url:"<?php echo url('Promote/alterPromoteSettlement'); ?>",
                    type:"POST",
                    dataType:'JSON',
                    data:{promote_id:promote_id,day_period:value,promote_account:promote_account},
                    success:function(result){
                        if(result.code > 0){
                            // layer.msg(result.msg,{time:1000});
                            layer.msg(result.msg,{time:1000},function(){
                                !result.code || location.reload();
                            });
                        }else{
                            layer.msg(result.msg,{time:1000});
                        }

                    },
                    error:function(){
                        layer.msg('服务器异常',{time:2000});
                    }
                })
            });
        })

        $(".editCashTab").click(function(){
            var that = $(this);
            var title = that.attr("data-title");
            var promote_id = that.attr("promote-id");
            var field = that.attr("field");
            var num = that.text();
            layer.prompt({
                formType:0,
                title:title,
                value:num,
                placeholder:'输入渠道已交押金（最多2位小数）',
                success: function (layero) {
                   layero.find('.layui-layer-input').on('keyup', function () {
                       var obj = this
                       obj.value = obj.value.replace(/[^\d.]/g,"");  //清除“数字”和“.”以外的字符
                       obj.value = obj.value.replace(/\.{2,}/g,"."); //只保留第一个. 清除多余的
                       obj.value = obj.value.replace(".","$#$").replace(/\./g,"").replace("$#$",".");
                       obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3');//只能输入两个小数
                       if(obj.value.indexOf(".")< 0 && obj.value !=""){
                           obj.value= parseFloat(obj.value);
                       }
                   })
                }
            }, function(value) {
                $.ajax({
                    async: false,
                    url:"<?php echo url('Promote/savePromoteField'); ?>",
                    type:"POST",
                    dataType:'JSON',
                    data:{promote_id:promote_id,value:value,field:field},
                    success:function(result){
                        if(result.code > 0){
                            layer.msg(result.msg,{time:1000},function(){
                                !result.code || location.reload();
                            });
                        }else{
                            layer.msg(result.msg,{time:1000});
                        }

                    },
                    error:function(){
                        layer.msg('服务器异常',{time:2000});
                    }
                })
            });
        })
    })
</script>
</body>
</html>
