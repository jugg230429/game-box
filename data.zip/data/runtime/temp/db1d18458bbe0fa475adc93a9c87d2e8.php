<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:114:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/site/site/ptb_cash_out_set.html";i:1632734362;s:101:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/public/header.html";i:1632734362;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
            position: absolute;
            left: 5px;
            top: 37%;
        }
        .mailer-test .form-required {
            top: 15%;
        }
        .mailer-test .form-horizontal .control-label {
            width: 30%;
        }

        .btn.disabled, .btn[disabled], fieldset[disabled] .btn {
            background-color: #999;
            border-color: #999;
        }

        .btn.disabled:hover, .btn[disabled]:hover, fieldset[disabled] .btn:hover {
            background-color: #999;
            border-color: #999;
        }


        /*新加*/
        .dropdown-menu > .active > a, .dropdown-menu > .active > a:hover, .dropdown-menu > .active > a:focus {
            background-color: #1E91FF;
        }

        .dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus {
            background-color: #1E91FF;
        }

        tbody > .data_summary {
            background-color: #e6e6e6;
        }

    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
        var saveAsImage = 'http://<?php echo $_SERVER["HTTP_HOST"]; ?>/themes/admin_simpleboot3/public/assets/images/data_btn_download_n.png';
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <link rel="stylesheet" href="/themes/admin_simpleboot3/public/assets/css/bootstrap-select.css">
    <script src="/static/js/layer/layer.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap-select.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/defaults-zh_CN.js"></script>
    <link rel="stylesheet" type="text/css" media="all" href="/static/js/datejs/daterangepicker.css"/>
    <script type="text/javascript" src="/static/js/datejs/moment.min.js"></script>
    <script type="text/javascript" src="/static/js/datejs/daterangepicker.js"></script>
    <script>
        btn_tijiao_load_img_id = 0;
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container: 'body',
                html: true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
            $('.pagination .jspagerow').change(function () {
                value = $('.pagination .jspagerow option:selected').attr('vv');
                $('#page').remove();
                $('#search_form').append('<input type="hidden" id="page" name="row" value="' + value + '">');
                $('#search_btn').click();
            });

            $("body").bind("keydown", function (event) {
                if (event.keyCode == 116) {
                    event.preventDefault(); //阻止默认刷新
                    //location.reload();
                    //采用location.reload()在火狐下可能会有问题，火狐会保留上一次链接
                    location = location;
                }
            })
        });

        var unSelected = "#acb6c0";
        var selected = "#2C3E50";
        $(function () {
            $("select").css("color", unSelected);
            $("option").css("color", selected);
            $("select").change(function () {
                var selItem = $(this).val();
                if (selItem == $(this).find('option:first').val()) {
                    $(this).css("color", unSelected);
                } else {
                    $(this).css("color", selected);
                }
            });
        })

    </script>
    <script>
        // 更改button状态
        function change_submit_btn(consa, registe_btn) {
            j = 0;
            consa.find('input,select').each(function (i, n) {
                that = $(this);
                that.hasClass('jsmust')&&!that.val()?registe_btn.prop('disabled',true):j++;
            });
            if(j==consa.find('input,select').length){
                registe_btn.prop('disabled',false);
            }
        }
    </script>
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
        #think_page_trace_open {
        z-index: 9999;
    }
    </style>
    <?php endif; ?>

</head>
<body>
<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li class="active"><a href="#A" data-toggle="tab">提现设置</a></li>
        <span class="title_remark">说明：针对玩家提现操作进行设置</span>
    </ul>
    <form class="form-horizontal js-ajax-form margin-top-20" role="form" action="<?php echo url('sitePost'); ?>"
          method="post">
        <fieldset>
            <div class="tabbable">
                <div class="tab-content">
                    <div class="tab-pane active" id="A">
                        <div class="form-group">
                            <label for="input-site_adminstyle" class="col-sm-2 control-label">最低手续费：</label>
                            <div class="col-md-3 col-sm-5 pr">
                                <input type="text" class="form-control"  name="limit_money"
                                       value="<?php echo $data['limit_money']; ?>"><span class="input-sup">元</span>
                            </div>
                            <p class="help-block">如1，则手续费不足1元时按照1元收取</p>
                        </div>
                        <div class="form-group">
                            <label for="input-site-name" class="col-sm-2 control-label">提现手续费：</label>
                            <div class="col-md-3 col-sm-5 pr">
                                <input type="text" class="form-control" value="<?php echo $data['payment_fee']; ?>" name="payment_fee"><span class="input-sup">%</span>
                            </div>
                            <p class="help-block">用户进行提现需要扣除的手续费，如：10%，用户提现￥100.00，平台将收取￥10.00的手续费</p>
                        </div>

                        <div class="form-group">
                            <label for="input-site-name" class="col-sm-2 control-label">单笔最高提现金额：</label>
                            <div class="col-md-3 col-sm-5 pr">
                                <input type="text" class="form-control" onkeyup="value=value.replace(/^(0+)|[^\d]+/g,'')" value="<?php echo $data['limit_cash']; ?>" name="limit_cash" placeholder="如500"><span class="input-sup">元</span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="input-site-name" class="col-sm-2 control-label">单日最高提现次数：</label>
                            <div class="col-md-3 col-sm-5 pr">
                                <input type="text" class="form-control" onkeyup="value=value.replace(/^(0+)|[^\d]+/g,'')" value="<?php echo $data['limit_count']; ?>" name="limit_count" placeholder="如3"><span class="input-sup">次</span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="input-site_adminstyle" class="col-sm-2 control-label">自动打款：</label>
                            <div class="col-md-3 col-sm-5">
                                <label  class="label-width">
                                    <input type="radio" class="inp_radio" value="0" name="pay_type" <?php if(empty($data['pay_type']) || (($data['pay_type'] instanceof \think\Collection || $data['pay_type'] instanceof \think\Paginator ) && $data['pay_type']->isEmpty())): ?>checked="checked"<?php endif; ?>> 关闭
                                </label>
                                <label  class="label-width">
                                    <input type="radio" class="inp_radio" value="1" name="pay_type" <?php if($data['pay_type'] == '1'): ?>checked="checked"<?php endif; ?>> 开启
                                </label>
                            </div>
                            <p class="help-block">自动打款开启时玩家正确提交平台币提现后即可打款到账，默认选中关闭</p>
                        </div>

                        <div class="form-group">
                            <label for="input-site_adminstyle" class="col-sm-2 control-label">支付宝提现：</label>
                            <div class="col-md-3 col-sm-5">
                                <label  class="label-width">
                                    <input type="radio" class="inp_radio" value="0" name="alipay_show" <?php if($data['alipay_show'] === '0'): ?>checked="checked"<?php endif; ?>>关闭
                                </label>
                                <label  class="label-width">
                                    <input type="radio" class="inp_radio" value="1" name="alipay_show" <?php if($data['alipay_show'] != '0'): ?>checked="checked"<?php endif; ?>> 开启
                                </label>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="input-site_adminstyle" class="col-sm-2 control-label">微信提现：</label>
                            <div class="col-md-3 col-sm-5">
                                <label  class="label-width">
                                    <input type="radio" class="inp_radio" value="0" name="weixin_show" <?php if($data['weixin_show'] === '0'): ?>checked="checked"<?php endif; ?>> 关闭
                                </label>
                                <label  class="label-width">
                                    <input type="radio" class="inp_radio" value="1" name="weixin_show" <?php if($data['weixin_show'] != '0'): ?>checked="checked"<?php endif; ?>> 开启
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-1 col-sm-5">
                                <input type="hidden" name="set_type" value="<?php echo $name; ?>">
                                <button type="submit" class="btn btn-primary js-ajax-submit save-btn ml9" data-refresh="1">
                                    <?php echo lang('SAVE'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </fieldset>
    </form>

</div>
<script type="text/javascript" src="/static/js/admin.js"></script>
</body>
</html>
