<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:117:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/promote/datamanage/coinrecord.html";i:1632734360;s:101:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/public/header.html";i:1632734362;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
            position: absolute;
            left: 5px;
            top: 37%;
        }
        .mailer-test .form-required {
            top: 15%;
        }
        .mailer-test .form-horizontal .control-label {
            width: 30%;
        }

        .btn.disabled, .btn[disabled], fieldset[disabled] .btn {
            background-color: #999;
            border-color: #999;
        }

        .btn.disabled:hover, .btn[disabled]:hover, fieldset[disabled] .btn:hover {
            background-color: #999;
            border-color: #999;
        }


        /*新加*/
        .dropdown-menu > .active > a, .dropdown-menu > .active > a:hover, .dropdown-menu > .active > a:focus {
            background-color: #1E91FF;
        }

        .dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus {
            background-color: #1E91FF;
        }

        tbody > .data_summary {
            background-color: #e6e6e6;
        }

    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
        var saveAsImage = 'http://<?php echo $_SERVER["HTTP_HOST"]; ?>/themes/admin_simpleboot3/public/assets/images/data_btn_download_n.png';
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <link rel="stylesheet" href="/themes/admin_simpleboot3/public/assets/css/bootstrap-select.css">
    <script src="/static/js/layer/layer.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap-select.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/defaults-zh_CN.js"></script>
    <link rel="stylesheet" type="text/css" media="all" href="/static/js/datejs/daterangepicker.css"/>
    <script type="text/javascript" src="/static/js/datejs/moment.min.js"></script>
    <script type="text/javascript" src="/static/js/datejs/daterangepicker.js"></script>
    <script>
        btn_tijiao_load_img_id = 0;
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container: 'body',
                html: true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
            $('.pagination .jspagerow').change(function () {
                value = $('.pagination .jspagerow option:selected').attr('vv');
                $('#page').remove();
                $('#search_form').append('<input type="hidden" id="page" name="row" value="' + value + '">');
                $('#search_btn').click();
            });

            $("body").bind("keydown", function (event) {
                if (event.keyCode == 116) {
                    event.preventDefault(); //阻止默认刷新
                    //location.reload();
                    //采用location.reload()在火狐下可能会有问题，火狐会保留上一次链接
                    location = location;
                }
            })
        });

        var unSelected = "#acb6c0";
        var selected = "#2C3E50";
        $(function () {
            $("select").css("color", unSelected);
            $("option").css("color", selected);
            $("select").change(function () {
                var selItem = $(this).val();
                if (selItem == $(this).find('option:first').val()) {
                    $(this).css("color", unSelected);
                } else {
                    $(this).css("color", selected);
                }
            });
        })

    </script>
    <script>
        // 更改button状态
        function change_submit_btn(consa, registe_btn) {
            j = 0;
            consa.find('input,select').each(function (i, n) {
                that = $(this);
                that.hasClass('jsmust')&&!that.val()?registe_btn.prop('disabled',true):j++;
            });
            if(j==consa.find('input,select').length){
                registe_btn.prop('disabled',false);
            }
        }
    </script>
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
        #think_page_trace_open {
        z-index: 9999;
    }
    </style>
    <?php endif; ?>

</head>
<body>
    <div class="wrap js-check-wrap">
        <ul class="nav nav-tabs">
            <li><a href="<?php echo url('@recharge/ptbspend/lists'); ?>">玩家充值</a></li>
            <?php if(AUTH_PROMOTE == 1): ?>
                <li class="active"><a href="<?php echo url('datamanage/coinrecord'); ?>">渠道充值</a></li>
            <?php endif; ?>
            <span class="title_remark">说明：统计推广渠道充值平台币到账户的记录，不包含消费平台币的记录。</span>
        </ul>
        <form id="search_form" class="well form-inline  fr" method="get" action="<?php echo url('datamanage/coinrecord'); ?>" onsubmit="return check();">
            <input type="text" class="form-control" name="pay_order_number" style="width: 140px;" value="<?php echo input('request.pay_order_number/s',''); ?>" placeholder="支付订单号">
            <select name="promote_id" id="promote_id"  class="selectpicker" data-live-search="true" data-size="8" promote_id="<?php echo input('request.promote_id',''); ?>">
                <option value="">充值账号</option>
                <?php $_result=get_promote_list();if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <option promote-id="<?php echo $vo['id']; ?>" value="<?php echo $vo['id']; ?>"><?php echo $vo['account']; ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
            <select name="to_id" id="to_id"  class="selectpicker" data-live-search="true" data-size="8" to_id="<?php echo input('request.to_id',''); ?>">
                <option value="">收款账号</option>
                <?php $_result=get_promote_list();if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <option promote-id="<?php echo $vo['id']; ?>" value="<?php echo $vo['id']; ?>"><?php echo $vo['account']; ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
            <input type="text" class="form-control js-bootstrap-date" id="start_time" name="start_time" placeholder="充值开始时间"
                   value="<?php echo input('request.start_time/s',''); ?>" style="width: 140px;" autocomplete="off">-
            <input type="text" class="form-control js-bootstrap-date" id="end_time" name="end_time" placeholder="充值结束时间"
                   value="<?php echo input('request.end_time/s',''); ?>" style="width: 140px;" autocomplete="off"> &nbsp; &nbsp;
            <select name="pay_way" id="pay_way" class="selectpicker" pay_way="<?php echo input('request.pay_way'); ?>">
                <option value="">充值方式</option>
                <option value="3" <?php if(input('request.pay_way') == 3): ?>selected<?php endif; ?>>支付宝</option>
                <option value="4" <?php if(input('request.pay_way') == 4): ?>selected<?php endif; ?>>微信</option>
            </select>
            <select name="pay_status" id="pay_status" class="selectpicker" pay_status="<?php echo input('request.pay_status'); ?>" style="width: 120px;">
                <option value="">订单状态</option>
                <option value="1" <?php if(input('request.pay_status') == 1): ?>selected<?php endif; ?>>充值成功</option>
                <option value="0" <?php if(input('request.pay_status') === '0'): ?>selected<?php endif; ?>>下单未付款</option>
            </select>
            <input type="submit" class="btn btn-primary" id="search_btn" value="搜索" />
            <a class="btn btn-clear" href="<?php echo url('datamanage/coinrecord'); ?>">清空</a>
        </form>
        <table class="table table-hover table-bordered">
            <thead >
                <tr>
                    <th>订单号</th>
                    <th>充值账号</th>
                    <th>充值数量</th>
                    <th>充值方式</th>
                    <th>充值IP</th>
                    <th>充值时间</th>
                    <th>订单状态</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($data_lists) || (($data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator ) && $data_lists->isEmpty())): ?>
                    <tr><td colspan="7" style="text-align: center;">暂无数据</td></tr>
                <?php else: if(is_array($data_lists) || $data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator): if( count($data_lists)==0 ) : echo "" ;else: foreach($data_lists as $key=>$vo): ?>
                    <tr>
                        <?php if($vo['pay_status'] == 1) $page_total +=$vo['pay_amount']; ?>
                        <td><?php echo $vo['pay_order_number']; ?></td>
                        <td><?php echo get_promote_name($vo['to_id']); ?></td>
                        <td><?php echo null_to_0($vo['pay_amount']); ?></td>
                        <td><?php echo get_pay_way($vo['pay_way']); ?></td>
                        <td><?php echo $vo['spend_ip']; ?></td>
                        <td><?php echo date('Y-m-d H:i:s',$vo['create_time']); ?></td>
                        <td>
                            <span <?php if($vo['pay_status'] == 1): ?> class="label" style="color:#3FAD46;font-size:14px"<?php else: ?>class="label" style="color:#d9534f;font-size:14px"<?php endif; ?>><?php echo get_info_status($vo['pay_status'],2); ?></span>
                        </td>
                    </tr>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                     <tr class="data_summary">
                        <td><span style="margin-right: 10px;">汇总</span></td>
                        <td colspan="6"><span>今日充值：<?php echo null_to_0($today); ?>元 ；昨日充值：<?php echo null_to_0($yestoday); ?>元 ； 当页充值：<?php echo null_to_0($page_total); ?>元 ； 累计充值：<?php echo null_to_0($total); ?>元</span></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php echo $page; ?>
        </div>
    </div>
    <script src="/static/js/admin.js"></script>
    <script src="/static/js/layer/layer.js"></script>
    <script type="text/javascript">
        promote_id = $("#promote_id").attr('promote_id');
        to_id = $("#to_id").attr('to_id');
        $("#promote_id").selectpicker('val', promote_id);
        $("#to_id").selectpicker('val', to_id);
        $("#pay_way").selectpicker('val', $('#pay_way').attr('pay_way'));
        $("#pay_status").selectpicker('val', $('#pay_status').attr('pay_status'));
        function check(){
            var start_time = $("#start_time").val();
            var end_time = $("#end_time").val();
            if(start_time != '' && end_time != '' && start_time > end_time){
                layer.msg('开始时间不能大于结束时间');
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
