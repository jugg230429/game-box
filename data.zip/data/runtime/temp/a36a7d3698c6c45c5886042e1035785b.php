<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:108:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/member/user/userinfo.html";i:1722479698;s:101:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/public/header.html";i:1632734362;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
            position: absolute;
            left: 5px;
            top: 37%;
        }
        .mailer-test .form-required {
            top: 15%;
        }
        .mailer-test .form-horizontal .control-label {
            width: 30%;
        }

        .btn.disabled, .btn[disabled], fieldset[disabled] .btn {
            background-color: #999;
            border-color: #999;
        }

        .btn.disabled:hover, .btn[disabled]:hover, fieldset[disabled] .btn:hover {
            background-color: #999;
            border-color: #999;
        }


        /*新加*/
        .dropdown-menu > .active > a, .dropdown-menu > .active > a:hover, .dropdown-menu > .active > a:focus {
            background-color: #1E91FF;
        }

        .dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus {
            background-color: #1E91FF;
        }

        tbody > .data_summary {
            background-color: #e6e6e6;
        }

    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
        var saveAsImage = 'http://<?php echo $_SERVER["HTTP_HOST"]; ?>/themes/admin_simpleboot3/public/assets/images/data_btn_download_n.png';
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <link rel="stylesheet" href="/themes/admin_simpleboot3/public/assets/css/bootstrap-select.css">
    <script src="/static/js/layer/layer.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap-select.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/defaults-zh_CN.js"></script>
    <link rel="stylesheet" type="text/css" media="all" href="/static/js/datejs/daterangepicker.css"/>
    <script type="text/javascript" src="/static/js/datejs/moment.min.js"></script>
    <script type="text/javascript" src="/static/js/datejs/daterangepicker.js"></script>
    <script>
        btn_tijiao_load_img_id = 0;
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container: 'body',
                html: true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
            $('.pagination .jspagerow').change(function () {
                value = $('.pagination .jspagerow option:selected').attr('vv');
                $('#page').remove();
                $('#search_form').append('<input type="hidden" id="page" name="row" value="' + value + '">');
                $('#search_btn').click();
            });

            $("body").bind("keydown", function (event) {
                if (event.keyCode == 116) {
                    event.preventDefault(); //阻止默认刷新
                    //location.reload();
                    //采用location.reload()在火狐下可能会有问题，火狐会保留上一次链接
                    location = location;
                }
            })
        });

        var unSelected = "#acb6c0";
        var selected = "#2C3E50";
        $(function () {
            $("select").css("color", unSelected);
            $("option").css("color", selected);
            $("select").change(function () {
                var selItem = $(this).val();
                if (selItem == $(this).find('option:first').val()) {
                    $(this).css("color", unSelected);
                } else {
                    $(this).css("color", selected);
                }
            });
        })

    </script>
    <script>
        // 更改button状态
        function change_submit_btn(consa, registe_btn) {
            j = 0;
            consa.find('input,select').each(function (i, n) {
                that = $(this);
                that.hasClass('jsmust')&&!that.val()?registe_btn.prop('disabled',true):j++;
            });
            if(j==consa.find('input,select').length){
                registe_btn.prop('disabled',false);
            }
        }
    </script>
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
        #think_page_trace_open {
        z-index: 9999;
    }
    </style>
    <?php endif; ?>

</head>
<body>
<style>
    .bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
        width: 120px;
    }
    .layui-equipment-num .layui-layer-content{
        padding: 20px;
    }
    #search_form{
        width:86% !important;
    }
    .layui-layer-iframe{
        border-radius: 4px;
        overflow: hidden;
    }
    .circle_class{
        border-radius: 20%;
        border:1px dotted gainsboro;
    }
    .circle_class2{
        border-radius: 25px;
        border:1px dotted gainsboro;
        text-align: center;
        background:floralwhite;
    }
    .table-actions,.scroll-table-wrapper{
        margin-left: -10px;
    }
</style>
    <div class="wrap js-check-wrap">
        <ul class="nav nav-tabs">
            <li class="active"><a href="<?php echo url('user/userinfo'); ?>">用户列表</a></li>
            <li ><a href="<?php echo url('user/unsubscribe'); ?>">已注销</a></li>
            <span class="title_remark" style="color:rgb(231,76,60)">说明：用户注册的实时列表。补链节点前的用户充值等数据归属原渠道，补链节点后归属补链后的渠道。</span>
        </ul>
        <div class="table-actions position fl" >
            <button id="bulian" class="btn btn-danger  mtb17" type="button"
                    data-action="<?php echo url('Mend/add'); ?>" data-subcheck="true" data-msg="您确定删除吗？">
                补链
            </button>
            <button id="lock_user" class="btn btn-danger  mtb17" type="button"
                    data-action="<?php echo url('User/ban'); ?>" data-subcheck="true" data-msg="您确定要锁定这些用户吗？">
                锁定
            </button>
            <a id="piliang" class="btn btn-danger mtb17" href="<?php echo url('member/user/batchCreate'); ?>">批量创建</a>
        </div>
        <form id="search_form" class="well form-inline fr" method="get" action="<?php echo url('User/userinfo'); ?>" onsubmit="return check();" style="width: 96%;margin-right: 0px;">
            <input type="text" class="form-control notempty" name="user_id" style="width: 120px;" value="<?php echo input('request.user_id/d',''); ?>" placeholder="玩家ID">
            <input type="text" class="form-control notempty" name="account" style="width: 120px;" value="<?php echo input('request.account/s',''); ?>" placeholder="玩家账号">
            <input type="text" class="form-control notempty" name="account" style="width: 120px;" value="<?php echo input('request.account/s',''); ?>" placeholder="玩家账号">
            <input type="text" class="form-control notempty" name="small_nickname" style="width: 120px;" value="<?php echo input('request.small_nickname/s',''); ?>" placeholder="小号账号">
            <?php if(cmf_get_admin_access('member/user/search') == true): ?>
            <input type="text" class="form-control notempty" name="equipment_num" style="width: 120px;" value="<?php echo input('request.equipment_num/s',''); ?>" placeholder="设备号">
            <input type="text" class="form-control notempty" name="register_ip" style="width: 120px;" value="<?php echo input('request.register_ip/s',''); ?>" placeholder="注册IP">
            <?php endif; ?>
            <input type="text" class="form-control js-bootstrap-date" name="start_time" id="start_time" placeholder="注册开始时间"
                   value="<?php echo input('request.start_time/s',''); ?>" style="width: 120px;" autocomplete="off"><span style="position: relative;top: 10px;">-</span>
            <input type="text" class="form-control js-bootstrap-date" name="end_time" id="end_time" placeholder="注册结束时间"
                   value="<?php echo input('request.end_time/s',''); ?>" style="width: 120px;" autocomplete="off">
            <?php if(cmf_get_admin_access('member/user/search') == true): ?>
            <select name="register_type" id="register_type"  class="selectpicker" register_type="<?php echo input('request.register_type'); ?>" style="width: 120px;">
                <option value="">注册方式</option>
                <option value="1" <?php if(input('request.register_type') == 1): ?>selected<?php endif; ?>>账号</option>
                <option value="2" <?php if(input('request.register_type') == 2): ?>selected<?php endif; ?>>手机号</option>
                <option value="7" <?php if(input('request.register_type') == 7): ?>selected<?php endif; ?>>邮箱</option>
                <option value="0" <?php if(input('request.register_type') == '0'): ?>selected<?php endif; ?>>游客</option>
                <option value="4" <?php if(input('request.register_type') == 4): ?>selected<?php endif; ?>>QQ</option>
                <option value="3" <?php if(input('request.register_type') == 3): ?>selected<?php endif; ?>>微信</option>
                <option value="catch_create" <?php if(input('request.register_type') == 'catch_create'): ?>selected<?php endif; ?>>系统创建</option>
            </select>
            <?php endif; ?>
            <select name="age_status" id="age_status"  class="selectpicker" register_type="<?php echo input('request.age_status'); ?>" style="width: 120px;">
                <option value="">实名认证</option>
                <option value="0" <?php if(input('request.age_status') == '0'): ?>selected<?php endif; ?>>未认证</option>
                <option value="2" <?php if(input('request.age_status') == 2): ?>selected<?php endif; ?>>已成年</option>
                <option value="3" <?php if(input('request.age_status') == 3): ?>selected<?php endif; ?>>未成年</option>
                <option value="4" <?php if(input('request.age_status') == 4): ?>selected<?php endif; ?>>审核中</option>
            </select>
            <select name="user_status" id="user_status"  class="selectpicker" user_status="<?php echo input('request.user_status'); ?>" style="width: 120px;">
                <option value="">账号状态</option>
                <option value="1" <?php if(input('request.user_status') == 1): ?>selected<?php endif; ?>>正常</option>
                <option value="0" <?php if(input('request.user_status') === '0'): ?>selected<?php endif; ?>>已锁定</option>
                <option value="2" <?php if(input('request.user_status') == '2'): ?>selected<?php endif; ?>>待注销</option>
            </select>
            <?php if(AUTH_PROMOTE == 1): ?>
                <select name="promote_id" id="promote_id"  class="selectpicker" data-live-search="true"  data-size="8" style="width: 120px;">
                    <option value="">所属渠道</option>
                    <option value="0" <?php if(input('request.promote_id') == '0'): ?>selected<?php endif; ?>>官方渠道</option>
                    <?php $_result=get_promote_list();if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <option promote-id="<?php echo $vo['id']; ?>" value="<?php echo $vo['id']; ?>" <?php if(input('request.promote_id') == $vo['id']): ?>selected<?php endif; ?>><?php echo $vo['account']; ?></option>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
            <?php endif; ?>
            <select name="fgame_id" id="fgame_id" class="selectpicker " game_id="<?php echo input('request.fgame_id'); ?>" data-live-search="true" data-size="8">
                <option value="">注册游戏</option>
                <?php $_result=get_game_list('id,game_name',$map);if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <option value="<?php echo $vo['id']; ?>"  <?php if(input('request.fgame_id') == $vo['id']): ?>selected<?php endif; ?>><?php echo $vo['game_name']; ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
            <?php $vip = explode(',',cmf_get_option('vip_set')['vip']); ?>
            <!--<input type="text" class="form-control notempty" name="equipment_num" style="width: 120px;" placeholder="OAID">-->
            <select id="viplevel" name="viplevel" class="selectpicker" style="width: 120px;">
                <option value="">VIP等级</option>
                <option value="0" <?php if(input('request.viplevel') == '0'): ?>selected<?php endif; ?>>VIP 0</option>
                <?php if(is_array($vip) || $vip instanceof \think\Collection || $vip instanceof \think\Paginator): $$key = 0; $__LIST__ = $vip;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($$key % 2 );++$$key;?>
                    <option value="<?php echo $key+1; ?>" <?php if(input('request.viplevel') == ($key+1)): ?>selected<?php endif; ?>>VIP <?php echo $key+1; ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
            <select id="cumulative" name="cumulative" class="selectpicker"  style="width: 120px;">
                <option value="">充值金额</option>
                <option value="1" <?php if(input('request.cumulative') == '1'): ?>selected<?php endif; ?>>0-100元</option>
                <option value="2" <?php if(input('request.cumulative') == '2'): ?>selected<?php endif; ?>>101-1000元</option>
                <option value="3" <?php if(input('request.cumulative') == '3'): ?>selected<?php endif; ?>>1001-10000元</option>
                <option value="4" <?php if(input('request.cumulative') == '4'): ?>selected<?php endif; ?>>10001-50000元</option>
                <option value="5" <?php if(input('request.cumulative') == '5'): ?>selected<?php endif; ?>>50001-100000元</option>
                <option value="6" <?php if(input('request.cumulative') == '6'): ?>selected<?php endif; ?>>100001及以上</option>
            </select>
            <input type="text" class="form-control js-bootstrap-date" name="login_start_time" id="login_start_time" placeholder="登录开始时间"
                   value="<?php echo input('request.login_start_time/s',''); ?>" style="width: 120px;" autocomplete="off"> <span style="position: relative;top: 10px;">-</span>
            <input type="text" class="form-control js-bootstrap-date" name="login_end_time" id="login_end_time" placeholder="登录结束时间"
                   value="<?php echo input('request.login_end_time/s',''); ?>" style="width: 120px;" autocomplete="off">
            <input type="hidden" name="sort" id="sort" value="<?php echo input('request.sort',1); ?>">
            <input type="hidden" name="sort_type" id="sort_type" value="<?php echo input('request.sort_type'); ?>">
            <input type="submit" class="btn btn-primary" id="search_btn" value="搜索" />
            <a class="btn btn-clear" href="<?php echo url('User/userinfo'); ?>">清空</a>
            <?php if(cmf_get_admin_access('member/export/expuser') == true): ?>
            <a class="btn btn-export js-export"  data-msg="确定导出吗？" href="<?php echo url('Export/expUser',array_merge(['id'=>1,'xlsname'=>'玩家列表'],input())); ?>">导出</a>
            <?php endif; ?>
        </form>
        <div class="scroll-table-wrapper">
        <table class="table table-hover table-bordered scroll-table" style="margin-left:0px;">
            <thead>
                <tr>
                    <th style="width: 32px;"><input type="checkbox" id="all-checkbox" class="table-item-checkbox js-check-all" data-direction="x" data-checklist="js-check-x"><label for="all-checkbox" class=""></label></th>
                    <!-- <th width="50">ID</th> -->
                    <th>账号信息</th>
                    <th>消费信息</th>
                    <th>VIP信息</th>
                    <th>实名信息</th>
                    <?php if(cmf_get_admin_access('member/user/search') == true): ?>
                        <th>注册信息</th>
                    <?php endif; ?>
                    <th>最后登录信息</th>
                    <th width="130"><?php echo lang('ACTIONS'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $user_statuses=array("0"=>'已锁定',"1"=>'正常'); if(empty($data_lists) || (($data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator ) && $data_lists->isEmpty())): ?>
                    <tr><td colspan="23" style="text-align: center;">暂无数据</td></tr>
                <?php else: if(is_array($data_lists) || $data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator): if( count($data_lists)==0 ) : echo "" ;else: foreach($data_lists as $key=>$vo): ?>
                    <tr>
                        <td><input type="checkbox" id="ids-checkbox<?php echo $vo['id']; ?>" class="table-item-checkbox js-check" data-yid="js-check-y" data-xid="js-check-x" name="ids[]"
                                   value="<?php echo $vo['id']; ?>" title="ID:<?php echo $vo['id']; ?>">
                            <label for="ids-checkbox<?php echo $vo['id']; ?>" class=""></label></td>
                        <!-- <td><?php echo $vo['id']; ?></td> -->
                        <td>
                            账号ID：<?php echo $vo['id']; ?> <br>
                            账号：<b><?php echo $vo['account']; ?> </b><br>
                            小号：
                            <a href="javascript:open_small_lists('<?php echo $vo[id]; ?>');" class="js_small_list" style="text-decoration: underline;"><?php echo $vo['small_count']; ?></a>
                            <br>
                            设备号：<?php if(!empty($vo['equipment_num'])): ?><?php echo $vo['equipment_num']; else: ?>--<?php endif; ?> <br>
                            所属渠道：
                            <?php if(AUTH_PROMOTE == 1): ?><?php echo get_promote_name($vo['promote_id']); else: ?>请购买渠道权限<?php endif; ?>
                            <br>
                            账号状态:
                            <?php if($vo['is_unsubscribe'] == 1): ?>
                                已注销
                            <?php elseif($vo['unsubscribe_status'] == 1): ?>
                                <span style="color: #d97416;font-size:14px">待注销</span>
                            <?php else: if($vo['lock_status'] == 1): ?>
                                    <span style="color: #3FAD46;font-size:14px"><?php echo $user_statuses[$vo['lock_status']]; ?></span>
                                <?php else: ?>
                                    <span style="color:#d9534f;font-size:14px"><?php echo $user_statuses[$vo['lock_status']]; ?></span>
                                <?php endif; endif; ?>
                            <br>
                        </td>
                        <td>
                            累计消费：<?php if(AUTH_PAY == 1): ?><?php echo $vo['cumulative']; else: ?>请购买充值权限<?php endif; ?>
                            <br>
                            付费记录：
                            <?php if(AUTH_PAY == 1): ?><a href="javascript:open_record('<?php echo $vo[id]; ?>');" style="text-decoration: underline;"><?php echo $vo['count']; ?></a><?php else: ?>请购买充值权限<?php endif; ?>
                            <br>
                            上次消费：<?php if(AUTH_PAY == 1): ?><?php echo (isset($vo['last_pay_time']) && ($vo['last_pay_time'] !== '')?$vo['last_pay_time']:'0'); else: ?>请购买充值权限<?php endif; ?>
                            <br>
                            平台币余额：<?php echo $vo['balance']; ?>
                            <br>
                            金币余额：<?php echo $vo['gold_coin']; ?>
                            <br>
                            绑币余额：
                            <a href="javascript:open_bangbi_lists('<?php echo $vo[id]; ?>');" class="js_small_list">查看></a>
                            <!-- vo.bind_balance -->

                        </td>
                        <td>
                            VIP等级：<?php echo $vo['vip_level']; ?>
                            <br>
                            尊享卡：<?php if($vo['member_days']): ?><?php echo $vo['member_days']; ?>天（剩余<?php echo $vo['valid_days']; ?>天）<?php else: ?>无<?php endif; ?>
                            <br>
                            剩余积分：<?php echo $vo['point']; ?>

                        </td>
                        <td>
                            <?php echo get_user_age_status($vo['age_status']); ?>
                        </td>
                        <?php if(cmf_get_admin_access('member/user/search') == true): ?>
                            <td>
                                注册方式：
                                <?php if($vo['is_batch_create']=='1'): ?>
                                    系统创建
                                <?php else: ?>
                                    <?php echo get_user_register_type($vo['register_type']); endif; ?>
                                <br>
                                注册时间：
                                <?php if($vo['register_time'] == ''): ?>
                                    --
                                <?php else: ?>
                                    <?php echo date('Y-m-d H:i:s',$vo['register_time']); endif; ?>
                                <br>
                                注册游戏：<?php echo (isset($vo['fgame_name']) && ($vo['fgame_name'] !== '')?$vo['fgame_name']:'--'); ?>
                                <br>
                                注册IP：<?php echo $vo['register_ip']; ?>
                                <br>
                                注册设备：<?php if(!empty($vo['device_name'])): ?><?php echo $vo['device_name']; else: ?>--<?php endif; ?>
                                <br>
                                设备码：<?php if(!empty($vo['equipment_num'])): ?><?php echo $vo['equipment_num']; else: ?>--<?php endif; ?>
                            </td>
                        <?php endif; ?>
                        <td>
                            最后登录时间：
                            <?php if($vo['login_time'] == ''): ?>
                                --
                            <?php else: ?>
                                <?php echo $vo['login_time']; endif; ?>
                            <br>
                            最后登录IP：<?php echo $vo['login_ip']; ?>
                            <br>
                            设备码：<?php if(!empty($vo['login_equipment_num'])): ?><?php echo $vo['login_equipment_num']; else: ?>--<?php endif; ?>
                        </td>

                        <td>
                            <!-- <a href="javascript:;" class="show_head_img" data-img="<?php echo $vo['head_img']; ?>">用户头像</a> -->
                            <a href="<?php echo url('user/user_data_analyze',array('id'=>$vo['id'])); ?>" >用户画像</a>

                            <!-- <a href='<?php echo url("user/edit",array("id"=>$vo["id"])); ?>'>查看</a> -->
                            <br>
                            <?php if($vo['lock_status'] == 1): ?>
                                <a href="<?php echo url('user/ban',array('id'=>$vo['id'])); ?>" class="js-ajax-dialog-btn" data-msg="<?php echo lang('您确定要锁定此用户吗？'); ?>">冻结</a>
                            <?php else: ?>
                                <a href="<?php echo url('user/cancelban',array('id'=>$vo['id'])); ?>" class="js-ajax-dialog-btn" data-msg="<?php echo lang('您确定要解锁此用户吗？'); ?>">解冻</a>
                            <?php endif; ?>
                            <br>
                            <?php if(AUTH_PROMOTE == 1): ?><a  href="<?php echo url('Mend/add',array('id'=>$vo['id'])); ?>">补链</a><?php else: ?>补链请购买渠道权限<?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; endif; else: echo "" ;endif; endif; ?>
            </tbody>
        </table>
        </div>
        <div class="pagination">
            <?php echo $page; ?>
<!--            <li class="page-item"><a class="page-link" href="<?php echo url('Export/expUser',array_merge(['id'=>1,'xlsname'=>'玩家_玩家列表'],input())); ?>">导出</a></li>-->
        </div>
    </div>

    <script src="/static/js/admin.js"></script>
    <script>
        $('#register_type').selectpicker('val', $('#register_type').attr('register_type'));
        $('#user_status').selectpicker('val', $('#user_status').attr('user_status'));
        $('#viplevel').selectpicker('val', $('#viplevel').attr('viplevel'));
        $(function () {
            //去空处理
            $('.notempty').bind('input onpropertychange',function(){
                $(this).val(($(this).val()).replace(/\s/g,""));
            });
            $("#lock_user").click(function () {
                var ids = '';
                $('input[name="ids[]"]:checked').each(function(){
                    //遍历每一个名字为interest的复选框，其中选中的执行函数
                    ids = ids +$(this).val()+",";//将选中的值添加到数组chk_value中
                });
                if(ids == ''){
                    layer.msg('请选择要操作的数据');
                    return false;
                }
                ids = ids.substring(0,ids.length-1);
                var url = $(this).attr('data-action');
                window.location.href = url+"?id="+ids;
            })
            $("#bulian").click(function () {
                var ids = '';
                $('input[name="ids[]"]:checked').each(function(){
                    //遍历每一个名字为interest的复选框，其中选中的执行函数
                    ids = ids +$(this).val()+",";//将选中的值添加到数组chk_value中
                });
                if(ids == ''){
                    layer.msg('请选择要操作的数据');
                    return false;
                }
                ids = ids.substring(0,ids.length-1);
                var url = $(this).attr('data-action');
                window.location.href = url+"?id="+ids;
            })
            // 查看用户头像
            $(".show_head_img").click(function(){
                var head_img_url = $(this).attr("data-img");
                if(head_img_url.length < 1){
                    layer.msg("该用户暂无头像!",{skin: 'circle_class2'});
                    // layer.alert('见到你真的很高兴', {icon: 6});
                    return false;
                }
                layer.open({
                    type: 1,
                    title: false,
                    closeBtn: 0,
                    shadeClose: true,
                    skin: 'circle_class',
                    content: '<div> <img style="width:220px;height:220px; border-radius:80%" src="'+head_img_url+'" alt=""> </div>'
                });
                // alert(head_img_url);
            });

            
            $(".js-export").click(function () {
                var param = '<?php echo json_encode(input("","")); ?>';
                param_obj = eval('(' + param + ')');
                if (param_obj.length == 0) {
                    layer.msg('请选择任一筛选条件后进行导出');
                    return false;
                }
                var msg = $(this).attr('data-msg');
                var href = $(this).attr('href');
                //询问框
                layer.confirm(msg, {
                    btn: ['确定', '取消'] //按钮
                }, function () {
                    location.href = href;
                    layer.closeAll();
                });
                return false;
            });

        })
        function open_record(user_id){
            layer.open({
                type: 2,
                title: '游戏付费记录',
                shadeClose: true,
                shade: 0.8,
                area: ['70%', '80%'],
                content: "<?php echo url('spendrecord'); ?>?user_id="+user_id //iframe的url
            });
        }
        function open_equipment_num(equipment_num) {
            var content = '<p>'+equipment_num+'</p>'
            layer.open({
                type: 1,
                skin: 'layui-equipment-num', //样式类名
                closeBtn: 1, //不显示关闭按钮
                title:'设备号',
                anim: 2,
                area: ['300px', '120px'],
                shadeClose: true, //开启遮罩关闭
                content: content
            });
        }
        function open_balance(user_id){
            layer.open({
                type: 2,
                title: '绑币余额',
                shadeClose: true,
                shade: 0.8,
                area: ['70%', '80%'],
                content: "<?php echo url('user_bind_balance'); ?>?user_id="+user_id //iframe的url
            });
        }

        /**
         * 小号列表
         * @param user_id
         */
        function open_small_lists(user_id) {
            layer.open({
                type: 2,
                title: '小号数据',
                shadeClose: true,
                shade: 0.8,
                area: ['70%', '80%'],
                content: "<?php echo url('user_small_lists'); ?>?user_id="+user_id //iframe的url
            });
        }
        function check(){
            var start_time = $("#start_time").val();
            var end_time = $("#end_time").val();
            if(start_time != '' && end_time != '' && start_time > end_time){
                layer.msg('开始时间不能大于结束时间');
                return false;
            }
            var login_start_time = $("#login_start_time").val();
            var login_end_time = $("#login_end_time").val();
            if(login_start_time != '' && login_end_time != '' && login_start_time > login_end_time){
                layer.msg('最后登录开始时间不能大于结束时间');
                return false;
            }
            return true;
        }
        function changesort(type){
            var sort_type = $("#sort_type").val();
            if(sort_type != type){
                var sort = 1;
            }else{
                var sort = $("#sort").val();
            }
            $("#sort_type").val(type);
            if(sort == 1){
                $("#sort").val(2);
            }else if(sort == 2){
                $("#sort").val(3);
            }else{
                $("#sort").val(1);
            }
           $("#search_btn").click();
        }

        // 点击查看綁币信息
        function open_bangbi_lists(user_id) {
            var user_id = user_id;
            // alert(user_id);
            layer.open({
                type: 2,
                title: "绑币余额",
                shadeClose: true,
                shade: 0.8,
                area: ['1062px', '80%'],
                content: "<?php echo url('user_bind_balance'); ?>?user_id="+user_id //iframe的url
            });
        };

    </script>
</body>
</html>
