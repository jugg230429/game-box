<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:108:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/recharge/spend/lists.html";i:1632734362;s:101:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/public/header.html";i:1632734362;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
            position: absolute;
            left: 5px;
            top: 37%;
        }
        .mailer-test .form-required {
            top: 15%;
        }
        .mailer-test .form-horizontal .control-label {
            width: 30%;
        }

        .btn.disabled, .btn[disabled], fieldset[disabled] .btn {
            background-color: #999;
            border-color: #999;
        }

        .btn.disabled:hover, .btn[disabled]:hover, fieldset[disabled] .btn:hover {
            background-color: #999;
            border-color: #999;
        }


        /*新加*/
        .dropdown-menu > .active > a, .dropdown-menu > .active > a:hover, .dropdown-menu > .active > a:focus {
            background-color: #1E91FF;
        }

        .dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus {
            background-color: #1E91FF;
        }

        tbody > .data_summary {
            background-color: #e6e6e6;
        }

    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
        var saveAsImage = 'http://<?php echo $_SERVER["HTTP_HOST"]; ?>/themes/admin_simpleboot3/public/assets/images/data_btn_download_n.png';
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <link rel="stylesheet" href="/themes/admin_simpleboot3/public/assets/css/bootstrap-select.css">
    <script src="/static/js/layer/layer.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap-select.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/defaults-zh_CN.js"></script>
    <link rel="stylesheet" type="text/css" media="all" href="/static/js/datejs/daterangepicker.css"/>
    <script type="text/javascript" src="/static/js/datejs/moment.min.js"></script>
    <script type="text/javascript" src="/static/js/datejs/daterangepicker.js"></script>
    <script>
        btn_tijiao_load_img_id = 0;
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container: 'body',
                html: true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
            $('.pagination .jspagerow').change(function () {
                value = $('.pagination .jspagerow option:selected').attr('vv');
                $('#page').remove();
                $('#search_form').append('<input type="hidden" id="page" name="row" value="' + value + '">');
                $('#search_btn').click();
            });

            $("body").bind("keydown", function (event) {
                if (event.keyCode == 116) {
                    event.preventDefault(); //阻止默认刷新
                    //location.reload();
                    //采用location.reload()在火狐下可能会有问题，火狐会保留上一次链接
                    location = location;
                }
            })
        });

        var unSelected = "#acb6c0";
        var selected = "#2C3E50";
        $(function () {
            $("select").css("color", unSelected);
            $("option").css("color", selected);
            $("select").change(function () {
                var selItem = $(this).val();
                if (selItem == $(this).find('option:first').val()) {
                    $(this).css("color", unSelected);
                } else {
                    $(this).css("color", selected);
                }
            });
        })

    </script>
    <script>
        // 更改button状态
        function change_submit_btn(consa, registe_btn) {
            j = 0;
            consa.find('input,select').each(function (i, n) {
                that = $(this);
                that.hasClass('jsmust')&&!that.val()?registe_btn.prop('disabled',true):j++;
            });
            if(j==consa.find('input,select').length){
                registe_btn.prop('disabled',false);
            }
        }
    </script>
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
        #think_page_trace_open {
        z-index: 9999;
    }
    </style>
    <?php endif; ?>

</head>
<body>
<style>
    .bind_order_promote {
        overflow: visible;
    }
    .bind_order_promote.layui-layer-page .layui-layer-content {
        overflow: visible;
    }
    .bind_order_promote .layui-layer-content {
        height: 75px;
    }
    .clear {
        clear: both;
    }
    .addPromoteDialog .form-group {
        height: 35px;
        margin-left: 7px;
        margin-top: 15px;
    }
    .tipFinal{
        margin: 10px 20px 20px 96px;
        /* margin-left: 96px; */
        color: red;
        width: 74%;

    }
     .layui-layer-content {
    position: relative;
    padding: 20px 20px 0 20px;
    word-wrap: break-word;
    word-break: normal;
    overflow-y: auto;
}
.layui-layer-title  .layui-layer-content {
    position: relative;
    padding: 20px 20px 0 20px;
    word-wrap: break-word;
    word-break: normal;
}
.layui-layer-btn {
    padding: 74px 0 16px 109px !important;
    text-align: left;

    }
    .open{
        margin-left: 2px !important;
    }
</style>
    <div class="wrap js-check-wrap">
        <ul class="nav nav-tabs">
            <li class="active"><a href="<?php echo url('spend/lists'); ?>">游戏订单</a></li>
            <span class="title_remark">说明：统计用户游戏内的消费订单，包括SDK现金支付、平台币支付。订单异常指苹果SDK内的苹果支付异常订单。</span>
        </ul>
        <form id="search_form" class="well form-inline  fr" style="width:94%;margin-right: 0px;" method="get" action="<?php echo url('spend/lists'); ?>" onsubmit="return check();">
            <?php if(AUTH_PROMOTE == 1): ?>
                <input type="text" class="form-control" name="user_account" style="width: 120px;" value="<?php echo input('request.user_account/s',''); ?>" placeholder="账号">
            <?php endif; ?>

            <input type="text" class="form-control" name="pay_order_number" style="width: 120px;" value="<?php echo input('pay_order_number/s',''); ?>" placeholder="支付订单号">
            <input type="text" class="form-control" name="extend" style="width: 120px;" value="<?php echo input('request.extend/s',''); ?>" placeholder="CP订单号">

            <input type="text" class="form-control js-bootstrap-date" id="start_time" name="start_time" placeholder="充值开始时间"
                   value="<?php echo input('request.start_time/s',''); ?>" style="width: 140px;" autocomplete="off">-
            <input type="text" class="form-control js-bootstrap-date" id="end_time" name="end_time" placeholder="充值结束时间"
                   value="<?php echo input('request.end_time/s',''); ?>" style="width: 140px;" autocomplete="off">
            <select name="promote_account" id="promote_account" class="selectpicker " promote_account="<?php echo input('request.promote_account'); ?>" data-live-search="true" data-size="8" style="width: 100px;">
                <option value="">渠道账号</option>
                <option value="is_gf" >官方渠道</option>
                <?php $_result=get_promote_list();if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <option value="<?php echo $vo['account']; ?>" ><?php echo $vo['account']; ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
            <select name="top_promote" id="top_promote" class="selectpicker sss" top_promote="<?php echo input('request.top_promote'); ?>" data-live-search="true" data-size="8" style="width: 100px;">
                <option value="">上线渠道</option>
                <?php $map=['parent_id'=>['eq',0]]; ?>
                <option value="is_gf" >官方渠道</option>
                <?php $_result=get_promote_list($map);if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <option value="<?php echo $vo['id']; ?>" ><?php echo $vo['account']; ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>
            <?php if(AUTH_GAME == 1): ?>
                <select name="game_id" id="game_id" class="selectpicker " game_id="<?php echo input('request.game_id'); ?>" data-live-search="true" data-size="8" style="width: 100px;">
                    <option value="">游戏名称</option>
                    <?php $_result=get_game_list('id,game_name');if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <option game-id="<?php echo $vo['id']; ?>" value="<?php echo $vo['id']; ?>" ><?php echo $vo['game_name']; ?></option>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
                <input type="text" class="form-control" name="server_name" style="width: 120px;" value="<?php echo input('request.server_name/s',''); ?>" placeholder="区服名称">
            <?php endif; ?>
            <select name="pay_way" id="pay_way" class="selectpicker" pay_way="<?php echo input('request.pay_way'); ?>">
                <option value="">充值方式</option>
                <option value="1" <?php if(input('request.pay_way') == 1): ?>selected<?php endif; ?>>绑币</option>
                <option value="2" <?php if(input('request.pay_way') == 2): ?>selected<?php endif; ?>>平台币</option>
                <option value="3" <?php if(input('request.pay_way') == 3): ?>selected<?php endif; ?>>支付宝</option>
                <option value="4" <?php if(input('request.pay_way') == 4): ?>selected<?php endif; ?>>微信</option>
                <option value="6" <?php if(input('request.pay_way') == 6): ?>selected<?php endif; ?>>苹果内购</option>
            </select>

            <input type="text" class="form-control" name="spend_ip" style="width: 120px;" value="<?php echo input('request.spend_ip/s',''); ?>" placeholder="充值IP">
            <select name="pay_status" id="pay_status" class="selectpicker" pay_status="<?php echo input('request.pay_status'); ?>" style="width: 120px;">
                <option value="">订单状态</option>
                <option value="1" <?php if(input('pay_status') == 1): ?>selected<?php endif; ?>>充值成功</option>
                <option value="0" <?php if(input('pay_status') == '0'): ?>selected<?php endif; ?>>下单未付款</option>
                <option value="2" <?php if(input('pay_status') == 2): ?>selected<?php endif; ?>>订单异常</option>
            </select>
            <?php if(AUTH_GAME == 1): ?>
                <select name="pay_game_status" id="pay_game_status" class="selectpicker" pay_game_status="<?php echo input('request.pay_game_status'); ?>" style="width: 140px;">
                    <option value="">游戏通知状态</option>
                    <option value="1" <?php if(input('pay_game_status') == 1): ?>selected<?php endif; ?>>通知成功</option>
                    <option value="0" <?php if(input('pay_game_status') === '0'): ?>selected<?php endif; ?>>通知失败</option>
                </select>
            <?php endif; ?>
            <select name="cp_id" id="cp_id" class="selectpicker " data-live-search="true" data-size="8" style="width: 100px;">
                <option value="">所属CP</option>
                <?php $_result=get_cp_list();if(is_array($_result) || $_result instanceof \think\Collection || $_result instanceof \think\Paginator): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <option value="<?php echo $vo['id']; ?>" <?php if(input('request.cp_id') == $vo['id']): ?>selected<?php endif; ?> ><?php echo $vo['cp_name']; ?></option>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </select>

            <select name="use_coupon" id="use_coupon" class="selectpicker " data-live-search="true" data-size="8" style="width: 100px;">
                <option value="">代金券折扣</option>
                <option value="1" <?php if(input('use_coupon')=='1') echo 'selected'; ?> >使用代金券</option>
                <option value="0" <?php if(input('use_coupon')==='0') echo 'selected'; ?> >未使用代金券</option>
            </select>
            <input type="hidden" name="sort" id="sort" value="<?php echo input('request.sort',1); ?>">
            <input type="hidden" name="sort_type" id="sort_type" value="<?php echo input('request.sort_type'); ?>">
            <input type="submit" class="btn btn-primary" id="search_btn" value="搜索" />
            <a class="btn btn-clear" href="<?php echo url('spend/lists'); ?>">清空</a>
            <a class="btn btn-export js-ajax-dialog-btn-xz" data-msg="确定导出吗？" href="<?php echo url('Export/expUser',array_merge(['id'=>1,'xlsname'=>'游戏充值'],input())); ?>">导出</a>
        </form>
        <form class="js-ajax-form" action="" method="post" style="margin-left: -8px;">
            <input type="hidden" id="f_promote_id" name="promote_id" >
        <div class="table-actions position">
            <button class="btn btn-primary js-pop-submit mtb17"
                    data-action="<?php echo url('bind'); ?>" >
                订单绑定
            </button>
        </div>
        <div class="scroll-table-wrapper">
        <table class="table table-hover table-bordered scroll-table" style="margin-left:0px;">
            <thead>
                <tr>
                    <th>
                        <input type="checkbox" id="all-checkbox" class="table-item-checkbox js-check-all" data-direction="x" data-checklist="js-check-x">
                        <label for="all-checkbox" class=""></label>
                    </th>
                    <th>订单号</th>
                    <th>CP订单号</th>
                    <th>时间</th>
                    <th>账号</th>
                    <th>游戏名称</th>
                    <th>所属渠道</th>
                    <th>充值IP</th>
                    <th>游戏区服</th>
                    <th>角色名称</th>
<!--                    <th>额外信息</th>-->
                    <!--<th>角色等级</th>-->
                    <th>订单金额</th>
                    <th>
                        <a href="javascript:changesort('pay_amount');">实付金额
                            <?php if(input('request.sort_type') == 'pay_amount' and input('request.sort') == 2): ?>▼
                                <?php elseif(input('request.sort_type') == 'pay_amount' and input('request.sort') == 3): ?>▲
                                <?php else: ?>
                                <img src="/themes/admin_simpleboot3/public/assets/images/up-down.png" width="7px">
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>代金券抵扣</th>
                    <th>充值方式</th>
                    <th>折扣</th>
                    <th>所属CP</th>
                    <th>订单状态</th>
                    <th>游戏通知状态</th>
                    <th><?php echo lang('ACTIONS'); ?></th>
                    <th>额外信息</th>
                </tr>
            </thead>
            <tbody style="background: #ffffff">
                <?php if(empty($data_lists) || (($data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator ) && $data_lists->isEmpty())): ?>
                    <tr><td colspan="19" style="text-align: center;">暂无数据</td></tr>
                <?php else: if(is_array($data_lists) || $data_lists instanceof \think\Collection || $data_lists instanceof \think\Paginator): if( count($data_lists)==0 ) : echo "" ;else: foreach($data_lists as $key=>$vo): ?>
                    <tr>
                        <?php if($vo['pay_status'] == 1) { $page_total +=$vo['pay_amount']; $page_us_total += $vo['us_cost'];} ?>
                        <td>
                            <input type="checkbox" id="ids-checkbox<?php echo $vo['id']; ?>" class="table-item-checkbox js-check" <?php if($vo['status'] == 1 or $vo['pay_status'] != 1): ?> disabled<?php endif; ?> data-yid="js-check-y" data-xid="js-check-x" name="ids[]"
                            value="<?php echo $vo['id']; ?>" >
                            <label for="ids-checkbox<?php echo $vo['id']; ?>" class=""></label>
                        </td>
                        <td><?php echo $vo['pay_order_number']; ?></td>
                        <td title="<?php echo $vo['extend']; ?>"><a data-order="<?php echo $vo['extend']; ?>" href="javascript:;" class="show_order_no">查看</a> </td>
                        <td><?php echo date("Y-m-d H:i:s",$vo['pay_time']); ?></td>
                        <td><?php echo $vo['user_account']; ?></td>
                        <td><?php echo $vo['game_name']; ?></td>
                        <?php if(AUTH_PROMOTE == 1): ?>
                            <td><?php echo get_promote_name($vo['promote_id']); ?></td>
                        <?php else: ?>
                            <td>请购买渠道权限</td>
                        <?php endif; ?>
                        <td><?php echo $vo['spend_ip']; ?></td>
                        <td><?php echo $vo['server_name']?:'--'; ?></td>
                        <td><?php echo $vo['game_player_name']?:'--'; ?></td>
                        <!--<td><?php if($vo['role_level'] > 0): ?><?php echo $vo['role_level']; else: ?>&#45;&#45;<?php endif; ?></td>-->
                        <td>
                            <div>￥<?php echo $vo['cost']; ?></div>
                            <?php if($vo['area'] == '1'): ?>
                            <div style="font-size:10px;color:#999;">(<?php echo $vo['currency_code']; ?> <?php echo $vo['currency_cost']; ?>/$<?php echo $vo['us_cost']; ?>)</div>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $vo['pay_amount']; ?></td>
                        <td>
                            <?php if($vo['pay_status'] == '1'): if(empty($vo['coupon_record_id']) || (($vo['coupon_record_id'] instanceof \think\Collection || $vo['coupon_record_id'] instanceof \think\Paginator ) && $vo['coupon_record_id']->isEmpty())): ?>--<?php else: ?><?php echo get_coupon_entity($vo['coupon_record_id'],'money')['money']; endif; else: ?>--<?php endif; ?></td>
                        <td><?php echo get_pay_way($vo['pay_way']); ?></td>
                        <td><?php if($vo['discount'] == 10): else: ?><?php echo $vo['discount']; ?>折<?php endif; ?></td>
                        <td><?php echo get_game_cp_name($vo['game_id']); ?></td>
                        <td>
                            <span <?php if($vo['pay_status'] == 1): ?> class="label" style="color:#3FAD46;font-size:14px"<?php else: ?>class="label" style="color:#d9534f;font-size:14px"<?php endif; ?>><?php echo get_info_status($vo['pay_status'],2); ?></span>
                        </td>
                        <td>
                            <spa <?php if($vo['pay_game_status'] == 1): ?> class="label" style="color:#3FAD46;font-size:14px"<?php else: ?>class="label " style="color:#d9534f;font-size:14px"<?php endif; ?>><?php echo get_info_status($vo['pay_game_status'],3); ?></span>
                        </td>
                        <td>
                            <?php if(($vo['pay_game_status'] == 0 and $vo['pay_status'] == 1) or $vo['pay_status'] == 2): ?>
                                <a href="javascript:;" class="budan" data-orderno="<?php echo $vo['pay_order_number']; ?>">
                                    补单
                                </a>
                                <a href="javascript:;" class="callback-info" data-orderno="<?php echo $vo['pay_order_number']; ?>">回调信息</a>
                            <?php else: ?>
                                --
                            <?php endif; ?>
                        </td>
                        <td><?php echo $vo['goods_reserve']?:'--'; ?></td>
                    </tr>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                     <tr class="data_summary">
                        <td colspan="2"><span style="margin-right: 10px;">汇总（只汇总充值成功） </span></td>
                         <td colspan="18"><span>今日充值：<?php echo null_to_0($today['total']); ?>元<?php if($pay_oversea == '1'): ?>($<?php echo null_to_0($today['us_total']); ?>)<?php endif; ?> ； 昨日充值：<?php echo null_to_0($yestoday['total']); ?>元<?php if($pay_oversea == '1'): ?>($<?php echo null_to_0($yestoday['us_total']); ?>)<?php endif; ?> ； 当页充值：<?php echo null_to_0($page_total); ?>元<?php if($pay_oversea == '1'): ?>($<?php echo null_to_0($page_us_total); ?>)<?php endif; ?> ； 累计充值：<?php echo null_to_0($total['total']); ?>元<?php if($pay_oversea == '1'): ?>($<?php echo null_to_0($total['us_total']); ?>)<?php endif; ?>； 累计充值用户数：<?php echo $totaluser; ?>人;  累计订单金额：<?php echo $order_total_money['all_cost']; ?>元</span></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
        </form>
        <div class="pagination">
            <?php echo $page; ?>
        </div>
    </div>
    <script src="/static/js/admin.js"></script>
    <script src="/static/js/layer/layer.js"></script>
    <script type="text/javascript">
        game_id = $("#game_id").attr('game_id');
        account = $("#promote_account").attr('promote_account');
        top_promote = $('#top_promote').attr('top_promote');
        server_id = $("#server_id").attr('server_id');
        $("#game_id").selectpicker('val', game_id);
        $("#promote_account").selectpicker('val', account);
        $("#top_promote").selectpicker('val', top_promote);
        $("#pay_way").selectpicker('val', $('#pay_way').attr('pay_way'));
        $("#pay_status").selectpicker('val', $('#pay_status').attr('pay_status'));
        $("#pay_game_status").selectpicker('val', $('#pay_game_status').attr('pay_game_status'));

        $(".show_order_no").click(function () {
            var order = $(this).data('order');
            layer.open({
                type: 1,
                title:"CP订单号",
                skin: 'layui-layer-rim', //加上边框
                area: ['400px', '200px'], //宽高
                content: order
            });
        })

        //回调信息查看
        $(".callback-info").click(function () {
            var pay_order_number = $(this).data('orderno');
            var getNotifyInfoUrl = "<?php echo url('recharge/spend/getNotifyInfo'); ?>";
            $.post(getNotifyInfoUrl, {pay_order_number: pay_order_number}, function (res) {
                var game_notify_info = res.data.game_notify_info;
                layer.open({
                    type: 1,
                    title: "回调信息",
                    closeBtn :1,
                    skin: 'layui-layer-rim', //加上边框
                    area: ['400px', '300px'], //宽高
                    content: game_notify_info
                });
            });
        })

        $('button.js-pop-submit').on('click', function (e) {
            var btn = $(this), form = btn.parents('form.js-ajax-form');
            btn.parent().find('span').remove();
            if (form.find('input.js-check:checked').length) {
                btn.data('subcheck', false);
            } else {
                var pay_order_number = $(this).data('orderno');
            var getNotifyInfoUrl = "<?php echo url('recharge/spend/getNotifyInfo'); ?>";
            $.post(getNotifyInfoUrl, {pay_order_number: pay_order_number}, function (res) {
                var game_notify_info = res.data.game_notify_info;
                layer.open({
                    type: 1,
                    title: "订单绑定",
                    skin: 'layui-layer-rim', //加上边框
                    area: ['200px', '106px'], //宽高
                    content: '<span class="tips_error" style="color:red;margin-left: 3px;">请至少选择一项</span>'
                });
            });
                // var btnStyle = btn.data('style') || '';
                // $('<span class="tips_error" style="' + btnStyle + '">请至少选择一项</span>').appendTo(btn.parent()).fadeIn('fast');
                return false;
            }
            //ie处理placeholder提交问题
            if ($.browser && $.browser.msie) {
                form.find('[placeholder]').each(function () {
                    var input = $(this);
                    if (input.val() == input.attr('placeholder')) {
                        input.val('');
                    }
                });
            }

            $.post('<?php echo url("get_promote_lists"); ?>', function (data) {
                var html='<form class="js-ajax-form addPromoteDialog" action="" method="post">' +
                    '<div class="form-group clear">' +
                    '<label for="input-site_seo_title" class="col-sm-3 control-label" style="line-height: 32px;width:16%;padding-right:0">绑定渠道：</label>' +
                    '<div class="col-sm-9" style="padding-left:0">' +
                    '<select id="promote_id" name="promote_id" class="form-control selectpicker" data-live-search="true" data-size="8"> ' +
                    '<option value="">选择渠道</option>' +
                    '<option value="0">官方渠道</option>';

                if (data.code==1 && data.data) {
                    $.each(data.data, function (index, item) {
                        html += '<option value="'+item.id+'" >'+item.account+'</option>'
                    })
                }

                html += '</select>' +
                    '</div>' +
                    '</div>' +
                    '<div class="tipFinal">注：补链后会出现【数据报表】下的数据与实时记录表内的数据不一致问题，希望显示一致需联系售后进行定制化处理。</div>'+
                    '</form>';

                layer.open({
                    type: 1,
                    title:"新增绑定",
                    skin: 'bind_order_promote', //加上边框
                    area: ['600px', 'auto'], //宽高
                    btn: ['确定', '取消'],
                    content: html,
                    success: function (layero) {
                        layero.find('#promote_id').selectpicker();
                    },
                    yes: function (index, layero) {
                        var promote_id = layero.find('#promote_id').val();
                        if (!isNaN(parseInt(promote_id))) {
                            form.find('#f_promote_id').val(promote_id);
                            $.post(btn.attr('data-action'), form.find('input.js-check:checked, input#f_promote_id').serialize(), function (response) {
                                if (response.code==1) {
                                    layer.msg(response.msg)
                                    layer.close(index)
                                    setTimeout(function () {
                                        window.location.reload();
                                    },1000)
                                } else {
                                    layer.msg(response.msg)
                                }
                            }, 'json');

                        } else {
                            layer.msg('请选择渠道')
                        }
                    },
                });
            }, 'json');

            return false;
        });


        function check(){
            var start_time = $("#start_time").val();
            var end_time = $("#end_time").val();
            if(start_time != '' && end_time != '' && start_time > end_time){
                layer.msg('开始时间不能大于结束时间');
                return false;
            }
            return true;
        }
        $('.budan').click(function(){
            var orderno = $(this).attr('data-orderno');
            $.ajax({
                url:"<?php echo url('repair'); ?>",
                type:'post',
                dataType:'json',
                data:{orderno:orderno},
                success:function(res){
                    layer.msg(res.msg);
                    if(res.code == 1){
                        setTimeout(function () {
                            window.location.reload();
                        },1000)
                    }
                },error(){
                    layer.msg('服务器错误');
                }
            })
        });
        function changesort(type){
            var sort_type = $("#sort_type").val();
            if(sort_type != type){
                var sort = 1;
            }else{
                var sort = $("#sort").val();
            }
            $("#sort_type").val(type);
            if(sort == 1){
                $("#sort").val(2);
            }else if(sort == 2){
                $("#sort").val(3);
            }else{
                $("#sort").val(1);
            }
            $("#search_btn").click();
        }
    </script>
</body>
</html>
