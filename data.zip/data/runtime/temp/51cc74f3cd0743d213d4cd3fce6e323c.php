<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:105:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/admin/index/index.html";i:1632734358;s:101:"/opt/homebrew/Cellar/nginx/1.25.5/project/game-box/public/themes/admin_simpleboot3/admin/website.html";i:1632734360;}*/ ?>
<!DOCTYPE html>
<html lang="zh_CN" style="height: 100%;overflow: hidden;">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta charset="utf-8">
    <title><?php echo cmf_get_option('admin_set')['web_site_title']; ?></title>
    <meta name="description" content="<?php echo cmf_get_option('admin_set')['web_set_meta_desc']; ?>">
    <meta name="keywords" content="<?php echo cmf_get_option('admin_set')['web_set_telecom_license']; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->
    <link href="<?php echo cmf_get_image_url(cmf_get_option('admin_set')['web_set_ico']); ?>" type="image/x-icon"  rel="shortcut icon">
    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
	 <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/index.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css?page=index" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/simplebootadminindex.min.css">
    <link href="/themes/admin_simpleboot3/public/assets/css/newBar.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/css/newLogin.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        /* body {
            overflow: hidden!important;
        } */
        /*-----------------导航hack--------------------*/
        .nav-list > li.open {
            position: relative;
        }

        .nav-list > li.open .back {
            display: none;
        }

        .nav-list > li.open .normal {
            display: inline-block !important;
        }

        .nav-list > li .submenu > li > a {
            background: #2f3160;
        }

        .nav-list > li .submenu > li a > [class*="fa-"]:first-child {
            left: 40px;
        }

        .nav-list > li ul.submenu ul.submenu > li a > [class*="fa-"]:first-child {
            left: 50px;
        }
        .nav-list>li {
            min-height: 101px;
            border-bottom: 1px solid #1B2F52;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        .nav-list .one-menu-title {
            color: #fff;
            line-height: 29px;
        }
        #nav-wrapper {
            padding-top: 0;
            display:flex;
            overflow: auto;
            width: 220px;
            background: #162642;
        }
        .nav-list>li .submenu {
            display: block;
            background-color: #162642;
        }
        .dropdown-menu.open {
		margin-left: 0px !important;
}
        .nav-list .submenu.two-menu.twoSubMenuChange {
            padding-left: 33px;
        }

        .nav-list>li>.submenu li {
           float: left;
        }
        .nav-list>li>.submenu li.havetreeMenuData {
            display: block;
            width: auto;
        }
        .nav-list > li .submenu > li > a {
            background: #162642;
        }
        .nav-list .submenu .two-menu-title {
            border-top: none;
        }
        .nav-list .one-menu-title {
            padding: 0;
        }
        .nav-list .submenu a {
            padding-left: 0;
        }
        .nav-list>li>.submenu li.havetreeMenuData a {
            margin-left: 0;
            padding-right: 7px;
            margin-right: 13px;
        }
        .nav-list>li .submenu.third-menu{
            margin-left: -1px;
        }
        .nav-list .submenu .third-menu-title {
            color: #C5D2E8;
        }
        .nav-list .submenu .two-menu-title .onlytwoText{
            color: #C5D2E8;
        }
        .nav-list .one-menu-title:hover {
            color: #fff;
        }
        .newListSilder {
            background-color: #000A1B;
            width: 1.6%;
        }
        .sliderSystem{
            color:#C5D2E8;
            width:auto;
            padding:20px 8px;
            background:#000A1B;
            line-height: 19px;
            word-break: break-all;
            text-align: center
        }
        .sliderSystem a {
            color:#C5D2E8;
        }
        .sliderSystem a:hover {
            color:#C5D2E8;
            text-decoration: none;
        }
        .activeSystem{
            background-color: #162642;
            color: #fff;
        }
        .customerOneMenu {
            height: 35px;
        }
        .havetreeMenuData .two-menu-title .menu-text {
            color: #1890FF;
        }
        .rejudgeItem{
            margin-left: 26px!important;
        }
        .overWidthItem {
            margin-right: 0!important;
            margin-left: 12px!important;
        }
        .removeWidth {
            margin-right: 0!important;
        }
        .changeIframe{
            display: block!important;
        }
        .fireFoxContent{
            margin-right: 5px!important;
        }
        .twelve {
            margin-left: 12px!important;
        }
        .nine {
            margin-left: 9px!important;
        }
        #navbar-main {
            box-shadow: 0px 0px 10px 1px rgba(60, 108, 188, 0.15);
        }

        @media screen and (max-width:900px) {
            body {
                overflow: hidden;
            }
           .newListSilder {
               width: 3%;
           }
           #nav-wrapper {
               width: 25.3%;
           }
           .rightTipOA{
               width: 78%;
           }
           .navbar-header {
               width: 100%!important;
           }
           .navbar-brand {
               width: 250px!important;
           }
           .page-content{
               height: 100%!important;
           }
           .systemModalLeft {
               width: 222px!important;
           }
           .rightMainContentIframe {
               width: 74%;
           }

        }


        .cooperationBox {
    /* display: none; */
    overflow: hidden;
    position: fixed;
    top: -46px;
    left: 0;
    bottom: 0;
    right: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,.5);
    z-index: 99;
}
.detailContainer {
    width: 786px;
    height: 534px;
    background: #FFFFFF;
    border-radius: 6px;
    margin: auto;
    margin-top: 10%;
}
.content-title {

    height: 54px;
    /* background: #29364C; */
    background-image: url("/themes/admin_simpleboot3/public/assets/images/bg_ptgg.png");
    border-radius: 6px 6px 0px 0px;
    color: #fff;
    font-size: 18px;
    position: relative;
    top: -1px;
}
.content-title p {
    padding: 13px 0 18px 25px;
}
.dialogOperationClose {
    content: '';
    display: block;
    width: 13px;
    height: 13px;
    background-image: url("/themes/admin_simpleboot3/public/assets/images/close_w.png");
    background-size: 100% 100%;
    position: absolute;
    right: 25px;
    top: 21px;
}
.title-bt{
    width: 725px;
    height: 18px;
    margin: 20px 31px 10px 30px;
    font-size: 20px;
    color: #354359;
    font-weight: Bold;
    letter-spacing:1px;
    font-family: 'MicrosoftYaHei';
}
.content-textBox {
    width: 748px;
    margin-left: 10px;
    margin: 25px 31px 0 30px;
    height: 392px;
    max-height: 349px;
    color: #354359;
    font-family: 'MicrosoftYaHei';
    font-size: 13px;
    letter-spacing: 1px;
    line-height: 25px;
    overflow-y: scroll;
    padding-bottom: 10px;
    overflow-x: hidden;
    margin-bottom: 7px;
}
.content1{
    width: 734px;
    float: left;
}
.xinxi{
    width: 725px;
    float: left;
    margin-top: 20px;
}
.bottom{
    width:100%;
    height: 60px;
    line-height: 60px;
    color: #354359;
    font-size: 13px;
    /* margin-top: -3px; */
    box-shadow:0px 5px 30px -16px #29364c;
}
.bottom p{
    color: #018FFF;
   width:300px;
    overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;

}
.shang{
    margin: 0px 20px 10px 30px;

    float:left;
}

.bottom a{color: #018FFF;}
.xia{
    float:left;
padding-left:20px;
}
.detailContainer-content .content-textBox img{
    width: 80%;
}
@media screen and (max-width: 1000px) {
    .cooperationBox {
        /* margin-top: 0px; */
        position: fixed;

    width: 100%;
    height: 130%;
    }
    .detailContainer-content {
    margin-top: -10%;
    height: 100px;
}
    .detailContainer {
        width:35%;
        margin-left: 35px;
    }
    .content1 {
    width: 100%;}
    .content-textBox {
    width: 85%;}
    .title-bt {
    width: 85%;
    height: 48px !important;
    font-size: 15px;
}
    .bottom p {
    width: 40%;}
    img {
    vertical-align: middle;
    width: 90%;
}
.content-textBox {
    height: 321px;
}

}
        /*----------------导航hack--------------------*/
    </style>

    <script>
        //全局变量
        var GV = {
            HOST: "<?php echo (isset($_SERVER['HTTP_HOST']) && ($_SERVER['HTTP_HOST'] !== '')?$_SERVER['HTTP_HOST']:''); ?>",
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/"
        };
    </script>
    <?php $submenus=$menus; 
        if (!function_exists('getsubmenu')) {
            function getsubmenu($submenus){

     if(!(empty($submenus) || (($submenus instanceof \think\Collection || $submenus instanceof \think\Paginator ) && $submenus->isEmpty()))): foreach($submenus as $menu){ ?>
        <li>
            <?php 
                $menu_name=lang($menu['lang']);
                $menu_name=$menu['lang']==$menu_name?$menu['name']:$menu_name;
             if(empty($menu['items'])){ ?>
            <a href="javascript:openapp('<?php echo $menu['url']; ?>','<?php echo $menu['id']; ?>','<?php echo $menu_name; ?>',true);" data-menu="<?php echo $menu_name; ?>" data-id="<?php echo intval($menu['id']); ?>" class="one-menu-title one-no-drop-title js-one-menu-title">
                <i class="fa fa-<?php echo (isset($menu['icon']) && ($menu['icon'] !== '')?$menu['icon']:'desktop'); ?>"></i>
                <span class="menu-text"> <?php echo $menu_name; ?> </span>
            </a>
            <?php }else{ ?>
            <a href="javascript:;" style="pointer-events: none;" class="dropdown-toggle one-menu-title one-drop-title js-one-drop-title customerOneMenu">
                <i class="fa fa-<?php echo (isset($menu['icon']) && ($menu['icon'] !== '')?$menu['icon']:'desktop'); ?> normal"></i>
                <span class="menu-text normal"> <?php echo $menu_name; ?> </span>
                <!-- <b class="arrow fa fa-angle-right normal"></b> -->
                <i class="fa fa-reply back"></i>
                <span class="menu-text back">返回</span>

            </a>

            <ul class="submenu two-menu twoSubMenuChange">
                <?php getsubmenu1($menu['items']) ?>
            </ul>
            <?php } ?>

        </li>

        <?php } endif; 
            }
        }
     
        if (!function_exists('getsubmenu1')) {
            function getsubmenu1($submenus){
     foreach($submenus as $menu){ ?>
    <li class="havetreeMenuData">
        <?php 
            $menu_name=lang($menu['lang']);
            $menu_name=$menu['lang']==$menu_name?$menu['name']:$menu_name;
         if(empty($menu['items'])){ ?>
        <a href="javascript:openapp('<?php echo $menu['url']; ?>','<?php echo $menu['id']; ?>','<?php echo $menu_name; ?>',true);" data-menu="<?php echo $menu_name; ?>" data-id="<?php echo intval($menu['id']); ?>" id="menuData" class="two-menu-title two-no-drop-title js-two-menu-title">
            <!-- <b class="menu-dot"></b> -->
            <span class="menu-text onlytwoText">
									<?php echo $menu_name; ?>
								</span>
        </a>
        <?php }else{ ?>
        <a href="javascript:;" style="pointer-events: none;" class="dropdown-toggle two-menu-title two-drop-title js-two-menu-title">
            <b class="menu-dot"></b>
            <span class="menu-text">
									<?php echo $menu_name; ?>
								</span>
            <!--<b class="arrow fa fa-angle-right"></b>-->
        </a>
        <ul class="submenu third-menu">
            <?php getsubmenu2($menu['items']) ?>
        </ul>
        <?php } ?>

    </li>

    <?php } }
    }
     
        if (!function_exists('getsubmenu2')) {
            function getsubmenu2($submenus){ foreach($submenus as $menu){ ?>
    <li>
        <?php 
            $menu_name=lang($menu['lang']);
            $menu_name=$menu['lang']==$menu_name?$menu['name']:$menu_name;
         ?>

        <a href="javascript:openapp('<?php echo $menu['url']; ?>','<?php echo $menu['id']; ?>','<?php echo $menu_name; ?>',true);" data-menu="<?php echo $menu_name; ?>" data-id="<?php echo intval($menu['id']); ?>" id="menuData"  class="third-menu-title js-third-menu-title">
            <span class="menu-text">
								<?php echo $menu_name; ?>
							</span>
        </a>
    </li>

    <?php } }
    }
     if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                left: 0 !important;
                right: initial !important;
            }
        </style>
    <?php endif; ?>

</head>

<body style="height: 100%;min-width: 900px;-webkit-overflow-scrolling: touch">
<div id="loading"><i class="loadingicon"></i><span><?php echo lang('LOADING'); ?></span></div>
<div id="right-tools-wrapper">
    <!--<span id="right_tools_clearcache" title="清除缓存" onclick="javascript:openapp('<?php echo url('admin/Setting/clearcache'); ?>','right_tool_clearcache','清除缓存');"><i class="fa fa-trash-o right_tool_icon"></i></span>-->
    <!--<span id="refresh-wrapper" title="<?php echo lang('REFRESH_CURRENT_PAGE'); ?>"><i-->
            <!--class="fa fa-refresh right_tool_icon"></i></span>-->
</div>
<div class="navbar navbar-default top-navbar" >
    <div style="display: flex;width:100%;height: 54px;">
        <div class="newListSilder" style="width:1.6% ;">&nbsp;</div>

    <div style="width:100%;display: flex;">
    <div class="container-fluid" style="display:flex;width:100%;padding: 0;">

        <div class="navbar-header" style="width: 220px;float: none;">

			 <a href="<?php echo url('admin/index/index'); ?>" class="navbar-brand" style="width:100%;text-align: center;background:rgba(22, 38, 66, 1);line-height: 30px;padding: 0!important;">
               <div style="width: 100%;height: 100%;display: flex;align-items: center;justify-content: center;">
                    <img src="<?php echo cmf_get_image_url(cmf_get_option('admin_set')['web_set_center_logo']); ?>" alt="手游联运系统"  style="height: 45px;" >
               </div>
            </a>
            <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>

        <div class="navbar-collapse collapse" id="navbar-main" style="padding-left: 0!important;flex: 1;">
            <div class="pull-left headerNav" style="position: relative;">
               <div class="newHeaderAddNav">
                <div class="navShowBtn">
                    <i class="putAwayIcon"></i>
                </div>
                <a href="javascript:;" class="headerNavLeft"></a>
                <a id="task-pre" class="task-changebt"><i class="fa fa-chevron-left"></i></a>
                <div id="task-content" class="headerNavListBox">
                    <ul class="nav navbar-nav cmf-component-tab headerNavList" id="task-content-inner">
                        <li class="cmf-component-tabitem noclose jsfirsttab active" app-id="0" app-url="<?php echo url('main/index'); ?>"
                            app-name="首页">
                            <a class="cmf-tabs-item-text headerNavLink" app-id="0" app-url="<?php echo url('main/index'); ?>">后台首页</a>
                        </li>
                    </ul>
                    <div style="clear:both;"></div>
                </div>
                <a href="javascript:;" class="headerNavRight" ></a>
                <a href="javascript:;" class="headerNavClose" ></a>
                <!-- <a class="btn btn-sm delete-all" id="close-wrapper" href="javascript:;"
                   title="关闭顶部菜单"
                   data-toggle="tooltip"
                   data-placement="bottom">
                    <img src="/themes/admin_simpleboot3/public/assets/images/icon_delete_all.png" >
                </a> -->
               </div>
            </div>

            <ul class="nav navbar-nav navbar-right simplewind-nav v-middle">
                <!--<li class="light-blue" style="border-left:none;display: none;" id="close-all-tabs-btn">
                    <a id="close-wrapper" href="javascript:void(0);" title="<?php echo lang('CLOSE_TOP_MENU'); ?>" style="color:#fff;font-size: 16px">
                        <i class="fa fa-times right_tool_icon"></i>
                    </a>
                </li>-->
                <li class="light-blue" style="border-left:none;">
                    <a id="refresh-wrapper" href="javacript:void(0);" title="<?php echo lang('REFRESH_CURRENT_PAGE'); ?>" >
                        <i class="fa fa-refresh_ right_tool_new_icon"></i>
                    </a>
                </li>
                <li class="light-blue dropdown" style="border-left:none;">
<!--                    <a data-toggle="dropdown" href="#" class="dropdown-toggle">-->
                    <a class="pr-5">

                        <span class="user-info">
								<?php echo lang('WELCOME_USER',array('user_nickname' => empty($admin['user_nickname'] )? $admin['user_login'] : $admin['user_nickname'])); ?>
							</span>
<!--                        <i class="fa fa-caret-down"></i>-->
                    </a>
                </li>
                 <li class="light-blue " style="border-left:none;"><a href="<?php echo url('Public/logout'); ?>" class="logout"><?php echo lang('LOGOUT'); ?></a>
            </ul>
            <div class="sidebar-shortcuts fr" id="sidebar-shortcuts">

                <!-- <a class="btn btn-sm"
                    href="javascript:openapp('<?php echo url('admin/Setting/clear_redis22'); ?>','index_clearcache','<?php echo lang('ADMIN_SETTING_CLEARCACHE'); ?>',true);"
                    title="删除"
                    data-toggle="tooltip"
                    data-placement="bottom">
                    <img src="/themes/admin_simpleboot3/public/assets/images/btn_eliminate.png">
                </a> -->

                <a class="btn btn-sm newbtn-home" href="/"
                   title="<?php echo lang('WEBSITE_HOME_PAGE'); ?>"
                   target="_blank"

                   data-placement="bottom">
                    <img src="/themes/admin_simpleboot3/public/assets/images/icon_home.png">
                </a>
                <!-- data-toggle="tooltip" -->

                <!--
                <?php if(cmf_auth_check(cmf_get_current_admin_id(),'portal/AdminCategory/index')): ?>
                    <a class="btn btn-sm btn-success" href="javascript:openapp('<?php echo url('portal/AdminCategory/index'); ?>','index_termlist','文章分类管理');" title="文章分类管理">
                        <i class="fa fa-th"></i>
                    </a>
                <?php endif; if(cmf_auth_check(cmf_get_current_admin_id(),'portal/AdminArticle/index')): ?>
                    <a class="btn btn-sm btn-info" href="javascript:openapp('<?php echo url('portal/AdminArticle/index'); ?>','index_postlist','文章管理');" title="文章管理">
                        <i class="fa fa-pencil"></i>
                    </a>
                <?php endif; ?>
                -->

                <!--            <?php if(cmf_auth_check(cmf_get_current_admin_id(),'user/AdminAsset/index')): ?>-->
                <!--                <a class="btn btn-sm newbtn-info"-->
                <!--                   href="javascript:openapp('<?php echo url('user/AdminAsset/index'); ?>','userAdminAssetindex','资源管理',true);"-->
                <!--                   title="资源管理"-->
                <!--                   data-toggle="tooltip">-->
                <!--                    <img src="/themes/admin_simpleboot3/public/assets/images/icon_info.png"> -->
                <!--                </a>-->
                <!--            <?php endif; ?>-->

                <?php if(cmf_auth_check(cmf_get_current_admin_id(),'admin/Setting/clearcache')): ?>
                    <a class="btn btn-sm newbtn-clear"
                       href="javascript:openapp('<?php echo url('admin/Setting/clearcache'); ?>','index_clearcache','<?php echo lang('ADMIN_SETTING_CLEARCACHE'); ?>',true);"
                       title="<?php echo lang('ADMIN_SETTING_CLEARCACHE'); ?>"

                       data-placement="bottom">
                        <img src="/themes/admin_simpleboot3/public/assets/images/icon_clear.png">
                    </a>
                <?php endif; ?>

                <!--            <?php if(cmf_auth_check(cmf_get_current_admin_id(),'admin/RecycleBin/index')): ?>-->
                <!--                <a class="btn btn-sm newbtn-recycle"-->
                <!--                   href="javascript:openapp('<?php echo url('admin/RecycleBin/index'); ?>','index_recycle','回收站',true);"-->
                <!--                   title="回收站"-->
                <!--                   data-toggle="tooltip">-->
                <!--                    <img src="/themes/admin_simpleboot3/public/assets/images/icon_recycle.png">-->
                <!--                </a>-->
                <!--            <?php endif; ?>-->

                <?php if(APP_DEBUG): ?>
                    <a class="btn btn-sm newbtn-menu"
                       href="javascript:openapp('<?php echo url('admin/Menu/index'); ?>','index_menu','<?php echo lang('ADMIN_MENU_INDEX'); ?>',true);"
                       title="<?php echo lang('ADMIN_MENU_INDEX'); ?>"

                       data-placement="bottom">
                        <img src="/themes/admin_simpleboot3/public/assets/images/icon_menu.png">
                    </a>
                <?php endif; ?>

            </div>
        </div>


        </div>
    </div>
    </div>
</div>
</div>

<div class="main-container container-fluid" style="height: calc(100% - 45px );transform: translateY(-8px);">
    <div style="display: flex;width:100%;height: 100%;">
        <div class="newListSilder">
            <ul style="cursor: pointer">
                <li class="sliderSystem activeSystem" id="js-homeBack" >旗舰管理后台</li>
                <!-- <li class="sliderSystem" ><a href="<?php echo cmf_get_option('system_set')['ad_domain']; ?>">广告监测分析系统</a></li> -->
                <li class="sliderSystem" id="js-scrm" ><a href="javascript:;">玩家维护和公会服务系统</a></li>
<!--                <li class="sliderSystem" id="js-fuwu"><a href="javaScript:;" >售后服务平台</a></li>-->
<!--                <li class="sliderSystem" id="js-kf_business" ><a href="javascript:;">在线客服系统</a></li>-->
<!--                <li class="sliderSystem" id="js-kf_work" ><a href="javascript:;">客服工作台</a></li>-->
                <li class="sliderSystem" id="issue_system" ><a href="javascript:;">发行系统</a></li>
                <li class="sliderSystem" id="js-oa" ><a href="javascript:;">工作室OA系统</a></li>
                <li class="sliderSystem" id="system_setting" onclick="" >系统设置</li>
            </ul>
        </div>
    <!-- 侧边栏右边的布局 -->
       <div style="width:100%;display: flex;">
        <!-- 套个iframe的话可以是OA的登录页 -->
        <!-- <iframe id="login_ifr" style="width:100%;height:100%;border:none"  src="http://www.oa.vlsdk.com/#/login" scrolling="no"></iframe> -->

        <!-- 这个是旗舰版的东西 -->
        <div style="width:100%;display: flex;" class="main-page">
            <div id="nav-wrapper" style="height: 100%;">
                <ul class=" nav-list one-menu" style="width:214px;padding-left:10px">
                    <?php echo getsubmenu($submenus); ?>
                </ul>
            </div>
            <div class="main-content" style="flex: 1;margin-left: 0;">
                <div class="page-content" id="content">
                    <iframe src="<?php echo url('Main/index'); ?>" style="width:100%;height: 100%;" frameborder="0" id="appiframe-0"
                            class="appiframe"></iframe>
                </div>
                <?php if(!empty($upgrade_data) and $upgrade_data['this_version'] != $upgrade_data['last_version']): ?>
                <div class="systemModal" hidden>
                    <div style="position: relative;width:100%;height:100%">
                        <div class="systemTipBox">
                            <div class="leftContentBox">
                            <div class="centerLimit">
                                    <div class="tipNowVersion">
                                        <p class="titleVersion">尊敬的客户您好~</p>
                                        <p style="line-height:25px;">该系统目前最新版本为<span class="deferrentColorBlue"><?php echo $upgrade_data['data'][0]['name']; ?></span>，监测到您还未升级至最新版本，为了第一时间体验新功能，建议您及时进行升级！</p>
                                    </div>
                                    <div>
                                        <p class="deferrentColorBlue"><span class="timeBeforeLogo"></span ><?php echo $upgrade_data['data'][0]['name']; ?>更新时间</p>
                                        <div class="showTimeBox"><?php echo date("Y-m-d",$upgrade_data['data'][0]['effective_time']); ?></div>
                                    </div>
                                    <div>
                                        <?php 
                                            $remark = explode(PHP_EOL,$upgrade_data['data'][0]['remark']);
                                         ?>
                                        <p class="deferrentColorBlue"><span class="timeBeforeLogo"></span ><?php echo $upgrade_data['data'][0]['name']; ?>更新内容</p>
                                        <div class="updateContentBox">
                                            <?php if(is_array($remark) || $remark instanceof \think\Collection || $remark instanceof \think\Paginator): $i = 0; $__LIST__ = $remark;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                                <p><?php echo $vo; ?></p>
                                            <?php endforeach; endif; else: echo "" ;endif; ?>
                                        </div>
                                    </div>
                            </div>
                                <p class="redTipText"><i class="tipRedIcon"></i>注：如您进行过个性化定制，可联系售后客服获取更新文件</p>
                                <div class="bottomUpdateBtn">
                                    <a href="javaScript:;" class="updateBtns cancelUpVersion">暂不升级</a>
                                    <a href="javascript:openapp('<?php echo url('upgrade/index/index'); ?>','','',true);" class="updateBtns rightUpVersion">立即升级</a>
                                </div>
                            </div>
                            <div class="rightImgBox">
                                <i class="closeModalIcon"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
           </div>

           <iframe id="login_ifr" style="width:100%;height:100%;border:none;display: none"  src="" scrolling="no"></iframe>
<style>
    .useBtn_n {
    display: block;
    width: 160px;
    height: 47px;
    background: #ffffff;
    border-radius: 5px;
    line-height: 47px;
    text-align: center;
    color: #2C68FF;
    box-shadow: 0px 4px 6px 0px rgb(56 113 233 / 80%);
    font-size: 16px;
    margin: auto;
    margin-top: 32px;
}
.useBtn_n:hover{
    color: #2C68FF;
    text-decoration: none;
}
</style>
<!-- 未购买旗舰版的提示 -->
<div class="unPayBoxHome firstDefaultHome" style="display: none">
    <div class="topTipBox">
        <p class="titleTip">您的账号尚未授权<span class="nowVersion">手游联运旗舰版</span>，请授权后使用！</p>
        <div class="tipDetail">
            <p style="margin-top: 10px;">不同系统自由组合，任意扩展，打通多平台数据、</p>
            <p>构建统一的用户ID体系，全盘释放运营威力</p>
        </div>
        <a href="https://www.vlsdk.com/" target="_blank" class="useBtn">申请授权使用</a>
    </div>
    <div class="con">
        <p class="title-productUnique">产品特色</p>
        <div class="showAllAdvantage">
            <div class="avantageModal">
                <img src="/themes/admin_simpleboot3/public/assets/images/login/png_one.png" alt="">
                <p class="itemAvantage">三合一系统</p>
                <div class="itemDetailAvantage">
                    <p>手游、H5游戏、页游 </p>
                    <p>一套系统同时运营</p>
                </div>
            </div>
            <div class="avantageModal">
                <img src="/themes/admin_simpleboot3/public/assets/images/login/png_two.png" alt="">
                <p class="itemAvantage">一键切换</p>
                <div class="itemDetailAvantage">
                    <p>三套系统统一键切换 </p>
                    <p>操作简单流畅</p>
                </div>
            </div>
            <div class="avantageModal">
                <img src="/themes/admin_simpleboot3/public/assets/images/login/png_three.png" alt="">
                <p class="itemAvantage">统一管理后台</p>
                <div class="itemDetailAvantage">
                    <p>实时查看游戏运营数据 </p>
                    <p>用户行为一“网”打尽</p>
                </div>
            </div>
            <div class="avantageModal">
                <img src="/themes/admin_simpleboot3/public/assets/images/login/png_four.png" alt="">
                <p class="itemAvantage">推广系统</p>
                <div class="itemDetailAvantage">
                    <p>海量资源自由对接  </p>
                    <p>分成比例自主拟定</p>
                </div>
            </div>
            <div class="avantageModal">
                <img src="/themes/admin_simpleboot3/public/assets/images/login/png_five.png" alt="">
                <p class="itemAvantage">游戏盒子APP</p>
                <div class="itemDetailAvantage">
                    <p>提升玩家活跃度及留存率 </p>
                    <p>为平台带来更多价值</p>
                </div>
            </div>
            <div class="avantageModal">
                <img src="/themes/admin_simpleboot3/public/assets/images/login/png_six.png" alt="">
                <p class="itemAvantage">游戏免费对接</p>
                <div class="itemDetailAvantage">
                    <p>提供海量游戏资源 帮助 </p>
                    <p>平台快速落地运营</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 未购买OA的提示 -->
<div class="unPayBoxHome oaHome changeOAHome" style="display: none">
    <div class="fl" style="padding-top: 10px;">
        <img src="/themes/admin_simpleboot3/public/assets/images/login/slider.png" alt="">
    </div>
    <div class="fl rightTipOA">
        <div class="topTipBox">
            <p class="titleTip">您的账号尚未授权<span class="nowVersion">工作室OA系统</span>，请授权后使用！</p>
            <div class="tipDetail">
                <p style="margin-top: 10px;">公会流水、成员业绩实时查询 </p>
                <p>内部人员自愿信息共享，让公会管理更简单</p>
            </div>
            <a href="http://oa.vlsdk.com/"  target="_blank" class="useBtn">申请授权使用</a>
        </div>
        <div class="con">
            <p class="title-productUnique">产品特色</p>
            <div class="showAllAdvantage">
                <div class="avantageModal">
                    <img src="/themes/admin_simpleboot3/public/assets/images/login/png_eleven.png" alt="">
                    <p class="itemAvantage">无限制</p>
                    <div class="itemDetailAvantage">
                        <p>支持所有联运平台系统 </p>
                        <p>对接即可使用，永久开源</p>
                    </div>
                </div>
                <div class="avantageModal">
                    <img src="/themes/admin_simpleboot3/public/assets/images/login/png_twelve.png" alt="">
                    <p class="itemAvantage">数据安全</p>
                    <div class="itemDetailAvantage">
                        <p>系统开源自由部署  </p>
                        <p>避免出现员工数据泄露情况</p>
                    </div>
                </div>
                <div class="avantageModal">
                    <img src="/themes/admin_simpleboot3/public/assets/images/login/png_thirteen.png" alt="">
                    <p class="itemAvantage">数据分析</p>
                    <div class="itemDetailAvantage">
                        <p>整合所有平台数据</p>
                        <p>不短优化推广方式</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 未购买商户客服管理的提示 -->
<div class="unPayBoxHome kfBusinessHome changeKfBusinessHome" style="display: none;width: 100%;">
    <div class="fl" style="position: relative;top: 0px;">
        <img src="/themes/admin_simpleboot3/public/assets/images/login/shangwu.png" alt="">
    </div>
    <div class="fl rightTipOA" style="width:86.5%">
        <div class="topTipBox" style="background-image: url(/themes/admin_simpleboot3/public/assets/images/login/bg-swkfxt.png);
        background-size: 100% 100%;">
            <p class="titleTip">您的账号尚未授权<span class="nowVersion">溪谷在线客服系统</span>，请授权后使用！</p>
            <div class="tipDetail">
                <p style="margin-top: 10px;">高可用，高好用的客服系统</p>
                <p>  解决客户问题，提升客户满意度</p>
            </div>
            <a href="https://www.vlsdk.com/"  target="_blank" class="useBtn_n" >申请授权使用</a>
        </div>
        <div class="con">
            <p class="title-productUnique">产品特色</p>
            <div class="showAllAdvantage">
                <div class="avantageModal">
                    <img src="/themes/admin_simpleboot3/public/assets/images/login/png_qqdjrkh.png" alt="">
                    <p class="itemAvantage">全渠道接入客户</p>
                    <div class="itemDetailAvantage">
                        <p>移动APP、游戏SDK、网页</p>
                        <p>咨询多样化沟通</p>
                    </div>
                </div>
                <div class="avantageModal">
                    <img src="/themes/admin_simpleboot3/public/assets/images/login/png_wdaq.png" alt="">
                    <p class="itemAvantage">稳定安全</p>
                    <div class="itemDetailAvantage">
                        <p>加密链接保证消息安全收发,</p>
                        <p> 用户离开也可接收提醒</p>
                    </div>
                </div>
                <div class="avantageModal">
                    <img src="/themes/admin_simpleboot3/public/assets/images/login/png_kfgxjd.png" alt="">
                    <p class="itemAvantage">客服高效接待</p>
                    <div class="itemDetailAvantage">
                        <p>快速响应客户咨询，</p>
                        <p>提升服务满意度</p>
                    </div>
                </div>
                <div class="avantageModal">
                    <img src="/themes/admin_simpleboot3/public/assets/images/login/png_fwgcjk.png" alt="">
                    <p class="itemAvantage">服务过程监控</p>
                    <div class="itemDetailAvantage">
                        <p>实时监控，数据报表细致全面，</p>
                        <p>服务过程100%掌握</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 未购客服模块 -->
<div class="unPayBoxHome kfWorkHome changeKfWorkHome" style="display: none;width:100%;">
    <div class="fl" style="position: relative;top: 0px;">
        <img src="/themes/admin_simpleboot3/public/assets/images/login/kefu.png" alt="">
    </div>
    <div class="fl rightTipOA" style="width:86.5%">
        <div class="topTipBox" style="background-image: url(/themes/admin_simpleboot3/public/assets/images/login/bg-swkfxt.png);
        background-size: 100% 100%;">
            <p class="titleTip">您的账号尚未授权<span class="nowVersion">溪谷客服工作台</span>，请授权后使用！</p>
            <div class="tipDetail">
                <p style="margin-top: 10px;">高可用，高好用的客服系统</p>
                <p>解决客户问题，提升客户满意度</p>
            </div>
            <a href="https://www.vlsdk.com/"  target="_blank" class="useBtn_n" >申请授权使用</a>
        </div>
        <div class="con">
            <p class="title-productUnique">产品特色</p>
            <div class="showAllAdvantage">
                <div class="avantageModal">
                    <img src="/themes/admin_simpleboot3/public/assets/images/login/png_qqdjrkh.png" alt="">
                    <p class="itemAvantage">全渠道接入客户</p>
                    <div class="itemDetailAvantage">
                        <p>移动APP、游戏SDK、网页</p>
                        <p>咨询多样化沟通</p>
                    </div>
                </div>
                <div class="avantageModal">
                    <img src="/themes/admin_simpleboot3/public/assets/images/login/png_wdaq.png" alt="">
                    <p class="itemAvantage">稳定安全</p>
                    <div class="itemDetailAvantage">
                        <p>加密链接保证消息安全收发,</p>
                        <p> 用户离开也可接收提醒</p>
                    </div>
                </div>
                <div class="avantageModal">
                    <img src="/themes/admin_simpleboot3/public/assets/images/login/png_kfgxjd.png" alt="">
                    <p class="itemAvantage">客服高效接待</p>
                    <div class="itemDetailAvantage">
                        <p>快速响应客户咨询，</p>
                        <p>提升服务满意度</p>
                    </div>
                </div>
                <div class="avantageModal">
                    <img src="/themes/admin_simpleboot3/public/assets/images/login/png_fwgcjk.png" alt="">
                    <p class="itemAvantage">服务过程监控</p>
                    <div class="itemDetailAvantage">
                        <p>实时监控，数据报表细致全面，</p>
                        <p>服务过程100%掌握</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 系统设置模块 -->
<div class="systemModalInner" style="display: none;width: 100%;height: 100%;">
    <div style="width: 100%;height: 100%;">
        <div class="fl systemModalLeft" style="width: 220px;background: #162642;height: 100%;">
            <ul class="nav-list one-menu" style="padding-left:10px">
                <li>
                    <a href="javascript:;" style="pointer-events: none;" class="dropdown-toggle one-menu-title one-drop-title js-one-drop-title customerOneMenu">
                       <i class="fa fa-user-circle normal"></i><span class="menu-text normal"> 系统设置 </span>
                    </a>
                    <ul class="submenu two-menu twoSubMenuChange">
                        <li class="havetreeMenuData">
                            <a href="javascript:;" data-menu="系统设置" id="menuData" class="onlySystem two-menu-title two-no-drop-title js-two-menu-title ">
                               <span class="menu-text onlytwoText">系统设置</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
        <div class="fl rightMainContentIframe" style="width: 88%;height: 100%;padding-top: 18px;">
            <iframe src="" frameborder="0" class="iframeContent" style="width: 100%;height: 100%;"></iframe>
        </div>
    </div>
</div>
<!-- 未购买广告分析后台的提示 -->
<div class="unPayBoxHome advertisementHome" style="display: none">
    <div class="topTipBox">
        <p class="titleTip">您的账号尚未授权<span class="nowVersion">广告监测分析系统</span>，请授权后使用！</p>
        <div class="tipDetail">
            <p style="margin-top: 10px;">面向广告主推出的广告效果追踪和监测平台，</p>
            <p>可获取真实准确的投放数据，为后续运营推广等提供数据支撑</p>
        </div>
        <a href="https://www.vlsdk.com/" target="_blank" class="useBtn">申请授权使用</a>
    </div>
    <div class="con">
        <p class="title-productUnique">产品特色</p>
        <div class="showAllAdvantage">
            <div class="avantageModal">
                <img src="/themes/admin_simpleboot3/public/assets/images/login/png_seven.png" alt="">
                <p class="itemAvantage">用户路径全触点归因</p>
                <div class="itemDetailAvantage">
                    <p>实时归因 </p>
                    <p>清晰区分不同渠道数据</p>
                </div>
            </div>
            <div class="avantageModal">
                <img src="/themes/admin_simpleboot3/public/assets/images/login/png_eight.png" alt="">
                <p class="itemAvantage">实时分析推广活动</p>
                <div class="itemDetailAvantage">
                    <p>检测推广活动转化数据</p>
                    <p>便于及时调整策略</p>
                </div>
            </div>
            <div class="avantageModal">
                <img src="/themes/admin_simpleboot3/public/assets/images/login/png_nigt.png" alt="">
                <p class="itemAvantage">保护广告预算</p>
                <div class="itemDetailAvantage">
                    <p>防作弊体系助您过滤无</p>
                    <p>效广告数据</p>
                </div>
            </div>
            <div class="avantageModal">
                <img src="/themes/admin_simpleboot3/public/assets/images/login/png_ten.png" alt="">
                <p class="itemAvantage">全面分析受众</p>
                <div class="itemDetailAvantage">
                    <p>大规模、自定义、高度</p>
                    <p>细分受众群体</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 发行系统模块 -->
<div class="issueModalInner" style="display: none;width: 100%;height: 100%;">
    <div style="width: 100%;height: 100%;">
        <div class="fl issueModalLeft" style="width: 220px;background: #162642;height: 100%;">
            <ul class="nav-list one-menu" style="padding-left:10px">
                <li>
                    <a href="javascript:;" style="pointer-events: none;"
                       class="dropdown-toggle one-menu-title one-drop-title js-one-drop-title customerOneMenu">
                        <i class="fa fa-arrows normal"></i><span class="menu-text normal">渠道大全 </span>
                    </a>
                    <ul class="submenu two-menu twoSubMenuChange">
                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('issue/channel/lists'); ?>','384issue','用户列表',true);"
                               data-menu="渠道大全" id="menuData" data-url="<?php echo url('issue/channel/lists'); ?>"
                               class="onlySystem two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <span class="menu-text onlytwoText">渠道大全</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="javascript:;" style="pointer-events: none;"
                       class="dropdown-toggle one-menu-title one-drop-title js-one-drop-title customerOneMenu">
                        <i class="fa fa-arrows normal"></i><span class="menu-text normal"> 联运分发 </span>
                    </a>
                    <ul class="submenu two-menu twoSubMenuChange">
                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('issue/user/lists'); ?>','384issue','用户列表',true);"
                               data-menu="用户列表" data-id="384" id="menuData" data-url="<?php echo url('issue/user/lists'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <span class="menu-text onlytwoText">
									用户列表								</span>
                            </a>

                        </li>

                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('issue/platform/lists'); ?>','388issue','平台列表',true);"
                               data-menu="平台列表" data-id="388" id="menuData" data-url="<?php echo url('issue/platform/lists'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">
									平台列表								</span>
                            </a>

                        </li>

                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('issue/apply/lists'); ?>','392issue','联运申请',true);"
                               data-menu="联运申请" data-id="392" id="menuData" data-url="<?php echo url('issue/apply/lists'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">
									联运申请								</span>
                            </a>

                        </li>

                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('issue/game/lists'); ?>','383issue','联运游戏',true);"
                               data-menu="联运游戏" data-id="383" id="menuData" data-url="<?php echo url('issue/game/lists'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">
									联运游戏								</span>
                            </a>

                        </li>

                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('issue/user_balance/lists'); ?>','475issue','联运币充值',true);"
                               data-menu="联运币充值" data-id="475" id="menuData" data-url="<?php echo url('issue/user_balance/lists'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">
									联运币
                                </span>
                            </a>

                        </li>

                    </ul>
                </li>

                <li>
                    <a href="javascript:;" style="cursor:default;"
                       class=" one-menu-title one-drop-title js-one-drop-title customerOneMenu">
                        <i class="fa fa-user-circle normal"></i><span class="menu-text normal"> 数据报表 </span>
                    </a>
                    <ul class="submenu two-menu twoSubMenuChange">
                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('issue/user/register'); ?>','394issue','注册明细',true);"
                               data-menu="玩家注册" data-id="394" id="menuData" data-url="<?php echo url('issue/user/register'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">注册明细</span>
                            </a>
                        </li>
                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('issue/user/recharge'); ?>','396issue','订单明细',true);"
                               data-menu="游戏充值" data-id="396" id="menuData" data-url="<?php echo url('issue/user/recharge'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">订单明细</span>
                            </a>

                        </li>

                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('issue/data/overview'); ?>','511issue','数据总览',true);"
                               data-menu="数据总览" data-id="511" id="menuData" data-url="<?php echo url('issue/data/overview'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <span class="menu-text onlytwoText">数据总览</span>
                            </a>
                        </li>
                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('issue/data/daily'); ?>','512issue','日报数据',true);"
                               data-menu="日报数据" data-id="512" id="menuData" data-url="<?php echo url('issue/data/daily'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">日报数据</span>
                            </a>
                        </li>
                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('issue/data/dailyhour'); ?>','513issue','日报表(时)',true);"
                               data-menu="日报表(时)" data-id="513" id="menuData" data-url="<?php echo url('issue/data/dailyhour'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">日报表(时)</span>
                            </a>

                        </li>
                    </ul>
                </li>

                <li>
                    <a href="javascript:;" style="cursor:default;"
                       class=" one-menu-title one-drop-title js-one-drop-title customerOneMenu">
                        <i class="fa fa-user-circle normal"></i><span class="menu-text normal"> 系统设置 </span>
                    </a>
                    <ul class="submenu two-menu twoSubMenuChange">

                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('admin/user/index'); ?>','111admin','管理员',true);"
                               data-menu="管理员" data-id="111" id="menuData" data-url="<?php echo url('admin/user/index'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">
									管理员								</span>
                            </a>

                        </li>

                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('admin/rbac/index'); ?>','50admin','角色权限',true);"
                               data-menu="角色权限" data-id="50" id="menuData" data-url="<?php echo url('admin/rbac/index'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title twelve js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">
									角色权限								</span>
                            </a>

                        </li>

                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('admin/actionlog/index'); ?>','164admin','行为日志',true);"
                               data-menu="行为日志" data-id="164" id="menuData" data-url="<?php echo url('admin/actionlog/index'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">
									行为日志								</span>
                            </a>

                        </li>

                        <li class="havetreeMenuData">
                            <a href="javascript:openapp('<?php echo url('admin/setting/site'); ?>','71admin','网站信息',true);"
                               data-menu="网站信息" data-id="71" id="menuData" data-url="<?php echo url('admin/setting/site'); ?>"
                               class="two-menu-title two-no-drop-title js-two-menu-title js-issue-menu">
                                <!-- <b class="menu-dot"></b> -->
                                <span class="menu-text onlytwoText">
									网站信息								</span>
                            </a>

                        </li>

                    </ul>
                </li>
            </ul>
        </div>
        <?php if(is_dir(APP_PATH.'issue')): ?>
            <div class="fl rightMainContentIframe" style="width:88%;height: 100%;padding-top: 18px;">
                <iframe src="" frameborder="0" class="issueIframeContent" style="width: 100%;height: 100%;"></iframe>
            </div>
            <?php else: ?>
              <!-- 未配置 -->
              <div class="fl rightMainContentIframe" style="width:86.5%;padding-top: 18px;" >
                <div class="topTipBox" style="background-image: url(/themes/admin_simpleboot3/public/assets/images/login/bg_fxxt.png);
            background-size: 100% 100%;">
                    <p class="titleTip">您的账号尚未授权<span class="nowVersion">溪谷发行系统</span>，请授权后使用！</p>
                    <div class="tipDetail">
                        <p style="margin-top: 10px;">渠道资源整合 海量游戏对接</p>
                        <p>充值收益保障</p>
                    </div>
                    <a href="https://www.vlsdk.com/" target="_blank" class="useBtn_n">申请授权使用</a>
                </div>
                <div class="con">
                    <p class="title-productUnique">产品特色</p>
                    <div class="showAllAdvantage">
                        <div class="avantageModal">
                            <img src="/themes/admin_simpleboot3/public/assets/images/login/ico_zyqdzh.png" alt="">
                            <p class="itemAvantage">资源渠道整合</p>
                            <div class="itemDetailAvantage">
                                <p>全方位多段互通，游戏</p>
                                <p>渠道资源共享</p>
                            </div>
                        </div>
                        <div class="avantageModal">
                            <img src="/themes/admin_simpleboot3/public/assets/images/login/ico_pxzc.png" alt="">
                            <p class="itemAvantage">培训支持</p>
                            <div class="itemDetailAvantage">
                                <p>不怕无经验，系统使用 </p>
                                <p>全程指导</p>
                            </div>
                        </div>
                        <div class="avantageModal">
                            <img src="/themes/admin_simpleboot3/public/assets/images/login/ico_shfw.png" alt="">
                            <p class="itemAvantage">售后服务</p>
                            <div class="itemDetailAvantage">
                                <p>随时在线，全心全意</p>
                                <p>答疑解惑</p>
                            </div>
                        </div>
                        <div class="avantageModal">
                            <img src="/themes/admin_simpleboot3/public/assets/images/login/ico_jszc.png" alt="">
                            <p class="itemAvantage">技术支持</p>
                            <div class="itemDetailAvantage">
                                <p>专业技术维护，细心 </p>
                                <p>打造专属定制</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php endif; ?>


    </div>

</div>



<script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript">
    var oa_domain = "<?php echo cmf_get_option('system_set')['oa_domain']; ?>";
    var kf_business_domain = "<?php echo cmf_get_option('system_set')['kf_business_domain']; ?>";
    var kf_work_domain = "<?php echo cmf_get_option('system_set')['kf_work_domain']; ?>";
    var fuwu_domain = "<?php echo get_upgrade_domain(); ?>";
    var is_login = "<?php echo cmf_get_current_admin_id(); ?>";
    $(function () {
        // 点击左边侧边栏，右边出现相应的东西
        $('#js-homeBack').click(function() {
            if(!is_login) {

            }else {
                console.log(999,$('body').find('.issueModalInner'))
                $('.kfBusinessHome').hide();
                $('.kfWorkHome').hide();

                var homeIframe = $('.appiframe')
                if(homeIframe.length > 1) {
                    var lastIframe = homeIframe[homeIframe.length - 1]
                    lastIframe.remove()
                    Array.prototype.pop.call(homeIframe)
                    var finalNum = homeIframe[homeIframe.length - 1]
                    console.log(888,finalNum)
                    var lastSrc = $(finalNum).attr('src')
                    console.log(5555,lastSrc)
                    openapp('/admin/main/index', 0, '', true)
                }

            }
            var height = 'calc(100% - 45px )'
            $('.main-container').height(height)
            $(this).addClass('activeSystem').siblings().removeClass('activeSystem')
            $(".unPayBoxHome").hide();
            $("#login_ifr").attr('src',"").hide();
            $('.main-page').show();
            $('.top-navbar').show();
            $('.newListSilder ul').css('padding-top','0px')
            $('.systemModalInner').hide()
            $('.issueModalInner').hide()
            if($('.navbar-default').hasClass('navbar-defaultActive')) {
                $('#nav-wrapper').hide()
                // $('.main-container .newListSilder').css('margin-top','-5px')
            }else {
                $('#nav-wrapper').show()
            }
            $('#task-content').show()
            $('.headerNavLeft').show()
            $('.headerNavRight').show()
            $('.headerNavClose').show()
            
            if ($('#task-content-inner li').length > 1) {
                var list = $('#task-content-inner li')
                for(var i =0;i<list.length;i++) {
                    if (i==0) {
                    } else {
                        list[i].remove()
                    }
                }
            }
            
        });

        // 点击工作室OA系统
        $('#js-oa').click(function() {
            //隐藏掉其他的
            $('.kfBusinessHome').hide();
            $('.kfWorkHome').hide();
            $('#login_ifr').hide();

            var height = '100%'
            $('.main-container').height(height)
            $(this).addClass('activeSystem').siblings().removeClass('activeSystem')
            $('.main-page').hide();
            $('.top-navbar').hide();
            $('.systemModalInner').hide();
            $('.issueModalInner').hide();
            if($('.navbar-default').hasClass('navbar-defaultActive')) {
                $('.newListSilder ul').css('padding-top','54px')
            }else {
                $('.newListSilder ul').css('padding-top','54px')
            }

            if(typeof(oa_domain)=="undefined" || oa_domain=='' || oa_domain==null){
                //未配置
                $(".unPayBoxHome").hide();
                $('.oaHome').show().css('width','100%')
            }else{
                //已配置
                $("#login_ifr").attr('src',oa_domain).show();
            }
        })

        //点击SCRM系统
        $('#js-scrm').click(function() {
            //隐藏掉其他的
            $('.kfBusinessHome').hide();
            $('.kfWorkHome').hide();
            $('.oaHome').hide();

            var height = '100%'
            $('.main-container').height(height)
            $(this).addClass('activeSystem').siblings().removeClass('activeSystem')
            $('.main-page').hide();
            $('.top-navbar').hide();
            $('.systemModalInner').hide();
            $('.issueModalInner').hide();
            if($('.navbar-default').hasClass('navbar-defaultActive')) {
                $('.newListSilder ul').css('padding-top','54px')
            }else {
                $('.newListSilder ul').css('padding-top','54px')
            }
            $("#login_ifr").attr('src','https://www.vlscrm.com/').show();
        })


        // 点击商户客服管理
        $('#js-kf_business').click(function() {
            if(typeof(kf_business_domain)=="undefined" || kf_business_domain=='' || kf_business_domain==null){
                //未配置
                $(".unPayBoxHome").hide();
                $('.kfBusinessHome').show().css('width','100%')
                 // //隐藏掉其他的
            $('.oaHome').hide();
                $('.kfWorkHome').hide();
                $("#login_ifr").css("display", "none");
                
                // $("#login_ifr3").css("display","none");
                $(".changeKfBusinessHome").css("display", "block");

                var height = 'calc(100% - 45px )'
                $('.main-container').height(height)
                $(this).addClass('activeSystem').siblings().removeClass('activeSystem')
                $('.main-page').hide();
                $('.top-navbar').hide();
                $('.systemModalInner').hide()
                $('.issueModalInner').hide()
                if ($('.navbar-default').hasClass('navbar-defaultActive')) {
                    $('.newListSilder ul').css('padding-top', '54px')
                } else {
                    $('.newListSilder ul').css('padding-top', '54px')
                }
            }else{
                //已配置
                window.open(kf_business_domain+"/seller");
            }

        })

        // 点击商户客服管理
        $('#js-kf_work').click(function() {

            if(typeof(kf_work_domain)=="undefined" || kf_work_domain=='' || kf_work_domain==null){
                //未配置
                $(".unPayBoxHome").hide();
                $('.kfWorkHome').show().css('width','100%')
                  //隐藏掉其他的
                $('.oaHome').hide();
                $('.kfBusinessHome').hide();
                $("#login_ifr").css("display", "none");
                $(".changeKfWorkHome").css("display", "block");
                var height = 'calc(100% - 45px )'
                $('.main-container').height(height)
                $(this).addClass('activeSystem').siblings().removeClass('activeSystem')
                $('.top-navbar').hide();
                $('.main-page').hide();
                $('.systemModalInner').hide()
                $('.issueModalInner').hide()
                if ($('.navbar-default').hasClass('navbar-defaultActive')) {
                    $('.newListSilder ul').css('padding-top', '54px')
                } else {
                    $('.newListSilder ul').css('padding-top', '54px')
                }

            }else{
                //已配置
                $("#login_ifr3").attr('src',kf_work_domain).show();
                window.open(kf_work_domain);

            }
        })

        // 点击系统设置
        $("#system_setting").click(function () {
            $('.kfBusinessHome').hide();
            $('.kfWorkHome').hide();
            $('.kfWorkHome').hide();
            $('.issueModalInner').hide();

            var height = 'calc(100% - 45px )'
            $('.main-container').height(height)
            $('.onlySystem').addClass('menu-active')
            var url = "<?php echo url('admin/setting/system'); ?>"
            $(this).addClass('activeSystem').siblings().removeClass('activeSystem')
            $('.iframeContent').attr('src', url)
            $('.main-page').hide();
            $('.systemModalInner').css('display', 'block')
            if ($('.navbar-default').hasClass('navbar-defaultActive')) {
                $('#nav-wrapper').hide()
                // $('.main-container .newListSilder').css('margin-top','-5px')
            } else {
                $('#nav-wrapper').show()
            }
            openapp(url, '', '系统设置', true)
            $(".unPayBoxHome").hide();
            $("#login_ifr").attr('src', "").hide();
            // $('.main-page').show();
            $('.top-navbar').show();
            $('.newListSilder ul').css('padding-top', '0px')
            $('#task-content').hide()
            $('.headerNavLeft').hide()
            $('.headerNavRight').hide()
            $('.headerNavClose').hide()
        })


        // 发行系统
        $("#issue_system").click(function () {

            $(".js-issue-menu").removeClass('menu-active');


            $('.kfBusinessHome').hide();
            $('.kfWorkHome').hide();
            $('.systemModalInner').hide();
            $('.oaHome').hide();
            $('.issueModalInner').hide();
            // $('#login_ifr').hide();
            
            var height = 'calc(100% - 45px )'
            $('.main-container').height(height)
            $('.onlySystem').addClass('menu-active')
            var url = "<?php echo url('issue/channel/lists'); ?>"
            $(this).addClass('activeSystem').siblings().removeClass('activeSystem')
            $('.issueIframeContent').attr('src', url)
            $('.main-page').hide();
            $('.issueModalInner').show();
            if ($('.navbar-default').hasClass('navbar-defaultActive')) {
                $('#nav-wrapper').hide()
                // $('.main-container .newListSilder').css('margin-top','-5px')
            } else {
                $('#nav-wrapper').show()
            }
            openapp(url, '', '渠道大全', true)
            $(".unPayBoxHome").hide();
            $("#login_ifr").attr('src', "").hide();
            $("#login_ifr").attr('src', "").hide();
            $("#login_ifr").attr('src', "").hide();
            $("#login_ifr").attr('src', "").hide();
            $("#login_ifr").attr('src', "").hide();
            // $('.main-page').show();
            $('.top-navbar').show();
            $('.newListSilder ul').css('padding-top', '0px')
            $('#task-content').hide()
            $('.headerNavLeft').hide()
            $('.headerNavRight').hide()
            $('.headerNavClose').hide()

        })


        $("#js-fuwu").click(function () {
            window.open(fuwu_domain);
        })

        $(".js-issue-menu").click(function () {
            var url = $(this).attr("data-url");
            openapp(url, '', '', true)
            $(".issueIframeContent").attr('src', url);
        })

        $(".login_ifr").height(window.innerHeight).css('overflow','auto')

    })

</script>

            <!-- 弹窗 判断是否需要显示-->
           <?php if(!(empty($gonggao_info) || (($gonggao_info instanceof \think\Collection || $gonggao_info instanceof \think\Paginator ) && $gonggao_info->isEmpty()))): ?>

               <div class="cooperationBox need_show_gonggao" style="display:none">
                   <div class="detailContainer">
                       <div class="detailContainer-content">
                           <div class="content-title">
                               <p>平台公告</p>
                               <a href="javaScript:;" class="dialogOperationClose"></a>
                           </div>
                           <div class="title-bt"><?php echo $gonggao_info[0]['post_title']; ?></div>
                           <div class="content-textBox">
                               <div class="content1">
                                   <?php echo $gonggao_info[0]['post_content']; ?>
                               </div>
                               <!-- <div class="xinxi">
                                   <p>超神之刃（无限爆真充）游戏关服通知</p>
                                   <p>产品名称：<span>《超神之刃（无限爆真充）》</span></p>
                                   <p>下架原因：由于项目运营计划调整。</p>
                                   <p>正式关闭注册和充值时间：2021年07月03日</p>
                                   <p>正式关服时间：2021年08月03日</p>
                                   <p>游戏内公告：已发布</p>
                               </div> -->
                               <input type="hidden" name="d_post_id" value="<?php echo $gonggao_info[0]['post_id']; ?>">
                           </div>

                           <div class="bottom">
                               <p class="shang previous-post">
                                   <span style="color:#354359">上一篇：</span>
                                   <a href="javascript:;" id="previous_title">
                                       <?php if(!empty($gonggao_info[1]['post_title'])): ?>
                                           <?php echo $gonggao_info[1]['post_title']; else: ?>
                                           暂无
                                       <?php endif; ?>
                                   </a>
                                   <input type="hidden" name="post_id_previous" value="<?php echo $gonggao_info[1]['post_id']; ?>">
                                   <!-- <input type="hidden" name="limit_1" value="<?php echo $limit_1; ?>"> -->
                                   <input type="hidden" name="post_sort_pre" value="<?php echo $gonggao_info[1]['sort']; ?>">

                               </p>
                               <p class="xia next-post">
                                   <span style="color:#354359">下一篇：</span>
                                   <a href="javascript:;" id="next_title">暂无</a>
                                   <input type="hidden" name="post_id_next" value="">
                               </p>

                           </div>
                       </div>
                   </div>
               </div>
           <?php endif; ?>

       </div>
    </div>
    <!-- <div class="sidebar" id="sidebar" style="display:none">
    </div> -->
</div>

<script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
<script src="/static/js/wind.js"></script>
<script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
<script src="/static/js/admin.js"></script>
<script src="/static/js/cookie.js"></script>
<script src="/themes/admin_simpleboot3/public/assets/simpleboot3/js/adminindex.js"></script>
<script>

    // 上一篇公告 by wjd
    $('.previous-post').click(function(){
        var post_id = $("input[ name='post_id_previous'] ").val(); // 当前展示的公告id
        var tmp_url = '<?php echo url("index/getPreviousNextArticle"); ?>';
        $.ajax({
            url: tmp_url,
            type: 'post',
            dataType: 'json',
            data: {post_id:post_id},
            success: function (data) {
                if (data.code > 0) {
                    // console.log(data.data);
                    $('.title-bt').html(data.data.d_gonggaoInfo['post_title']);
                    $('.content1').html(data.data.d_gonggaoInfo['post_content']);
                    if(data.data.previous_gonggaoInfo == null || data.data.previous_gonggaoInfo == undefined || data.data.previous_gonggaoInfo==""){
                        // 上一篇为空
                        $('#previous_title').html("暂无");
                    }else{
                        $('#previous_title').html(data.data.previous_gonggaoInfo['post_title']);
                    }
                    if(data.data.next_gonggaoInfo == null || data.data.next_gonggaoInfo == undefined || data.data.next_gonggaoInfo==""){
                        // 下一篇为空
                        $('#next_title').html("暂无");
                    }else{
                        $('#next_title').html(data.data.next_gonggaoInfo['post_title']);
                    }
                    $("input[ name='post_id_previous'] ").val(data.data.previous_gonggaoInfo['id']);
                    $("input[ name='post_id_next'] ").val(data.data.next_gonggaoInfo['id']);
                } else {
                    // layer.msg(data.msg)
                }
            },
            error: function () {
                // layer.msg("系统繁忙,请销后再试！");
            }
        });
    });
    // 下一篇公告 by wjd
    $('.next-post').click(function(){
        // var limit_1 = $("input[ name='limit_1'] ").val();
        var tmp_url = '<?php echo url("index/getPreviousNextArticle"); ?>';
        var post_id = $("input[ name='post_id_next'] ").val(); // 当前展示的公告id
        $.ajax({
            url: tmp_url,
            type: 'post',
            dataType: 'json',
            data: {post_id:post_id},
            success: function (data) {
                if (data.code > 0) {
                    console.log(data.data);
                    $('.title-bt').html(data.data.d_gonggaoInfo['post_title']);
                    $('.content1').html(data.data.d_gonggaoInfo['post_content']);

                    if(data.data.previous_gonggaoInfo == null || data.data.previous_gonggaoInfo == undefined || data.data.previous_gonggaoInfo==""){
                        // 上一篇为空
                        $('#previous_title').html("暂无");

                    }else{
                        $('#previous_title').html(data.data.previous_gonggaoInfo['post_title']);
                    }
                    if(data.data.next_gonggaoInfo == null || data.data.next_gonggaoInfo == undefined || data.data.next_gonggaoInfo==""){
                        // 下一篇为空
                        $('#next_title').html("暂无");
                    }else{
                        $('#next_title').html(data.data.next_gonggaoInfo['post_title']);
                    }

                    $("input[ name='post_id_previous'] ").val(data.data.previous_gonggaoInfo['id']);
                    $("input[ name='post_id_next'] ").val(data.data.next_gonggaoInfo['id']);
                } else {
                    // layer.msg(data.msg)
                }
            },
            error: function () {
                // layer.msg("系统繁忙,请销后再试！");
            }
        });
    });
    var admin_id = "<?php echo $admin_id; ?>";
    // 今天的时间
    var myDate = new Date;
    var year = myDate.getFullYear(); //获取当前年
    var mon = myDate.getMonth() + 1; //获取当前月
    var date = myDate.getDate();
    var d_date = year + '.' + mon + '.' + date;
    if(localStorage.getItem('need_show_gonggao' + admin_id + 'date_' + d_date) != '1'){
        $('.need_show_gonggao').css('display','block')
        localStorage.setItem('need_show_gonggao' + admin_id + 'date_' + d_date, '1');
    }

    $(function () {
        //平台公告 弹框
        $('.dialogOperationClose').click(function() {
            $('.cooperationBox').css('display','none')
            // logout();
        });

        //监听浏览器返回事件
        pushHistory();
        window.addEventListener("popstate", function(e) {
           var all = $('.appiframe')
            if(all.length>1){
                var final = all[all.length - 1]
                final.remove()
                Array.prototype.pop.call(all)
                all[all.length - 1].classList.add('changeIframe')
            }
        });
        function pushHistory() {
            var state = {
                title: "title",
                url: "#"
            };
            window.history.pushState(state, "title", "#");
        }

        // 弹窗图标点击消失
        $('.closeModalIcon').click(function () {
            $('.systemModal').css('display', 'none')
        });
        $(".rightUpVersion").click(function () {
            $('.systemModal').css('display', 'none');
        });
        $(".cancelUpVersion").click(function () {
            $.cookie('is_upgrade_tag', '1', {expires: 1});
            $('.systemModal').css('display', 'none')
            return false;
        });
        if ($.cookie('is_upgrade_tag') != '1') {
            $('.systemModal').css('display', 'block')
        }


        $('.navShowBtn').click(function() {
             // 展开的功能
            if($('.navbar-default').hasClass('navbar-defaultActive')) {
                $('.navbar-default').removeClass('navbar-defaultActive')
                $('.putAwayIcon').removeClass('putAwayActiveIcon')
                $('#nav-wrapper').css('display','block')
                $('.navbar-brand').css('width','100%')
                $(".systemModalLeft").css('display','block')
                return
            }
            // 收起的功能
            $('.navbar-default').addClass('navbar-defaultActive')
            $('.putAwayIcon').addClass('putAwayActiveIcon')
            $('#nav-wrapper').css('display','none')
            $(".systemModalLeft").css('display','none')
            $('.navbar-brand').css('width','auto')
            // $('.sidebar').css('borderRight','none').width(0).siblings('.main-content').addClass('sidebarActive')
        })

        navWidth()
        $("[data-toggle='tooltip']").tooltip();
        /*$("li.dropdown").hover(function () {
            $(this).addClass("open");
        }, function () {
            $(this).removeClass("open");
        });*/

        var menus= <?php echo $menus_js_var; ?>;
        var tw = window.top;
        var twa =tw.location.href.split("#");
        var url = twa[1];
        var urlTmp = url;
        try {
            var newurl = urlTmp.split('/').slice(0,4);
        }catch (e) {
            urlTmp = '/';
            var newurl = urlTmp.split('/').slice(0,4);
        }
        var newurlTmp = newurl.join('/');
        var arr =twa[0].split("#");
        var test =location.search;
        //后台首页不允许多次出现
        $(".nav-list a").click(function(){
           href = $(this).attr('href');
           if(href.indexOf("openapp('/admin/main/index")!=-1){
               var url = "<?php echo url('main/index'); ?>"
               openapp(url,'0','首页');
               openapp($('.jsfirsttab').attr("app-url"), $('.jsfirsttab').attr("app-id"), $('.jsfirsttab').attr("app-name"));
               return false;
           }
        })
        //读取url参数。尝试执行菜单功能。
        if(typeof(menus) != "undefined"){

            if (url !=null ){
                //去掉/ 去掉_ 全部小写。
                newurlTmp = newurlTmp.replace(/[\\/|_|]/g,"");
                newurlTmp = newurlTmp.replace(".html","");
                var menu = menus[newurlTmp];
                if (menu){
                    if(url=='/admin/main/index.html'){
                        return false;
                    }
                    openapp(url,menu.id+menu.app,menu.name,true);
                    $('.nav-list .submenu a[data-id="'+menu.id+'"]').addClass('menu-active')
                        .parents('ul.submenu').slideDown(150).parent().addClass('open')
                        .find('li').addClass('open').find('ul').slideDown(150);
                }
            }

        }
    });
        $('.headerNavClose').click(function() {
            $('.headerNavList').html('')
            window.location.href = '/admin/index/index'
        })

        function getOverWidth() {
            var listWidth = $("#task-content").innerWidth()
            var sonWidth = $("#task-content-inner").width()
            var finalWidth = listWidth-sonWidth
            if(sonWidth > listWidth) {
                $(".headerNavList").css('margin-left', finalWidth+ 'px')
            }
        }

        function navWidth() {
            var w = window.innerWidth
            var navWidth = $('.navbar-header').width()
            var simple = $('.simplewind-nav').width()
            var sidebar = $('.sidebar-shortcuts').width()
            $('#task-content').css('max-width',w - navWidth - simple - sidebar - 250)
        }

        $(".nav-list .js-one-drop-title").on("click", function (event) {

            var closest_a = $(event.target).closest("a");

            if (!closest_a || closest_a.length == 0 || !closest_a.hasClass("dropdown-toggle")) {
                return
            }

            var closest_a_next = closest_a.next().get(0);

            $(closest_a_next).slideToggle(150).parent().toggleClass("open").siblings().removeClass('open').find('ul').slideUp(150);
            $(closest_a_next).find('li').toggleClass('open').find('ul').slideToggle(150);

            return false;
        });

        $('.nav-list .js-third-menu-title, .nav-list .js-one-menu-title, .nav-list .js-two-menu-title').on('click', function () {
            $('.nav-list .js-third-menu-title, .nav-list .js-one-menu-title, .nav-list .js-two-menu-title').removeClass('menu-active');
            $(this).addClass('menu-active');
             getOverWidth()
        });

        // 左边箭头的事件
        $('.headerNavLeft').click(function() {
            $('.headerNavList').css('margin-left','0px')
        })
        // 右边箭头的事件
        $('.headerNavRight').click(function() {
            getOverWidth()
        })

        if( $('.two-no-drop-title[data-id="468"]')) {
           $('.two-no-drop-title[data-id="468"]').addClass('menu-active')
        }


        function myBrowser() {
            var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
            var isOpera = userAgent.indexOf("Opera") > -1;
            if (userAgent.indexOf("Firefox") > -1) { //判断是否Firefox浏览器
                return "FF";
            }
        }
        var brower = myBrowser()
        if(brower == "FF") {
            $('.nav-list > li > .submenu li.havetreeMenuData a').css('margin-right','7px')
            document.querySelector('[data-id="364"]').classList.add('fireFoxContent')
        }
        var u = navigator.userAgent;
        var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
        var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
        if(isiOS) {
           $('html').css({'-webkit-overflow-scrolling': 'touch','overflow':'auto'})
        }

        // 修改侧边栏导航中字数只有两个样式错位的问题
    try {
        document.querySelector('[data-id="240"]').classList.add('rejudgeItem')
    } catch(err){}
    try {
        document.querySelector('[data-id="353"]').classList.add('rejudgeItem')
    } catch(err){}
    try {
        document.querySelector('[data-id="362"]').classList.add('overWidthItem')
    } catch(err){}
    try {
        document.querySelector('[data-id="459"]').classList.add('removeWidth')
    } catch(err){}
    try {
        document.querySelector('[data-id="196"]').classList.add('twelve')
    } catch(err){}
    try {
        document.querySelector('[data-id="50"]').classList.add('twelve')
    } catch(err){}
    try {
        document.querySelector('[data-id="371"]').classList.add('nine')
    } catch(err){}
    try {
        document.querySelector('[data-id="227"]').classList.add('nine')
    } catch(err){}

</script>
</body>
</html>
