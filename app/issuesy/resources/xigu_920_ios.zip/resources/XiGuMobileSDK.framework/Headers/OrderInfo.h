//
//  OrderInfo.h
//
//  Created by 梦创 .
//  Copyright © 梦创. All rights reserved.
//

/**
 *      商品参数
 *
 **/

#import <Foundation/Foundation.h>

@interface OrderInfo : NSObject

@property (nonatomic, strong) NSString *goodsPrice;     // 商品价格(价格为 分)
@property (nonatomic, strong) NSString *goodsName;      // 商品名称
@property (nonatomic, strong) NSString *goodsDesc;      // 商品描述
@property (nonatomic, strong) NSString *productId;      // 内购产品id(不使用内购值保持默认，不要为空)
@property (nonatomic, strong) NSString *extendInfo;     // 此字段会透传到游戏服务器，可拼接(建议拼接时间戳)
@property (nonatomic, strong) NSString *gameVersion;    // 游戏版本号(CP提供)
@property (nonatomic, strong) NSString *goods_reserve;  // 订-单预留参数(有多余值可传，没有则不传)

@end
