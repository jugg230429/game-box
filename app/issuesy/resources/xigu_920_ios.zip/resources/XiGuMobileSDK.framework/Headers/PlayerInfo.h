//
//  PlayerInfo.h
//
//  Created by zhujin zhujin on 17/8/18.
//  Copyright © 2017年 朱进. All rights reserved.
//

/**
 *      玩家信息
 *
 ***/

#import <Foundation/Foundation.h>

@interface PlayerInfo : NSObject

@property (nonatomic, copy) NSString *gameService;      // 区服名
@property (nonatomic, copy) NSString *gameServiceId;    // 区服id
@property (nonatomic, copy) NSString *playerLevel;      // 角色等级
@property (nonatomic, copy) NSString *playerName;       // 角色名称
@property (nonatomic, copy) NSString *playerNameID;     // 角色id
@property (nonatomic, copy) NSString *player_reserve;   // 角色预留参数(有多余值可传，没有则不传)

@end
