//
//  XiGuPlatformSdk.h
//  XiGuPlatformSdk
//
//  Created by zhujin zhujin on 2018/9/11.
//  Copyright © 2018年 XiGu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MCHApi.h"
#import "OrderInfo.h"

//! Project version number for XiGuPlatformSdk.
FOUNDATION_EXPORT double XiGuPlatformSdkVersionNumber;

//! Project version string for XiGuPlatformSdk.
FOUNDATION_EXPORT const unsigned char XiGuPlatformSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XiGuPlatformSdk/PublicHeader.h>


