//
//  MCHApi.h

//
//  Created by 梦创 .
//  Copyright © 梦创. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OrderInfo.h"       // 订单模型类
#import "PlayerInfo.h"      // 游戏角色模型类
#import "MCUtilsFactory.h"  // 附加功能类


typedef void(^CompletionBlock)(NSDictionary *resultDic);

@interface MCHApi : NSObject

/**
 *      注销回调(SDK内注销回调、clickLoginOut接口回调)
 *  注： 1、悬浮球页面注销，点击按钮触发，触发即代表注销成功；方法需要先执行(参照demo)；
 *      2、调用 [[MCHApi sharedInstance] clickLoginOut]; 也会触发此回调；
 */
@property (nonatomic, copy,setter=setExitLogin:) CompletionBlock exitLogin;

/**
 *  创建单例服务
 *
 *  @return 返回单例对象
 */
+ (MCHApi *)sharedInstance;

/**
 *  初始化方法,在应用didFinishLaunchingWithOptions中调用(必接)
 */
- (BOOL)initApi:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;

/**
 *  登录接口
 *  @param completion     登录结果回调Block
 *  回调数据说明：
 *      loginresult 为1，代表登录成功；其他失败
 *      account     用户的account
 *      userId      用户的userId
 */
- (void)addLoginView:(CompletionBlock)completion;

/**
 *  注销接口
 * 回调结果同 [[MCHApi sharedInstance] setExitLogin:] 方法 ，
 */
- (void)clickLoginOut;

/**
 *  支付接口
 *  @param orderStr        订单信息(具体参照demo)
 *  @param completionBlock 交换结果回调Block
 */
- (void)exchange:(OrderInfo *)orderStr completionBlock:(CompletionBlock)completionBlock;

/**
 *  上传(更新)角色信息接口
 *  @param playerInfo 玩家信息(具体参照demo)
 *  @param resultDict 上传结果回调Block
 *  注：玩家选择完区服信息调用；更新角色信息再次调用
 */
- (void)addPlayerInfo:(PlayerInfo *)playerInfo completionBlock:(void(^)(NSDictionary *resultDict))resultDict;

/**
 *  添加/显示悬浮窗
 */
- (void)addFloatingView;

/**
 *  移除悬浮窗
 */
- (void)removeFloatingView;

/**
 *  用于微信QQ登录和支付回调(必接)
 */
- (void)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

/**
 *  用于微信QQ登录和支付回调(必接)
 */
- (void)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString *, id> *)options;

/**
 *  主要用于支付回调(必接)
 */
- (void)application:(UIApplication *)application handleOpenURL:(NSURL *)url;



@end









