//
//  MCHFunctionApi.h
//  XiGuMobileSDK
//
//  Created by zhujin on 2019/4/30.
//  Copyright © 2019 XiGu. All rights reserved.
//


/**
 *      附加功能类
 *
 */

#import <Foundation/Foundation.h>

typedef void(^CompletionBlock)(NSDictionary *resultDic);

@interface MCUtilsFactory : NSObject

/**
 *  创建单例服务
 *  @return 返回单例对象
 */
+ (MCUtilsFactory *)sharedInstance;

/**
 * 防沉迷回调
 *@param typeBlock  返回修改结果
 */
- (void)getUserType:(CompletionBlock)typeBlock;

/**
 *  当前版本号
 */
- (NSString *)versionStr;

/*
 * @return UUID（不涉及私有API）
 **/
- (NSString *)deviceUUID;

/*
 * @return 屏幕分辨率
 **/
- (NSString *)deviceSize;

/*
 * @return 设备操作系统 (例：iPhone OS9.3.2)
 **/
- (NSString *)deviceSystemName;

/*
 * @return 当前网络状态 （当前网络状态不可达、Wifi、2G、3G、4G、WWAN、未知）
 **/
- (NSString *)currentNetWork;

/*
 * @return 设备运营商
 **/
- (NSString *)currentOperator;

/*
 * @return 手机型号 iPhone 系列、iPod 系列、iPad 系列
 **/
- (NSString *)deviceModel;

@end
